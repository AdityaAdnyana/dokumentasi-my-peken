# Local Diagram Helper Tools (`.ai-tools/`)

Utilitas lokal (di-ignore Git) untuk merancang, mengaudit, merutekan klaster secara organik, dan mengekspor diagram `.drawio` (`<mxfile>`) menjadi `.png` berformat default Draw.io secara cepat via headless Chrome.

## 1. `diagram_lib.js`
Fungsi inti XML, audit geometri, dan penyematan metadata PNG:
- `buildMultiPageMxfileXml(pages)` / `buildSinglePageMxfileXml(page)` — Menghasilkan `<mxfile host="app.diagrams.net" ...>` bersih tanpa atribut/jejak AI.
- `verifyNoAiMetadata(xml)` — Memastikan bebas pola `antigravity`, `ai-generated`, `claude`, `openai`, `chatgpt`, `gemini`.
- `rectsOverlap(a, b, pad = 2)` & `segIntersectsRect(p1, p2, rect, pad = 4)` — Audit tumpang tindih kotak dan tabrakan segmen ke node (gunakan `pad < 0` untuk margin halo luar).
- `findCollinearOverlaps(edges, minParallelGap = 6, minOverlapLen = 8)` — Deteksi garis sejajar bertumpuk.
- `countEdgeCrossings(edges)` — Menghitung total persilangan garis.
- `embedMxfileInPng(pngPath, singlePageMxfileXml)` — Menyematkan chunk `tEXt:mxfile` yang valid dan terkompresi URL ke file PNG.

## 2. `cluster_router.js`
Router ortogonal untuk tata letak klaster 2D organik (non-grid kaku):
```js
const { routeClusterEdges } = require('./.ai-tools/cluster_router');
const routed = routeClusterEdges(nodes, edgeSpecs, {
  margin: 56,
  stubLen: 22,
  minPortSpacing: 12,
  nodeClearance: 10,
  parallelGap: 9,
  labelFontSize: 10,
  trackStep: 12
});
```
Fitur:
- Distribusi port 4 sisi (`T/B/L/R`) terurut berdasarkan sudut polar `atan2` tanpa memelintir panah timbal balik.
- Penempatan terminal langsung pada keliling lingkaran untuk node dengan `kind: 'process'`.
- Pre-reservasi stub agar tidak terblokir segmen lain + fallback Hanan-grid A* dengan `0` collinear overlap.
- Penempatan label otomatis menghindari node dan garis lain + normalisasi `pageWidth` / `pageHeight`.

## 3. `render_mxfile_chrome.js`
Renderer cepat `<mxfile>` XML single-page -> PNG default Draw.io (`Zoom: 100%`, `Border: 0`, `Size: Diagram`, font `Helvetica, Arial, sans-serif`, background `#ffffff`, rounded corners & jump arcs, dan chunk `tEXt:mxfile`):
```js
const { renderDrawioXmlToPng } = require('./.ai-tools/render_mxfile_chrome');
await renderDrawioXmlToPng('single_page.drawio', 'output.drawio.png');
```
Catatan: Menggunakan `C:\Program Files\Google\Chrome\Application\chrome.exe --headless=new` dengan fallback otomatis ke Chrome DevTools Protocol (`Page.captureScreenshot` `captureBeyondViewport: true`) jika dimensi melebihi batas viewport standar.
