const path = require('path');
const engine = require('./bpmn_engine');
const pages1_4 = require('./bpmn_pages_1_4');
const pages5_8 = require('./bpmn_pages_5_8');

(async () => {
  const root = path.resolve(__dirname, '..');
  const outDrawio = path.join(root, 'Diagram', 'BPMN', 'BPMN MyPeken.drawio');
  const outPngDir = path.join(root, 'Diagram', 'BPMN', 'PNG');
  const allPages = [...pages1_4, ...pages5_8];
  await engine.buildAndExportAll(allPages, outDrawio, outPngDir);
  console.log('ALL 8 BPMN PAGES BUILT, AUDITED, AND EXPORTED SUCCESSFULLY.');
})().catch((err) => {
  console.error('BUILD FAILED:', err.message);
  process.exit(1);
});
