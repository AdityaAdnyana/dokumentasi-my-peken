const PAGES_5_8 = [
  // =========================================================================
  // HALAMAN 05: PEMENUHAN PESANAN, KURIR, PEMBATALAN & ULASAN
  // =========================================================================
  {
    id: 'p5',
    name: '05. Pemenuhan, Kurir & Ulasan',
    pngName: '05- BPMN Pemenuhan Pesanan, Kurir, Batal & Ulasan.drawio.png',
    lanes: [
      { id: 'buyer', label: 'Pembeli', height: 225 },
      { id: 'seller', label: 'Penjual UMKM', height: 225 },
      { id: 'sys', label: 'Sistem MyPeken', height: 500, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_log', label: 'API Logistik', cx: 1580, w: 185 },
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 2250, w: 220 }
    ],
    nodes: [
      // --- Awal Status Dibayar & Timer SLA ---
      { id: 's_paid', laneId: 'sys', type: 'start', symbol: 'message', label: 'Pesanan Status\nDibayar', cx: 45, cy: 175, labelSide: 'T' },
      { id: 't_sla_calc', laneId: 'sys', type: 'task', marker: 'service', label: 'Hitung SLA Jam Operasional\n(Reg 1x24j | SD 3j | Instan 2j)', cx: 205, cy: 175 },
      { id: 'ann_sla', laneId: 'sys', type: 'annotation', label: 'Toggle Libur tidak menjeda timer;\norder luar jam mulai buka berikut', cx: 205, cy: 62 },
      { id: 'g_ev_paid', laneId: 'sys', type: 'gateway', gwType: 'event', label: '', cx: 365, cy: 175 },

      // Branch 1: Pembeli Batal Sepihak saat Dibayar (FR-021)
      { id: 's_buy_cxl', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Ingin Batal\n(Dibayar)', cx: 205, cy: 62, labelSide: 'T' },
      { id: 't_buy_cxl', laneId: 'buyer', type: 'task', marker: 'user', label: 'Tekan Batalkan\nPesanan (Dibayar)', cx: 485, cy: 62 },
      { id: 'ic_buy_cxl', laneId: 'sys', type: 'intermediate', symbol: 'message', outline: 'catching', label: 'Pembeli Batal\nSepihak', cx: 485, cy: 65, labelSide: 'B' },
      { id: 'g_ref_reg_m', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 665, cy: 65 },
      { id: 'sp_ref_reg', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Batal & Refund Saldo Reguler\n(Biaya Layanan Non-Refundable)', cx: 860, cy: 65 },
      { id: 'e_batal_buy', laneId: 'sys', type: 'end', symbol: 'general', label: 'Batal Mandiri\nPembeli', cx: 1035, cy: 65, labelSide: 'R' },

      // Branch 2: SLA Respon Habis / Penjual Tolak -> Refund 100% Saldo Bebas
      { id: 'ic_sla_resp', laneId: 'sys', type: 'intermediate', symbol: 'timer', outline: 'catching', label: 'SLA Respon\nLewat', cx: 485, cy: 315, labelSide: 'B' },
      { id: 'g_ref_free_m', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 665, cy: 315 },
      { id: 'g_batal_tmr_m', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 665, cy: 420 },
      { id: 'sp_ref_free', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Batal & Refund 100% ke Saldo\nBebas Biaya Tarik + Notif WA', cx: 860, cy: 315 },
      { id: 'd5_rel', laneId: 'sys', type: 'datastore', label: 'D5: Stok', cx: 810, cy: 425 },
      { id: 'd11_ref', laneId: 'sys', type: 'datastore', label: 'D11: Saldo Saya', cx: 935, cy: 425 },
      { id: 'e_batal_sys', laneId: 'sys', type: 'end', symbol: 'general', label: 'Batal & Refund\nPenuh 100%', cx: 1055, cy: 315, labelSide: 'T' },

      // Branch 3: Penjual Proses atau Tolak (FR-014)
      { id: 't_sell_resp', laneId: 'seller', type: 'task', marker: 'user', label: 'Proses Pesanan (Diproses)\natau Tolak + Alasan', cx: 665, cy: 112 },
      { id: 'g_sell_acc', laneId: 'seller', type: 'gateway', gwType: 'exclusive', label: 'Terima?', cx: 815, cy: 112, labelSide: 'T' },
      { id: 't_lbl_pdf', laneId: 'seller', type: 'task', marker: 'user', label: 'Cetak Label\nPengiriman PDF (FR-038)', cx: 975, cy: 68 },
      { id: 'do_lbl', laneId: 'seller', type: 'dataobject', label: 'Label Pengiriman\nPDF', cx: 975, cy: 170 },

      { id: 't_notif_proc', laneId: 'sys', type: 'task', marker: 'send', label: 'Set Diproses & Notif\nIn-App Pembeli (FR-022)', cx: 975, cy: 185 },
      { id: 'g_buy_req_cxl', laneId: 'buyer', type: 'gateway', gwType: 'exclusive', label: 'Ajukan\nBatal 1x?', cx: 1125, cy: 62, labelSide: 'T' },
      { id: 't_buy_req_cxl', laneId: 'buyer', type: 'task', marker: 'user', label: 'Ajukan Pembatalan\n(Maks 1x + Alasan)', cx: 1125, cy: 155 },
      { id: 't_sell_cxl_dec', laneId: 'seller', type: 'task', marker: 'user', label: 'Setujui atau Tolak\nAjuan Pembatalan', cx: 1125, cy: 68 },
      { id: 'g_cxl_acc', laneId: 'seller', type: 'gateway', gwType: 'exclusive', label: 'Setuju\nBatal?', cx: 1265, cy: 68, labelSide: 'T' },

      // --- Pengiriman & Kurir (FR-014, FR-030) ---
      { id: 't_sell_ship', laneId: 'seller', type: 'task', marker: 'user', label: 'Tekan Kirim Pesanan\n(Sesuai SLA Kurir)', cx: 1415, cy: 68 },
      { id: 'b_sla_ship', type: 'boundary', hostId: 't_sell_ship', posRatio: 0.96, symbol: 'timer', label: 'SLA Kirim\nLewat', cx: 0, cy: 0, labelSide: 'R' },
      { id: 'g_kurir', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Kategori\nKurir?', cx: 1415, cy: 175, labelSide: 'L' },
      { id: 't_reg_resi', laneId: 'sys', type: 'task', marker: 'service', label: 'Auto-Booking Resi\n(Fallback Manual)', cx: 1595, cy: 115 },
      { id: 't_inst_drv', laneId: 'sys', type: 'task', marker: 'service', label: 'Panggil Driver (Mencari\nDriver, Retry 15m)', cx: 1595, cy: 235 },
      { id: 'b_drv_to', type: 'boundary', hostId: 't_inst_drv', posRatio: 0.04, symbol: 'timer', label: 'Timeout Driver\n(3j / 6j)', cx: 0, cy: 0, labelSide: 'L' },
      { id: 'g_kurir_m', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 1745, cy: 175 },

      { id: 't_shipped', laneId: 'sys', type: 'task', marker: 'service', label: 'Set Dikirim, Salurkan Ongkir\n+ Asuransi & Webhook/Polling', cx: 1895, cy: 175 },
      { id: 'd7_ord', laneId: 'sys', type: 'datastore', label: 'D7: Pesanan', cx: 1785, cy: 385 },
      { id: 'd8_esc', laneId: 'sys', type: 'datastore', label: 'D8: Escrow', cx: 1905, cy: 385 },
      { id: 'g_par_trk', laneId: 'sys', type: 'gateway', gwType: 'parallel', label: '', cx: 2045, cy: 175 },
      { id: 't_buy_trk', laneId: 'buyer', type: 'task', marker: 'user', label: 'Pantau Pesanan Saya, Lacak\n& Unduh Invoice PDF', cx: 2045, cy: 62 },
      { id: 'do_inv', laneId: 'buyer', type: 'dataobject', label: 'Invoice Transaksi\nPDF (FR-038)', cx: 1860, cy: 62 },
      { id: 'e_trk_done', laneId: 'buyer', type: 'end', symbol: 'general', label: 'Selesai Pantau /\nUnduh Invoice', cx: 2215, cy: 62, labelSide: 'R' },

      { id: 'g_log_res', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Status\nKurir?', cx: 2185, cy: 175, labelSide: 'T' },
      { id: 't_fail_esc', laneId: 'sys', type: 'task', marker: 'service', label: 'Tahan Escrow & Eskalasi\nGagal Kirim/Retur (FR-030)', cx: 2185, cy: 300 },
      { id: 'e_esc_log', laneId: 'sys', type: 'end', symbol: 'escalation', label: 'Ke Resolusi\n(Proses 6.0)', cx: 2335, cy: 300, labelSide: 'B' },

      { id: 't_notif_dlv', laneId: 'sys', type: 'task', marker: 'send', label: 'Set Terkirim & Notif\nIn-App/WA (Tenggat 2x24j)', cx: 2365, cy: 175 },
      { id: 'd16_not', laneId: 'sys', type: 'datastore', label: 'D16: Notif', cx: 2365, cy: 410 },
      { id: 'g_ev_conf', laneId: 'sys', type: 'gateway', gwType: 'event', label: '', cx: 2525, cy: 175 },

      { id: 'ic_comp', laneId: 'sys', type: 'intermediate', symbol: 'message', outline: 'catching', label: 'Ajukan\nKomplain', cx: 2525, cy: 300, labelSide: 'L' },
      { id: 'e_esc_comp', laneId: 'sys', type: 'end', symbol: 'escalation', label: 'Ke Komplain &\nMediasi (Proses 6.0)', cx: 2675, cy: 300, labelSide: 'R' },

      { id: 't_buy_recv', laneId: 'buyer', type: 'task', marker: 'user', label: 'Tekan Pesanan\nDiterima (FR-020)', cx: 2525, cy: 62 },
      { id: 'ic_auto_48', laneId: 'sys', type: 'intermediate', symbol: 'timer', outline: 'catching', label: 'Otomatis\n2x24 Jam', cx: 2675, cy: 175, labelSide: 'B' },
      { id: 'g_fin_m', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 2805, cy: 175 },
      { id: 't_rel_esc', laneId: 'sys', type: 'task', marker: 'service', label: 'Set Selesai, Potong Komisi &\nCairkan Escrow ke Saldo Toko', cx: 2955, cy: 175 },
      { id: 'd3_bal', laneId: 'sys', type: 'datastore', label: 'D3: Saldo Toko', cx: 2955, cy: 385 },

      // --- Rating & Ulasan (FR-013) ---
      { id: 't_review', laneId: 'buyer', type: 'task', marker: 'user', label: 'Beri Rating 1-5, Ulasan\n& <=3 Foto (1x)', cx: 2955, cy: 62 },
      { id: 'b_rev_30', type: 'boundary', hostId: 't_review', posRatio: 0.96, symbol: 'timer', label: 'Lewat\n30 Hari', cx: 0, cy: 0, labelSide: 'R' },
      { id: 'e_rev_exp', laneId: 'buyer', type: 'end', symbol: 'general', label: 'Ulasan\nDinonaktifkan', cx: 3175, cy: 62, labelSide: 'R' },
      { id: 't_recalc', laneId: 'sys', type: 'task', marker: 'service', label: 'Simpan Ulasan & Hitung\nUlang Rating Produk/Toko', cx: 3165, cy: 175 },
      { id: 'd9_rev', laneId: 'sys', type: 'datastore', label: 'D9: Ulasan', cx: 3165, cy: 385 },
      { id: 't_sell_reply', laneId: 'seller', type: 'task', marker: 'user', label: 'Beri Maks 1x Balasan\nPublik Ulasan', cx: 3165, cy: 68 },
      { id: 'e_done_p5', laneId: 'seller', type: 'end', symbol: 'general', label: 'Pesanan &\nUlasan Selesai', cx: 3325, cy: 68, labelSide: 'R' }
    ],
    edges: [
      { src: 's_paid', dst: 't_sla_calc', srcSide: 'R', dstSide: 'L' },
      { src: 't_sla_calc', dst: 'ann_sla', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_sla_calc', dst: 'g_ev_paid', srcSide: 'R', dstSide: 'L' },

      // Event-based pada status Dibayar
      { src: 'g_ev_paid', dst: 'ic_buy_cxl', srcSide: 'T', dstSide: 'L' },
      { src: 's_buy_cxl', dst: 't_buy_cxl', srcSide: 'R', dstSide: 'L' },
      { src: 't_buy_cxl', dst: 'ic_buy_cxl', srcSide: 'B', dstSide: 'T' },
      { src: 'ic_buy_cxl', dst: 'g_ref_reg_m', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ref_reg_m', dst: 'sp_ref_reg', srcSide: 'R', dstSide: 'L' },
      { src: 'sp_ref_reg', dst: 'e_batal_buy', srcSide: 'R', dstSide: 'L' },

      { src: 'g_ev_paid', dst: 'ic_sla_resp', srcSide: 'B', dstSide: 'L' },
      { src: 'ic_sla_resp', dst: 'g_ref_free_m', srcSide: 'R', dstSide: 'L' },
      { src: 'g_batal_tmr_m', dst: 'g_ref_free_m', srcSide: 'T', dstSide: 'B' },
      { src: 'g_ref_free_m', dst: 'sp_ref_free', srcSide: 'R', dstSide: 'L' },
      { src: 'sp_ref_free', dst: 'd5_rel', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'sp_ref_free', dst: 'd11_ref', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'sp_ref_free', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Batal & Refund' },
      { src: 'sp_ref_free', dst: 'e_batal_sys', srcSide: 'R', dstSide: 'L' },

      { src: 'g_ev_paid', dst: 't_sell_resp', srcSide: 'R', dstSide: 'B' },
      { src: 't_sell_resp', dst: 'g_sell_acc', srcSide: 'R', dstSide: 'L' },
      { src: 'g_sell_acc', dst: 'g_ref_free_m', srcSide: 'B', dstSide: 'T', label: 'Tolak' },
      { src: 'g_sell_acc', dst: 't_lbl_pdf', srcSide: 'R', dstSide: 'L', label: 'Proses' },
      { src: 't_lbl_pdf', dst: 'do_lbl', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_lbl_pdf', dst: 't_notif_proc', srcSide: 'B', dstSide: 'T' },
      { src: 't_notif_proc', dst: 'g_buy_req_cxl', srcSide: 'R', dstSide: 'L' },

      { src: 'g_buy_req_cxl', dst: 't_buy_req_cxl', srcSide: 'B', dstSide: 'T', label: 'Ya' },
      { src: 't_buy_req_cxl', dst: 't_sell_cxl_dec', srcSide: 'R', dstSide: 'B' },
      { src: 't_sell_cxl_dec', dst: 'g_cxl_acc', srcSide: 'R', dstSide: 'L' },
      { src: 'g_cxl_acc', dst: 'g_ref_reg_m', srcSide: 'B', dstSide: 'T', label: 'Setuju' },
      { src: 'g_cxl_acc', dst: 't_sell_ship', srcSide: 'R', dstSide: 'L', label: 'Tolak' },
      { src: 'g_buy_req_cxl', dst: 't_sell_ship', srcSide: 'R', dstSide: 'T', label: 'Tidak' },

      { src: 'b_sla_ship', dst: 'g_batal_tmr_m', srcSide: 'B', dstSide: 'R' },
      { src: 't_sell_ship', dst: 'g_kurir', srcSide: 'B', dstSide: 'T' },
      { src: 'g_kurir', dst: 't_reg_resi', srcSide: 'R', dstSide: 'L', label: 'Reguler' },
      { src: 'g_kurir', dst: 't_inst_drv', srcSide: 'B', dstSide: 'L', label: 'Instan / SD' },
      { src: 't_reg_resi', dst: 'ext_log', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Booking Resi' },
      { src: 't_inst_drv', dst: 'ext_log', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Panggil Driver' },
      { src: 'b_drv_to', dst: 'g_batal_tmr_m', srcSide: 'B', dstSide: 'B' },
      { src: 't_reg_resi', dst: 'g_kurir_m', srcSide: 'R', dstSide: 'T' },
      { src: 't_inst_drv', dst: 'g_kurir_m', srcSide: 'R', dstSide: 'B' },
      { src: 'g_kurir_m', dst: 't_shipped', srcSide: 'R', dstSide: 'L' },
      { src: 't_shipped', dst: 'd7_ord', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_shipped', dst: 'd8_esc', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'ext_log', dst: 't_shipped', srcSide: 'T', dstSide: 'B', kind: 'message', label: 'Webhook / Polling' },

      { src: 't_shipped', dst: 'g_par_trk', srcSide: 'R', dstSide: 'L' },
      { src: 'g_par_trk', dst: 't_buy_trk', srcSide: 'T', dstSide: 'B' },
      { src: 't_buy_trk', dst: 'do_inv', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 't_buy_trk', dst: 'e_trk_done', srcSide: 'R', dstSide: 'L' },
      { src: 'g_par_trk', dst: 'g_log_res', srcSide: 'R', dstSide: 'L' },
      { src: 'g_log_res', dst: 't_fail_esc', srcSide: 'B', dstSide: 'T', label: 'Gagal / Retur' },
      { src: 't_fail_esc', dst: 'e_esc_log', srcSide: 'R', dstSide: 'L' },
      { src: 'g_log_res', dst: 't_notif_dlv', srcSide: 'R', dstSide: 'L', label: 'Terkirim' },
      { src: 't_notif_dlv', dst: 'd16_not', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_notif_dlv', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'WA Terkirim' },
      { src: 't_notif_dlv', dst: 'g_ev_conf', srcSide: 'R', dstSide: 'L' },

      { src: 'g_ev_conf', dst: 'ic_comp', srcSide: 'B', dstSide: 'T' },
      { src: 'ic_comp', dst: 'e_esc_comp', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ev_conf', dst: 't_buy_recv', srcSide: 'T', dstSide: 'B' },
      { src: 't_buy_recv', dst: 'g_fin_m', srcSide: 'R', dstSide: 'T' },
      { src: 'g_ev_conf', dst: 'ic_auto_48', srcSide: 'R', dstSide: 'L' },
      { src: 'ic_auto_48', dst: 'g_fin_m', srcSide: 'R', dstSide: 'L' },
      { src: 'g_fin_m', dst: 't_rel_esc', srcSide: 'R', dstSide: 'L' },
      { src: 't_rel_esc', dst: 'd3_bal', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_rel_esc', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Selesai' },

      { src: 't_rel_esc', dst: 't_review', srcSide: 'T', dstSide: 'B' },
      { src: 'b_rev_30', dst: 'e_rev_exp', srcSide: 'B', dstSide: 'B' },
      { src: 't_review', dst: 't_recalc', srcSide: 'R', dstSide: 'T' },
      { src: 't_recalc', dst: 'd9_rev', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_recalc', dst: 't_sell_reply', srcSide: 'T', dstSide: 'B' },
      { src: 't_sell_reply', dst: 'e_done_p5', srcSide: 'R', dstSide: 'L' }
    ]
  },

  // =========================================================================
  // HALAMAN 06: KOMPLAIN, MEDIASI, SENGKETA & RETUR
  // =========================================================================
  {
    id: 'p6',
    name: '06. Komplain, Mediasi & Retur',
    pngName: '06- BPMN Komplain, Mediasi, Sengketa & Retur.drawio.png',
    lanes: [
      { id: 'buyer', label: 'Pembeli', height: 220 },
      { id: 'seller', label: 'Penjual UMKM', height: 220 },
      { id: 'admin_cs', label: 'Admin CS', height: 150 },
      { id: 'sys', label: 'Sistem MyPeken', height: 390, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_log', label: 'API Logistik', cx: 1380, w: 185 },
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 1980, w: 220 }
    ],
    nodes: [
      // --- Pengajuan Komplain & Mediasi 1x24j (FR-020) ---
      { id: 's_comp', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Ajukan Komplain\n(Dikirim / Terkirim)', cx: 45, cy: 74, labelSide: 'B' },
      { id: 't_comp_in', laneId: 'buyer', type: 'task', marker: 'user', label: 'Isi Alasan, Bukti Unboxing /\nETD & Usul Full/Partial', cx: 210, cy: 74 },
      { id: 'do_unbox', laneId: 'buyer', type: 'dataobject', label: 'Bukti Unboxing /\nResi & Struk Retur', cx: 210, cy: 170 },

      { id: 't_comp_hold', laneId: 'sys', type: 'task', marker: 'service', label: 'Bekukan Escrow, Set Mediasi\n& Notif Penjual (1x24j)', cx: 210, cy: 82 },
      { id: 'g_ev_med', laneId: 'sys', type: 'gateway', gwType: 'event', label: '', cx: 380, cy: 82 },

      { id: 't_med_acc', laneId: 'seller', type: 'task', marker: 'user', label: 'Setujui Usulan\nFull / Partial Refund', cx: 380, cy: 68 },
      { id: 't_med_exec', laneId: 'sys', type: 'task', marker: 'service', label: 'Eksekusi Refund Saldo Bebas\n& Beban Arrears (INV-07)', cx: 560, cy: 82 },
      { id: 'e_med_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Selesai di\nTahap Mediasi', cx: 560, cy: 195, labelSide: 'B' },

      { id: 't_med_rej', laneId: 'seller', type: 'task', marker: 'user', label: 'Tolak / Kirim\nBukti Bantahan', cx: 560, cy: 162 },
      { id: 'ic_med_to', laneId: 'sys', type: 'intermediate', symbol: 'timer', outline: 'catching', label: '1x24 Jam\nTanpa Respon', cx: 380, cy: 205, labelSide: 'B' },
      { id: 's_fail_dlv', laneId: 'sys', type: 'start', symbol: 'message', label: 'Eskalasi Gagal Kirim /\nDikembalikan (FR-030)', cx: 740, cy: 315, labelSide: 'L' },
      { id: 'g_esc_m', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 740, cy: 185 },
      { id: 't_esc_adm', laneId: 'sys', type: 'task', marker: 'service', label: 'Eskalasi Otomatis ke\nPanel Resolusi Konflik', cx: 880, cy: 185 },
      { id: 'd10_disp', laneId: 'sys', type: 'datastore', label: 'D10: Komplain\n& Retur', cx: 740, cy: 82 },
      { id: 'd13_chat', laneId: 'sys', type: 'datastore', label: 'D13: Chat\nPermanen', cx: 880, cy: 315 },

      // --- Panel Resolusi Konflik & Alur Retur (FR-010) ---
      { id: 't_adm_rev', laneId: 'admin_cs', type: 'task', marker: 'user', label: 'Tinjau Bukti, Polis Asuransi,\nRiwayat Chat & Tracking', cx: 880, cy: 74 },
      { id: 'g_need_ret', laneId: 'admin_cs', type: 'gateway', gwType: 'exclusive', label: 'Perlu\nRetur?', cx: 1030, cy: 74 },

      { id: 't_ret_wait', laneId: 'sys', type: 'task', marker: 'send', label: 'Set Menunggu Pengembalian\n& Notif WA (3x24j)', cx: 1055, cy: 185 },
      { id: 'g_ev_ret3', laneId: 'sys', type: 'gateway', gwType: 'event', label: '', cx: 1215, cy: 185 },
      { id: 'ic_ret_to', laneId: 'sys', type: 'intermediate', symbol: 'timer', outline: 'catching', label: 'Lewat 3x24 Jam', cx: 1215, cy: 315, labelSide: 'B' },
      { id: 't_ret_drop', laneId: 'sys', type: 'task', marker: 'service', label: 'Komplain Gugur &\nTeruskan Dana Penjual', cx: 1370, cy: 315 },
      { id: 'e_ret_drop', laneId: 'sys', type: 'end', symbol: 'general', label: 'Komplain Gugur', cx: 1515, cy: 315, labelSide: 'B' },

      { id: 't_ret_ship', laneId: 'buyer', type: 'task', marker: 'user', label: 'Input Resi Retur &\nBukti Struk Ongkir', cx: 1215, cy: 74 },
      { id: 't_ret_trk', laneId: 'sys', type: 'task', marker: 'service', label: 'Lacak Retur (API Logistik)\n-> Terkirim & Notif 2x24j', cx: 1385, cy: 185 },
      { id: 'g_ev_ret2', laneId: 'sys', type: 'gateway', gwType: 'event', label: '', cx: 1545, cy: 185 },
      { id: 'ic_ret2_to', laneId: 'sys', type: 'intermediate', symbol: 'timer', outline: 'catching', label: 'Lewat 2x24 Jam', cx: 1545, cy: 265, labelSide: 'L' },
      { id: 't_ret_ok', laneId: 'seller', type: 'task', marker: 'user', label: 'Konfirmasi Terima\nBarang Retur', cx: 1545, cy: 62 },
      { id: 't_ret_bantah', laneId: 'seller', type: 'task', marker: 'user', label: 'Ajukan Bantahan Retur\n(+ Video Unboxing)', cx: 1705, cy: 158 },
      { id: 't_ret_sengketa', laneId: 'admin_cs', type: 'task', marker: 'user', label: 'Tinjau Sengketa Retur &\nVideo Unboxing Bantahan', cx: 1705, cy: 74 },

      // --- Keputusan Final, Alokasi Dana & Audit Log ---
      { id: 'g_ret_m', laneId: 'admin_cs', type: 'gateway', gwType: 'exclusive', label: '', cx: 1845, cy: 74 },
      { id: 'g_fin_m', laneId: 'admin_cs', type: 'gateway', gwType: 'exclusive', label: '', cx: 1925, cy: 74 },
      { id: 't_adm_dec', laneId: 'admin_cs', type: 'task', marker: 'user', label: 'Pilih 1 dari 3 Keputusan,\nPenyebab & Alasan Wajib', cx: 2065, cy: 74 },
      { id: 't_exec_alloc', laneId: 'sys', type: 'task', marker: 'service', label: 'Alokasi Dana, Komisi Proporsional,\nAsuransi/Plafon & Ongkir Retur', cx: 2065, cy: 185 },
      { id: 'ann_dec', laneId: 'sys', type: 'annotation', label: '1. Full Refund: Salah Penjual (Bebas+Arrears) |\nBukan Penjual (Reguler) | Salah Kurir (Asuransi/Plafon)\n2. Teruskan ke Penjual  3. Partial Refund per Item', cx: 2035, cy: 315 },
      { id: 'd8_esc', laneId: 'sys', type: 'datastore', label: 'D8: Escrow', cx: 1645, cy: 315 },
      { id: 'd11_wal', laneId: 'sys', type: 'datastore', label: 'D11: Saldo &\nArrears', cx: 1765, cy: 315 },
      { id: 'g_par_fin', laneId: 'sys', type: 'gateway', gwType: 'parallel', label: '', cx: 2225, cy: 185 },
      { id: 'sp_aud_p6', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Catat Audit Log\nImmutable (FR-029)', cx: 2385, cy: 115 },
      { id: 't_not_p6', laneId: 'sys', type: 'task', marker: 'send', label: 'Kirim Notif Keputusan Final\n(In-App & WA)', cx: 2385, cy: 255 },
      { id: 'd16_not', laneId: 'sys', type: 'datastore', label: 'D16: Notif &\nAudit Log', cx: 2525, cy: 115 },
      { id: 'g_par_join', laneId: 'sys', type: 'gateway', gwType: 'parallel', label: '', cx: 2525, cy: 255 },
      { id: 'e_done_p6', laneId: 'sys', type: 'end', symbol: 'general', label: 'Komplain / Retur\nSelesai', cx: 2645, cy: 255, labelSide: 'R' }
    ],
    edges: [
      { src: 's_comp', dst: 't_comp_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_comp_in', dst: 'do_unbox', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_comp_in', dst: 't_comp_hold', srcSide: 'R', dstSide: 'T' },
      { src: 't_comp_hold', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Mediasi 1x24j' },
      { src: 't_comp_hold', dst: 'g_ev_med', srcSide: 'R', dstSide: 'L' },

      { src: 'g_ev_med', dst: 't_med_acc', srcSide: 'T', dstSide: 'B' },
      { src: 't_med_acc', dst: 't_med_exec', srcSide: 'R', dstSide: 'T' },
      { src: 't_med_exec', dst: 'e_med_ok', srcSide: 'B', dstSide: 'T' },

      { src: 'g_ev_med', dst: 't_med_rej', srcSide: 'R', dstSide: 'B' },
      { src: 'g_ev_med', dst: 'ic_med_to', srcSide: 'B', dstSide: 'T' },
      { src: 't_med_rej', dst: 'g_esc_m', srcSide: 'R', dstSide: 'T' },
      { src: 'ic_med_to', dst: 'g_esc_m', srcSide: 'R', dstSide: 'L' },
      { src: 's_fail_dlv', dst: 'g_esc_m', srcSide: 'T', dstSide: 'B' },

      { src: 'g_esc_m', dst: 't_esc_adm', srcSide: 'R', dstSide: 'L' },
      { src: 'd10_disp', dst: 't_esc_adm', srcSide: 'R', dstSide: 'T', kind: 'data' },
      { src: 'd13_chat', dst: 't_esc_adm', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_esc_adm', dst: 't_adm_rev', srcSide: 'T', dstSide: 'B' },
      { src: 't_adm_rev', dst: 'g_need_ret', srcSide: 'R', dstSide: 'L' },
      { src: 'g_need_ret', dst: 'g_fin_m', srcSide: 'T', dstSide: 'T', label: 'Tanpa Retur' },
      { src: 'g_need_ret', dst: 't_ret_wait', srcSide: 'B', dstSide: 'T', label: 'Perlu Retur' },

      { src: 't_ret_wait', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'WA Instruksi Retur' },
      { src: 't_ret_wait', dst: 'g_ev_ret3', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ev_ret3', dst: 'ic_ret_to', srcSide: 'B', dstSide: 'T' },
      { src: 'ic_ret_to', dst: 't_ret_drop', srcSide: 'R', dstSide: 'L' },
      { src: 't_ret_drop', dst: 'e_ret_drop', srcSide: 'R', dstSide: 'L' },

      { src: 'g_ev_ret3', dst: 't_ret_ship', srcSide: 'T', dstSide: 'B' },
      { src: 't_ret_ship', dst: 't_ret_trk', srcSide: 'R', dstSide: 'T' },
      { src: 't_ret_trk', dst: 'ext_log', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Lacak Resi Retur' },
      { src: 't_ret_trk', dst: 'g_ev_ret2', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ev_ret2', dst: 'ic_ret2_to', srcSide: 'B', dstSide: 'T' },
      { src: 'g_ev_ret2', dst: 't_ret_ok', srcSide: 'T', dstSide: 'B' },
      { src: 'g_ev_ret2', dst: 't_ret_bantah', srcSide: 'R', dstSide: 'B' },
      { src: 't_ret_ok', dst: 'g_ret_m', srcSide: 'R', dstSide: 'T' },
      { src: 'ic_ret2_to', dst: 'g_ret_m', srcSide: 'R', dstSide: 'B' },
      { src: 't_ret_bantah', dst: 't_ret_sengketa', srcSide: 'T', dstSide: 'B' },
      { src: 't_ret_sengketa', dst: 'g_ret_m', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ret_m', dst: 'g_fin_m', srcSide: 'R', dstSide: 'L' },

      { src: 'g_fin_m', dst: 't_adm_dec', srcSide: 'R', dstSide: 'L' },
      { src: 't_adm_dec', dst: 't_exec_alloc', srcSide: 'B', dstSide: 'T' },
      { src: 't_exec_alloc', dst: 'ann_dec', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_exec_alloc', dst: 'd8_esc', srcSide: 'L', dstSide: 'T', kind: 'data' },
      { src: 't_exec_alloc', dst: 'd11_wal', srcSide: 'L', dstSide: 'T', kind: 'data' },

      { src: 't_exec_alloc', dst: 'g_par_fin', srcSide: 'R', dstSide: 'L' },
      { src: 'g_par_fin', dst: 'sp_aud_p6', srcSide: 'T', dstSide: 'L' },
      { src: 'g_par_fin', dst: 't_not_p6', srcSide: 'B', dstSide: 'L' },
      { src: 'sp_aud_p6', dst: 'd16_not', srcSide: 'R', dstSide: 'L', kind: 'data' },
      { src: 't_not_p6', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'In-App & WA Final' },
      { src: 'sp_aud_p6', dst: 'g_par_join', srcSide: 'B', dstSide: 'T' },
      { src: 't_not_p6', dst: 'g_par_join', srcSide: 'R', dstSide: 'L' },
      { src: 'g_par_join', dst: 'e_done_p6', srcSide: 'R', dstSide: 'L' }
    ]
  },

  // =========================================================================
  // HALAMAN 07: DOMPET SALDO, PENARIKAN & TUNGGAKAN
  // =========================================================================
  {
    id: 'p7',
    name: '07. Dompet, Withdrawal & Tunggakan',
    pngName: '07- BPMN Dompet Saldo, Penarikan & Tunggakan.drawio.png',
    lanes: [
      { id: 'buyer', label: 'Pembeli', height: 155 },
      { id: 'seller', label: 'Penjual UMKM', height: 210 },
      { id: 'super', label: 'Super Admin', height: 215 },
      { id: 'sys', label: 'Sistem MyPeken', height: 470, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_pg', label: 'Payment Gateway\n(Inquiry & Disbursement)', cx: 740, w: 225 },
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 1380, w: 220 }
    ],
    nodes: [
      // --- Cluster 1: Penarikan Saldo Saya Pembeli (FR-025, INV-06) ---
      { id: 's_bwd', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Buka Saldo Saya\n(Bebas & Reguler)', cx: 45, cy: 76, labelSide: 'B' },
      { id: 't_bwd_in', laneId: 'buyer', type: 'task', marker: 'user', label: 'Pilih Bank, Input\nRekening & Nominal', cx: 195, cy: 76 },
      { id: 't_bwd_inq', laneId: 'sys', type: 'task', marker: 'service', label: 'Bank Account Inquiry\nAPI Payment Gateway', cx: 195, cy: 78 },
      { id: 'g_bwd_v', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Valid?', cx: 345, cy: 78 },
      { id: 'e_bwd_no', laneId: 'sys', type: 'end', symbol: 'error', label: 'Rekening\nTidak Valid', cx: 345, cy: 195, labelSide: 'B' },
      { id: 't_bwd_conf', laneId: 'buyer', type: 'task', marker: 'user', label: 'Centang Nama Pemilik\n& Input PIN Saldo 6 Digit', cx: 545, cy: 76 },
      { id: 't_bwd_rule', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Sub-Bucket (Bebas Rp0\nvs Reguler Min 20rb+Biaya)', cx: 545, cy: 78 },
      { id: 'sp_bwd_otp', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Verifikasi OTP\nMulti-Saluran (INV-02)', cx: 745, cy: 78 },
      { id: 't_bwd_disb', laneId: 'sys', type: 'task', marker: 'service', label: 'Kunci Saldo Pending &\nKirim Disbursement API', cx: 940, cy: 78 },
      { id: 'g_bwd_wh', laneId: 'sys', type: 'gateway', gwType: 'event', label: 'Webhook\nPG', cx: 1085, cy: 78 },
      { id: 'ic_bwd_ok', laneId: 'sys', type: 'intermediate', symbol: 'message', outline: 'catching', label: 'Berhasil', cx: 1215, cy: 48, labelSide: 'T' },
      { id: 'e_bwd_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Penarikan\nBerhasil', cx: 1345, cy: 48, labelSide: 'R' },
      { id: 'ic_bwd_err', laneId: 'sys', type: 'intermediate', symbol: 'message', outline: 'catching', label: 'Gagal', cx: 1215, cy: 132, labelSide: 'B' },
      { id: 't_bwd_ret', laneId: 'sys', type: 'task', marker: 'service', label: 'Kembalikan 100% ke\nSub-Bucket Asal & Notif', cx: 1375, cy: 132 },
      { id: 'e_bwd_fail', laneId: 'sys', type: 'end', symbol: 'general', label: 'Saldo\nDikembalikan', cx: 1515, cy: 132, labelSide: 'R' },

      // --- Cluster 2: Saldo Toko, Pelunasan Tunggakan & Withdrawal Penjual (FR-015) ---
      { id: 's_swd', laneId: 'seller', type: 'start', symbol: 'general', label: 'Buka Saldo Toko\n& Riwayat Mutasi', cx: 1495, cy: 105, labelSide: 'L' },
      { id: 'g_has_arr', laneId: 'seller', type: 'gateway', gwType: 'exclusive', label: 'Tunggakan\n> Rp0?', cx: 1635, cy: 105 },
      { id: 't_pay_arr', laneId: 'seller', type: 'task', marker: 'user', label: 'Tekan Bayar Tunggakan\nvia PG (WD Dikunci)', cx: 1805, cy: 52 },
      { id: 't_arr_exec', laneId: 'sys', type: 'task', marker: 'service', label: 'Proses Bayar PG / Auto-Potong\n& Cabut Auto-Suspend', cx: 1805, cy: 255 },
      { id: 'e_arr_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Tunggakan\nLunas', cx: 1975, cy: 255, labelSide: 'R' },

      { id: 't_swd_req', laneId: 'seller', type: 'task', marker: 'user', label: 'Tarik Saldo (>=Rp50rb ke\nRek KYC) & Input PIN', cx: 1805, cy: 155 },
      { id: 'sp_swd_otp', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Verifikasi OTP Multi-Saluran\n& Kunci Saldo Pending', cx: 1605, cy: 365 },
      { id: 't_swd_disb', laneId: 'sys', type: 'task', marker: 'service', label: 'Kirim Disbursement API\n& Tunggu Webhook PG', cx: 1805, cy: 365 },
      { id: 't_swd_wh', laneId: 'sys', type: 'task', marker: 'service', label: 'Update Mutasi Berhasil /\nRefund 100% Jika Gagal', cx: 2005, cy: 365 },
      { id: 'e_swd_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Withdrawal\nToko Selesai', cx: 2155, cy: 365, labelSide: 'B' },

      // --- Cluster 3: Scheduler Mitigasi Tunggakan (INV-07) ---
      { id: 's_sched', laneId: 'sys', type: 'start', symbol: 'timer', label: 'Scheduler Harian\nTunggakan (INV-07)', cx: 45, cy: 345, labelSide: 'B' },
      { id: 't_chk_arr', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Limit Rp250rb &\nUmur (H-3/H-1 / 14h / 30h)', cx: 215, cy: 345 },
      { id: 'g_arr_lvl', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 365, cy: 345 },
      { id: 't_flag_bl', laneId: 'sys', type: 'task', marker: 'service', label: 'Tandai Siap Blacklist\n(>30 Hari Terlantar)', cx: 545, cy: 265 },
      { id: 'e_flag_bl', laneId: 'sys', type: 'end', symbol: 'escalation', label: 'Ke Blacklist\n(Proses 8.0)', cx: 705, cy: 265, labelSide: 'R' },
      { id: 't_auto_susp', laneId: 'sys', type: 'task', marker: 'service', label: 'Auto-Suspend Toko\n(>Rp250rb atau >14h)', cx: 545, cy: 345 },
      { id: 'e_auto_susp', laneId: 'sys', type: 'end', symbol: 'general', label: 'Toko\nAuto-Suspend', cx: 705, cy: 345, labelSide: 'R' },
      { id: 't_arr_rem', laneId: 'sys', type: 'task', marker: 'send', label: 'Kirim Pengingat H-3 / H-1\n(In-App & WA/Email)', cx: 545, cy: 425 },
      { id: 'e_arr_rem', laneId: 'sys', type: 'end', symbol: 'general', label: 'Pengingat\nTerkirim', cx: 705, cy: 425, labelSide: 'R' },

      // --- Cluster 4: Monitoring & Hold Saldo Super Admin (FR-019) ---
      { id: 's_mon', laneId: 'super', type: 'start', symbol: 'general', label: 'Monitoring\nSaldo & Hold', cx: 1985, cy: 56, labelSide: 'L' },
      { id: 't_mon_view', laneId: 'super', type: 'task', marker: 'user', label: 'Pantau Riwayat WD (Webhook)\n& Daftar Saldo Tertunggak', cx: 2155, cy: 56 },
      { id: 'g_hold_act', laneId: 'super', type: 'gateway', gwType: 'exclusive', label: 'Hold?', cx: 2315, cy: 56 },
      { id: 'e_mon_ok', laneId: 'super', type: 'end', symbol: 'general', label: 'Selesai\nPantau', cx: 2455, cy: 56, labelSide: 'R' },
      { id: 't_hold_in', laneId: 'super', type: 'task', marker: 'user', label: 'Tahan / Perpanjang (<=14h)\n/ Lepas Saldo + Alasan', cx: 2315, cy: 158 },
      { id: 't_hold_sys', laneId: 'sys', type: 'task', marker: 'service', label: 'Update Saldo Ditahan &\nNotif Banding Penjual', cx: 2315, cy: 255 },
      { id: 'sp_aud_p7', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Catat Audit Log\nImmutable (FR-029)', cx: 2315, cy: 365 },
      { id: 'e_hold_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Status Hold\nTersimpan', cx: 2475, cy: 365, labelSide: 'R' },

      // Data Stores clustered cleanly
      { id: 'd1_pin', laneId: 'sys', type: 'datastore', label: 'D1: PIN &\nKontak', cx: 940, cy: 235 },
      { id: 'd11_mut', laneId: 'sys', type: 'datastore', label: 'D11: Mutasi,\nWD & Hold', cx: 1125, cy: 265 },
      { id: 'd3_st', laneId: 'sys', type: 'datastore', label: 'D3: Toko &\nStatus', cx: 940, cy: 365 },
      { id: 'd16_aud', laneId: 'sys', type: 'datastore', label: 'D16: Notif &\nAudit Log', cx: 1375, cy: 265 }
    ],
    edges: [
      // Cluster 1: Buyer WD
      { src: 's_bwd', dst: 't_bwd_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_bwd_in', dst: 't_bwd_inq', srcSide: 'B', dstSide: 'T' },
      { src: 't_bwd_inq', dst: 'ext_pg', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Bank Account Inquiry' },
      { src: 't_bwd_inq', dst: 'g_bwd_v', srcSide: 'R', dstSide: 'L' },
      { src: 'g_bwd_v', dst: 'e_bwd_no', srcSide: 'B', dstSide: 'T', label: 'Tidak Valid' },
      { src: 'g_bwd_v', dst: 't_bwd_conf', srcSide: 'T', dstSide: 'B', label: 'Cocok' },
      { src: 't_bwd_conf', dst: 't_bwd_rule', srcSide: 'B', dstSide: 'T' },
      { src: 'd1_pin', dst: 't_bwd_rule', srcSide: 'L', dstSide: 'B', kind: 'data' },
      { src: 't_bwd_rule', dst: 'sp_bwd_otp', srcSide: 'R', dstSide: 'L' },
      { src: 'sp_bwd_otp', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'OTP Multi-Saluran' },
      { src: 'sp_bwd_otp', dst: 't_bwd_disb', srcSide: 'R', dstSide: 'L' },
      { src: 't_bwd_disb', dst: 'ext_pg', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Disbursement API' },
      { src: 't_bwd_disb', dst: 'g_bwd_wh', srcSide: 'R', dstSide: 'L' },
      { src: 'g_bwd_wh', dst: 'ic_bwd_ok', srcSide: 'T', dstSide: 'L' },
      { src: 'ic_bwd_ok', dst: 'e_bwd_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_bwd_wh', dst: 'ic_bwd_err', srcSide: 'B', dstSide: 'L' },
      { src: 'ic_bwd_err', dst: 't_bwd_ret', srcSide: 'R', dstSide: 'L' },
      { src: 't_bwd_ret', dst: 'd11_mut', srcSide: 'B', dstSide: 'R', kind: 'data' },
      { src: 't_bwd_ret', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Gagal' },
      { src: 't_bwd_ret', dst: 'e_bwd_fail', srcSide: 'R', dstSide: 'L' },

      // Cluster 2: Seller Saldo & WD
      { src: 's_swd', dst: 'g_has_arr', srcSide: 'R', dstSide: 'L' },
      { src: 'g_has_arr', dst: 't_pay_arr', srcSide: 'T', dstSide: 'L', label: 'Ya (>Rp0)' },
      { src: 't_pay_arr', dst: 't_arr_exec', srcSide: 'B', dstSide: 'T' },
      { src: 't_arr_exec', dst: 'ext_pg', srcSide: 'L', dstSide: 'T', kind: 'message', label: 'Bayar Tunggakan' },
      { src: 't_arr_exec', dst: 'e_arr_ok', srcSide: 'R', dstSide: 'L' },

      { src: 'g_has_arr', dst: 't_swd_req', srcSide: 'B', dstSide: 'L', label: 'Bebas' },
      { src: 't_swd_req', dst: 'sp_swd_otp', srcSide: 'B', dstSide: 'T' },
      { src: 'sp_swd_otp', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'OTP Withdrawal' },
      { src: 'sp_swd_otp', dst: 't_swd_disb', srcSide: 'R', dstSide: 'L' },
      { src: 't_swd_disb', dst: 'ext_pg', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Disbursement Toko' },
      { src: 't_swd_disb', dst: 't_swd_wh', srcSide: 'R', dstSide: 'L' },
      { src: 't_swd_wh', dst: 'e_swd_ok', srcSide: 'R', dstSide: 'L' },

      // Cluster 3: Scheduler INV-07
      { src: 's_sched', dst: 't_chk_arr', srcSide: 'R', dstSide: 'L' },
      { src: 'd3_st', dst: 't_chk_arr', srcSide: 'L', dstSide: 'B', kind: 'data' },
      { src: 't_chk_arr', dst: 'g_arr_lvl', srcSide: 'R', dstSide: 'L' },
      { src: 'g_arr_lvl', dst: 't_flag_bl', srcSide: 'T', dstSide: 'L', label: '>30 Hari' },
      { src: 't_flag_bl', dst: 'e_flag_bl', srcSide: 'R', dstSide: 'L' },
      { src: 'g_arr_lvl', dst: 't_auto_susp', srcSide: 'R', dstSide: 'L', label: '>250rb / >14h' },
      { src: 't_auto_susp', dst: 'e_auto_susp', srcSide: 'R', dstSide: 'L' },
      { src: 'g_arr_lvl', dst: 't_arr_rem', srcSide: 'B', dstSide: 'L', label: 'H-3 / H-1' },
      { src: 't_arr_rem', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Pengingat Tunggakan' },
      { src: 't_arr_rem', dst: 'e_arr_rem', srcSide: 'R', dstSide: 'L' },

      // Cluster 4: Monitoring & Hold
      { src: 's_mon', dst: 't_mon_view', srcSide: 'R', dstSide: 'L' },
      { src: 't_mon_view', dst: 'g_hold_act', srcSide: 'R', dstSide: 'L' },
      { src: 'g_hold_act', dst: 'e_mon_ok', srcSide: 'R', dstSide: 'L', label: 'Pantau' },
      { src: 'g_hold_act', dst: 't_hold_in', srcSide: 'B', dstSide: 'T', label: 'Tahan/Lepas' },
      { src: 't_hold_in', dst: 't_hold_sys', srcSide: 'B', dstSide: 'T' },
      { src: 't_hold_sys', dst: 'd16_aud', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 't_hold_sys', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Hold & Banding' },
      { src: 't_hold_sys', dst: 'sp_aud_p7', srcSide: 'B', dstSide: 'T' },
      { src: 'sp_aud_p7', dst: 'e_hold_ok', srcSide: 'R', dstSide: 'L' }
    ]
  },

  // =========================================================================
  // HALAMAN 08: ADMINISTRASI PLATFORM, MODERASI & LAPORAN
  // =========================================================================
  {
    id: 'p8',
    name: '08. Admin, Moderasi & Laporan',
    pngName: '08- BPMN Administrasi Platform, Moderasi & Laporan.drawio.png',
    lanes: [
      { id: 'seller', label: 'Penjual UMKM', height: 135 },
      { id: 'ops', label: 'Admin Operasional / KYC', height: 195 },
      { id: 'super', label: 'Super Admin', height: 195 },
      { id: 'sys', label: 'Sistem MyPeken', height: 480, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 1135, w: 220 }
    ],
    nodes: [
      // --- Cluster 1: Statistik Penjualan Toko (FR-006) ---
      { id: 's_stat', laneId: 'seller', type: 'start', symbol: 'general', label: 'Buka Statistik\nPenjualan', cx: 45, cy: 66, labelSide: 'B' },
      { id: 't_stat_flt', laneId: 'seller', type: 'task', marker: 'user', label: 'Pilih Filter Harian /\nMingguan / Bulanan', cx: 190, cy: 66 },
      { id: 't_stat_agg', laneId: 'sys', type: 'task', marker: 'service', label: 'Agregasi Grafik, Selesai/Batal\n& Top 5 Produk Toko', cx: 190, cy: 80 },
      { id: 't_stat_view', laneId: 'seller', type: 'task', marker: 'user', label: 'Lihat Dashboard\nPerforma Toko', cx: 360, cy: 66 },
      { id: 'e_stat_ok', laneId: 'seller', type: 'end', symbol: 'general', label: 'Selesai', cx: 495, cy: 66, labelSide: 'R' },

      // --- Cluster 2: Moderasi & Laporan Pelanggaran (FR-018) - 2x2 Grid Organik ---
      { id: 's_mod', laneId: 'ops', type: 'start', symbol: 'general', label: 'Tinjau Antrean\nAbuse / Master', cx: 45, cy: 95, labelSide: 'B' },
      { id: 't_mod_pick', laneId: 'ops', type: 'task', marker: 'user', label: 'Pilih Target, Aksi Moderasi\n& Isi Alasan Wajib', cx: 215, cy: 95 },
      { id: 'g_mod_1', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 415, cy: 205 },
      { id: 'g_mod_2', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 415, cy: 335 },

      { id: 't_mod_rev', laneId: 'sys', type: 'task', marker: 'service', label: 'Hapus Produk / Sembunyikan\nUlasan & Hitung Rating', cx: 615, cy: 78 },
      { id: 'd9_r', laneId: 'sys', type: 'datastore', label: 'D9: Ulasan', cx: 615, cy: 175 },
      { id: 't_mod_toko', laneId: 'sys', type: 'task', marker: 'service', label: 'Suspend Toko (Sembunyi\nEtalase, Blokir Order Baru)', cx: 615, cy: 270 },
      { id: 'd3_t', laneId: 'sys', type: 'datastore', label: 'D3: Toko', cx: 615, cy: 395 },

      { id: 't_mod_akun', laneId: 'sys', type: 'task', marker: 'service', label: 'Suspend Akun (Blokir Login,\nAuto-Batal, Refund & Hold)', cx: 835, cy: 155 },
      { id: 'd1_u', laneId: 'sys', type: 'datastore', label: 'D1: User', cx: 835, cy: 65 },
      { id: 't_mod_bl', laneId: 'sys', type: 'task', marker: 'service', label: 'Blacklist NIK KTP &\nRekening (>30h) / Tolak', cx: 835, cy: 295 },
      { id: 'd15_b', laneId: 'sys', type: 'datastore', label: 'D15: Abuse/BL', cx: 835, cy: 395 },

      { id: 'g_mod_m1', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 995, cy: 155 },
      { id: 'g_mod_m2', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '', cx: 995, cy: 275 },
      { id: 't_mod_not', laneId: 'sys', type: 'task', marker: 'send', label: 'Set Selesai Ditinjau &\nKirim Notif Pelapor/Pemilik', cx: 1135, cy: 215 },
      { id: 'sp_aud_mod', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Catat Audit Log\nImmutable (FR-029)', cx: 1315, cy: 215 },
      { id: 'e_mod_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Moderasi\nSelesai', cx: 1435, cy: 215, labelSide: 'T' },

      // --- Cluster 3: Kategori 2-Level, Banner & Biaya/Komisi (FR-034, FR-009) ---
      { id: 's_cat', laneId: 'ops', type: 'start', symbol: 'general', label: 'Kelola Kategori\n& Banner', cx: 1020, cy: 95, labelSide: 'L' },
      { id: 't_cat_in', laneId: 'ops', type: 'task', marker: 'user', label: 'CRUD Kategori 2-Level\natau Banner (Maks 5 Aktif)', cx: 1195, cy: 95 },
      { id: 't_cat_sys', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Produk Aktif, Warisi\nTarif Default & Sinkron', cx: 1195, cy: 78 },
      { id: 'e_cat_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Kategori / Banner\nTersinkron', cx: 1365, cy: 78, labelSide: 'R' },

      { id: 's_fee', laneId: 'super', type: 'start', symbol: 'general', label: 'Atur Biaya &\nKomisi (FR-009)', cx: 1415, cy: 95, labelSide: 'L' },
      { id: 't_fee_in', laneId: 'super', type: 'task', marker: 'user', label: 'Atur Layanan Flat, Admin PPOB\n& Komisi (>=1%) + Alasan', cx: 1595, cy: 95 },
      { id: 't_fee_sys', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi >=1% & Simpan\nRate Snapshot Order Baru', cx: 1595, cy: 175 },
      { id: 'sp_aud_fee', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Catat Audit Log\nImmutable (FR-029)', cx: 1595, cy: 285 },
      { id: 'e_fee_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Tarif Baru\nAktif', cx: 1745, cy: 285, labelSide: 'R' },

      // --- Cluster 4: Dashboard Keuangan, Rekonsiliasi & Audit Log (FR-041, FR-029) ---
      { id: 's_fin', laneId: 'super', type: 'start', symbol: 'general', label: 'Keuangan &\nAudit Log', cx: 1815, cy: 95, labelSide: 'L' },
      { id: 'g_fin_menu', laneId: 'super', type: 'gateway', gwType: 'exclusive', label: 'Menu?', cx: 1935, cy: 95 },
      { id: 't_aud_read', laneId: 'super', type: 'task', marker: 'user', label: 'Filter & Baca Audit Log\nImmutable (Read-Only)', cx: 2115, cy: 50 },
      { id: 'e_aud_ok', laneId: 'super', type: 'end', symbol: 'general', label: 'Selesai Baca\nAudit Log', cx: 2275, cy: 50, labelSide: 'R' },

      { id: 't_fin_flt', laneId: 'super', type: 'task', marker: 'user', label: 'Pilih Periode & Jenis\n(Semua / Fisik / PPOB)', cx: 2115, cy: 142 },
      { id: 't_fin_agg', laneId: 'sys', type: 'task', marker: 'service', label: 'Hitung GMV, Pendapatan Bersih,\nLiabilitas & Top 5 UMKM', cx: 2115, cy: 175 },
      { id: 't_fin_exp', laneId: 'super', type: 'task', marker: 'user', label: 'Tinjau Rekonsiliasi &\nEkspor Laporan (XLSX/PDF)', cx: 2315, cy: 142 },
      { id: 'do_fin', laneId: 'super', type: 'dataobject', label: 'Laporan Keuangan\n& Rekonsiliasi', cx: 2475, cy: 142 },
      { id: 'sp_aud_exp', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Generate Berkas & Catat\nAudit Log Ekspor (FR-029)', cx: 2315, cy: 365 },
      { id: 'e_fin_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Laporan\nDiekspor', cx: 2475, cy: 365, labelSide: 'R' },

      // --- Data Stores ---
      { id: 'd5_p', laneId: 'sys', type: 'datastore', label: 'D5: Produk', cx: 190, cy: 235 },
      { id: 'd4_f', laneId: 'sys', type: 'datastore', label: 'D4: Kat/Tarif', cx: 1195, cy: 395 },
      { id: 'd16_l', laneId: 'sys', type: 'datastore', label: 'D16: Notif &\nAudit Log', cx: 1595, cy: 395 },
      { id: 'd7_o', laneId: 'sys', type: 'datastore', label: 'D7: Pesanan', cx: 1935, cy: 295 },
      { id: 'd8_e', laneId: 'sys', type: 'datastore', label: 'D8: Escrow', cx: 2055, cy: 295 },
      { id: 'd11_s', laneId: 'sys', type: 'datastore', label: 'D11: Saldo', cx: 2175, cy: 295 }
    ],
    edges: [
      // Cluster 1: Statistik Toko
      { src: 's_stat', dst: 't_stat_flt', srcSide: 'R', dstSide: 'L' },
      { src: 't_stat_flt', dst: 't_stat_agg', srcSide: 'B', dstSide: 'T' },
      { src: 'd5_p', dst: 't_stat_agg', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_stat_agg', dst: 't_stat_view', srcSide: 'R', dstSide: 'B' },
      { src: 't_stat_view', dst: 'e_stat_ok', srcSide: 'R', dstSide: 'L' },

      // Cluster 2: Moderasi
      { src: 's_mod', dst: 't_mod_pick', srcSide: 'R', dstSide: 'L' },
      { src: 't_mod_pick', dst: 'g_mod_1', srcSide: 'B', dstSide: 'L' },
      { src: 'g_mod_1', dst: 't_mod_rev', srcSide: 'T', dstSide: 'L', label: 'Prod/Ulas' },
      { src: 'g_mod_1', dst: 't_mod_toko', srcSide: 'R', dstSide: 'L', label: 'Susp Toko' },
      { src: 'g_mod_1', dst: 'g_mod_2', srcSide: 'B', dstSide: 'T' },
      { src: 'g_mod_2', dst: 't_mod_akun', srcSide: 'R', dstSide: 'L', label: 'Susp Akun' },
      { src: 'g_mod_2', dst: 't_mod_bl', srcSide: 'B', dstSide: 'L', label: 'BL / Tolak' },

      { src: 't_mod_rev', dst: 'g_mod_m1', srcSide: 'R', dstSide: 'T' },
      { src: 't_mod_toko', dst: 'g_mod_m1', srcSide: 'R', dstSide: 'B' },
      { src: 't_mod_akun', dst: 'g_mod_m2', srcSide: 'R', dstSide: 'T' },
      { src: 't_mod_bl', dst: 'g_mod_m2', srcSide: 'R', dstSide: 'B' },
      { src: 'g_mod_m1', dst: 't_mod_not', srcSide: 'R', dstSide: 'T' },
      { src: 'g_mod_m2', dst: 't_mod_not', srcSide: 'R', dstSide: 'B' },
      { src: 'd1_u', dst: 't_mod_akun', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'd3_t', dst: 't_mod_toko', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'd9_r', dst: 't_mod_rev', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd15_b', dst: 't_mod_bl', srcSide: 'T', dstSide: 'B', kind: 'data' },

      { src: 't_mod_not', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Moderasi' },
      { src: 't_mod_not', dst: 'sp_aud_mod', srcSide: 'R', dstSide: 'L' },
      { src: 'sp_aud_mod', dst: 'd16_l', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'sp_aud_mod', dst: 'e_mod_ok', srcSide: 'R', dstSide: 'L' },

      // Cluster 3: Kategori/Banner & Biaya/Komisi
      { src: 's_cat', dst: 't_cat_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_cat_in', dst: 't_cat_sys', srcSide: 'B', dstSide: 'T' },
      { src: 't_cat_sys', dst: 'd4_f', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_cat_sys', dst: 'e_cat_ok', srcSide: 'R', dstSide: 'L' },

      { src: 's_fee', dst: 't_fee_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_fee_in', dst: 't_fee_sys', srcSide: 'B', dstSide: 'T' },
      { src: 't_fee_sys', dst: 'd4_f', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 't_fee_sys', dst: 'sp_aud_fee', srcSide: 'B', dstSide: 'T' },
      { src: 'sp_aud_fee', dst: 'd16_l', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'sp_aud_fee', dst: 'e_fee_ok', srcSide: 'R', dstSide: 'L' },

      // Cluster 4: Keuangan & Audit Log
      { src: 's_fin', dst: 'g_fin_menu', srcSide: 'R', dstSide: 'L' },
      { src: 'g_fin_menu', dst: 't_aud_read', srcSide: 'T', dstSide: 'L', label: 'Audit Log' },
      { src: 'd16_l', dst: 't_aud_read', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_aud_read', dst: 'e_aud_ok', srcSide: 'R', dstSide: 'L' },

      { src: 'g_fin_menu', dst: 't_fin_flt', srcSide: 'B', dstSide: 'L', label: 'Keuangan' },
      { src: 't_fin_flt', dst: 't_fin_agg', srcSide: 'B', dstSide: 'T' },
      { src: 'd7_o', dst: 't_fin_agg', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd8_e', dst: 't_fin_agg', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd11_s', dst: 't_fin_agg', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_fin_agg', dst: 't_fin_exp', srcSide: 'R', dstSide: 'B' },
      { src: 't_fin_exp', dst: 'do_fin', srcSide: 'R', dstSide: 'L', kind: 'data' },
      { src: 't_fin_exp', dst: 'sp_aud_exp', srcSide: 'B', dstSide: 'T' },
      { src: 'sp_aud_exp', dst: 'd16_l', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 'sp_aud_exp', dst: 'e_fin_ok', srcSide: 'R', dstSide: 'L' }
    ]
  }
];

module.exports = PAGES_5_8;
