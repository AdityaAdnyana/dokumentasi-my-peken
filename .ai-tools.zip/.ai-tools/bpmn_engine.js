const fs = require('fs');
const path = require('path');
const lib = require('./diagram_lib');
const { routeClusterEdges } = require('./cluster_router');
const { renderDrawioXmlToPng } = require('./render_mxfile_chrome');

function estimateTaskBox(label, marker, isSub) {
  const lines = String(label || '').split('\n');
  let maxLen = 0;
  for (const l of lines) maxLen = Math.max(maxLen, l.length);
  const w = Math.max(128, Math.min(220, Math.ceil(maxLen * 5.9 + 24)));
  const padTop = (marker && marker !== 'abstract' && marker !== 'none') ? 17 : 6;
  const padBot = isSub ? 15 : 6;
  const h = Math.max(54, Math.ceil(lines.length * 13.2 + padTop + padBot));
  return { w, h };
}

function estimateAnnotationBox(label) {
  const lines = String(label || '').split('\n');
  let maxLen = 0;
  for (const l of lines) maxLen = Math.max(maxLen, l.length);
  return {
    w: Math.max(120, Math.min(250, Math.ceil(maxLen * 5.3 + 20))),
    h: Math.max(36, Math.ceil(lines.length * 12.2 + 12))
  };
}

function estimateDataObjectBox(label) {
  const lines = String(label || '').split('\n');
  let maxLen = 0;
  for (const l of lines) maxLen = Math.max(maxLen, l.length);
  return {
    w: Math.max(88, Math.min(148, Math.ceil(maxLen * 5.4 + 20))),
    h: Math.max(46, Math.ceil(lines.length * 12 + 16))
  };
}

function estimateDataStoreBox(label) {
  const lines = String(label || '').split('\n');
  let maxLen = 0;
  for (const l of lines) maxLen = Math.max(maxLen, l.length);
  return {
    w: Math.max(76, Math.min(130, Math.ceil(maxLen * 5.2 + 16))),
    h: Math.max(52, Math.ceil(lines.length * 11.5 + 24))
  };
}

function estimateExtLabelRect(node, side) {
  if (!node.label) return null;
  const lines = String(node.label).split('\n');
  let maxLen = 0;
  for (const l of lines) maxLen = Math.max(maxLen, l.length);
  const fSize = 9.5;
  const estW = Math.max(36, Math.min(210, Math.ceil(maxLen * fSize * 0.56 + 10)));
  const estH = Math.ceil(lines.length * (fSize * 1.24) + 6);
  const cx = node.x + node.w * 0.5;
  const cy = node.y + node.h * 0.5;
  if (side === 'T') {
    return { x: cx - estW * 0.5, y: node.y - estH - 3, w: estW, h: estH, vPos: 'top', hPos: 'center', align: 'center' };
  }
  if (side === 'L') {
    return { x: node.x - estW - 4, y: cy - estH * 0.5, w: estW, h: estH, vPos: 'middle', hPos: 'left', align: 'right' };
  }
  if (side === 'R') {
    return { x: node.x + node.w + 4, y: cy - estH * 0.5, w: estW, h: estH, vPos: 'middle', hPos: 'right', align: 'left' };
  }
  return { x: cx - estW * 0.5, y: node.y + node.h + 3, w: estW, h: estH, vPos: 'bottom', hPos: 'center', align: 'center' };
}

function chooseSideToward(u, v, usedMap, allowDuplicate) {
  const ux = u.x + u.w * 0.5;
  const uy = u.y + u.h * 0.5;
  const vx = v.x + v.w * 0.5;
  const vy = v.y + v.h * 0.5;
  const dx = vx - ux;
  const dy = vy - uy;
  const len = Math.hypot(dx, dy) || 1;
  const nx = dx / len;
  const ny = dy / len;
  const vecs = { R: [1, 0], L: [-1, 0], T: [0, -1], B: [0, 1] };
  const cands = ['R', 'L', 'B', 'T'].map((s) => {
    const [sx, sy] = vecs[s];
    let score = nx * sx + ny * sy;
    if (!allowDuplicate && usedMap[s] > 0) score -= 10;
    return { s, score };
  });
  cands.sort((a, b) => b.score - a.score);
  return cands[0].s;
}

function buildNodeStyle(n, extLblMeta) {
  if (n.type === 'task') {
    const marker = n.marker || 'user';
    return `shape=mxgraph.bpmn.task2;whiteSpace=wrap;rectStyle=rounded;size=10;html=1;taskMarker=${marker};fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=10;fontFamily=Helvetica;`;
  }
  if (n.type === 'subprocess') {
    const marker = n.marker || 'abstract';
    return `shape=mxgraph.bpmn.task2;whiteSpace=wrap;rectStyle=rounded;size=10;html=1;taskMarker=${marker};bpmnShapeType=subprocess;isLoopSub=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontStyle=1;fontSize=10;fontFamily=Helvetica;`;
  }
  if (n.type === 'start') {
    const sym = n.symbol || 'general';
    const lp = extLblMeta || { vPos: 'bottom', hPos: 'center', align: 'center' };
    return `shape=mxgraph.bpmn.event;html=1;perimeter=ellipsePerimeter;aspect=fixed;outline=standard;symbol=${sym};fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9.5;fontFamily=Helvetica;verticalLabelPosition=${lp.vPos};labelPosition=${lp.hPos};verticalAlign=top;align=${lp.align};`;
  }
  if (n.type === 'intermediate' || n.type === 'boundary') {
    const sym = n.symbol || 'timer';
    const outline = n.type === 'boundary' ? 'boundInt' : (n.outline || 'catching');
    const lp = extLblMeta || { vPos: 'bottom', hPos: 'center', align: 'center' };
    return `shape=mxgraph.bpmn.event;html=1;perimeter=ellipsePerimeter;aspect=fixed;outline=${outline};symbol=${sym};fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9.5;fontFamily=Helvetica;verticalLabelPosition=${lp.vPos};labelPosition=${lp.hPos};verticalAlign=top;align=${lp.align};`;
  }
  if (n.type === 'end') {
    const sym = n.symbol || 'general';
    const lp = extLblMeta || { vPos: 'bottom', hPos: 'center', align: 'center' };
    return `shape=mxgraph.bpmn.event;html=1;perimeter=ellipsePerimeter;aspect=fixed;outline=end;symbol=${sym};fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9.5;fontFamily=Helvetica;verticalLabelPosition=${lp.vPos};labelPosition=${lp.hPos};verticalAlign=top;align=${lp.align};`;
  }
  if (n.type === 'gateway') {
    const gw = n.gwType || 'exclusive';
    const lp = extLblMeta || { vPos: 'top', hPos: 'center', align: 'center' };
    let gwPart;
    if (gw === 'inclusive') {
      gwPart = 'outline=end;symbol=general;';
    } else if (gw === 'event') {
      gwPart = 'outline=catching;symbol=multiple;';
    } else {
      gwPart = `outline=none;symbol=none;gwType=${gw};`;
    }
    return `shape=mxgraph.bpmn.gateway2;html=1;perimeter=rhombusPerimeter;${gwPart}fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9.5;fontFamily=Helvetica;verticalLabelPosition=${lp.vPos};labelPosition=${lp.hPos};verticalAlign=top;align=${lp.align};`;
  }
  if (n.type === 'datastore') {
    return `shape=datastore;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9;fontFamily=Helvetica;`;
  }
  if (n.type === 'dataobject') {
    return `shape=mxgraph.bpmn.data2;whiteSpace=wrap;html=1;size=10;fillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9;fontFamily=Helvetica;`;
  }
  if (n.type === 'annotation') {
    return `shape=partialRectangle;whiteSpace=wrap;html=1;top=1;bottom=1;left=1;right=0;fillColor=none;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontSize=9;align=left;spacingLeft=6;spacingRight=5;fontFamily=Helvetica;`;
  }
  if (n.type === 'extpool') {
    return `rounded=0;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=1.2;fontColor=#000000;fontStyle=1;fontSize=10.5;fontFamily=Helvetica;`;
  }
  return '';
}

function buildEdgeStyle(e) {
  const exitX = e.exitX ?? 0.5;
  const exitY = e.exitY ?? 0.5;
  const entryX = e.entryX ?? 0.5;
  const entryY = e.entryY ?? 0.5;
  const portPart = `exitX=${exitX};exitY=${exitY};exitDx=0;exitDy=0;entryX=${entryX};entryY=${entryY};entryDx=0;entryDy=0;`;
  if (e.kind === 'message') {
    return `edgeStyle=orthogonalEdgeStyle;rounded=1;arcSize=8;jumpStyle=arc;jumpSize=7;html=1;dashed=1;dashPattern=8 4;strokeColor=#000000;strokeWidth=1.1;startArrow=oval;startFill=0;startSize=6;endArrow=block;endFill=0;endSize=8;fontColor=#000000;fontSize=9;fontFamily=Helvetica;labelBackgroundColor=#ffffff;${portPart}`;
  }
  if (e.kind === 'data') {
    return `edgeStyle=orthogonalEdgeStyle;rounded=1;arcSize=8;jumpStyle=arc;jumpSize=7;html=1;dashed=1;dashPattern=2 3;strokeColor=#000000;strokeWidth=1;endArrow=open;endFill=0;endSize=7;fontColor=#000000;fontSize=8.5;fontFamily=Helvetica;labelBackgroundColor=#ffffff;${portPart}`;
  }
  return `edgeStyle=orthogonalEdgeStyle;rounded=1;arcSize=8;jumpStyle=arc;jumpSize=7;html=1;strokeColor=#000000;strokeWidth=1.2;endArrow=block;endFill=1;endSize=8;fontColor=#000000;fontSize=9.5;fontFamily=Helvetica;labelBackgroundColor=#ffffff;${portPart}`;
}

function compileAndAuditPage(pageDef) {
  const poolX = 24;
  const poolY = 24;
  const poolHeaderW = 34;
  const laneHeaderW = 30;
  const contentLeft = poolX + poolHeaderW + laneHeaderW + 38;

  // Compute lane Y bands from lane definitions
  const laneMap = new Map();
  let curY = poolY;
  const lanes = pageDef.lanes.map((ln) => {
    const h = ln.height || 148;
    const obj = { ...ln, x: poolX + poolHeaderW, y: curY, h };
    laneMap.set(ln.id, obj);
    curY += h;
    return obj;
  });
  const poolH = curY - poolY;

  // Size and position all intra-pool nodes
  const rawNodes = [];
  const nodeById = new Map();

  for (const spec of pageDef.nodes) {
    if (spec.type === 'boundary') continue; // placed after host
    const ln = laneMap.get(spec.laneId);
    if (!ln) throw new Error(`[${pageDef.id}] Unknown laneId "${spec.laneId}" on node "${spec.id}"`);
    let w = spec.w;
    let h = spec.h;
    if (spec.type === 'task' || spec.type === 'subprocess') {
      const sz = estimateTaskBox(spec.label, spec.marker || (spec.type === 'subprocess' ? 'abstract' : 'user'), spec.type === 'subprocess');
      w = w || sz.w;
      h = h || sz.h;
    } else if (spec.type === 'start' || spec.type === 'intermediate' || spec.type === 'end') {
      w = w || 36;
      h = h || 36;
    } else if (spec.type === 'gateway') {
      w = w || 42;
      h = h || 42;
    } else if (spec.type === 'datastore') {
      const sz = estimateDataStoreBox(spec.label);
      w = w || sz.w;
      h = h || sz.h;
    } else if (spec.type === 'dataobject') {
      const sz = estimateDataObjectBox(spec.label);
      w = w || sz.w;
      h = h || sz.h;
    } else if (spec.type === 'annotation') {
      const sz = estimateAnnotationBox(spec.label);
      w = w || sz.w;
      h = h || sz.h;
    }
    const cx = contentLeft + spec.cx;
    const cy = ln.y + spec.cy;
    const node = {
      ...spec,
      w,
      h,
      x: Math.round(cx - w * 0.5),
      y: Math.round(cy - h * 0.5),
      kind: (spec.type === 'start' || spec.type === 'intermediate' || spec.type === 'end') ? 'process' : 'rect'
    };
    rawNodes.push(node);
    nodeById.set(node.id, node);
  }

  // Place boundary events anchored on bottom edge of host tasks
  for (const spec of pageDef.nodes) {
    if (spec.type !== 'boundary') continue;
    const host = nodeById.get(spec.hostId);
    if (!host) throw new Error(`[${pageDef.id}] Unknown hostId "${spec.hostId}" on boundary "${spec.id}"`);
    const w = 32;
    const h = 32;
    const ratio = spec.posRatio ?? 0.5;
    const cx = host.x + host.w * ratio;
    const cy = host.y + host.h;
    const node = {
      ...spec,
      laneId: host.laneId,
      w,
      h,
      x: Math.round(cx - w * 0.5),
      y: Math.round(cy - h * 0.5),
      kind: 'process'
    };
    rawNodes.push(node);
    nodeById.set(node.id, node);
  }

  // Place external black-box pools below main pool
  const extPoolY = poolY + poolH + 56;
  const extPoolH = 46;
  for (const ep of pageDef.externalPools) {
    const lines = String(ep.label).split('\n');
    const maxLen = Math.max(...lines.map((l) => l.length));
    const w = ep.w || Math.max(170, Math.ceil(maxLen * 6.5 + 24));
    const cx = contentLeft + ep.cx;
    const node = {
      id: ep.id,
      type: 'extpool',
      label: ep.label,
      x: Math.round(cx - w * 0.5),
      y: extPoolY,
      w,
      h: extPoolH,
      kind: 'rect'
    };
    rawNodes.push(node);
    nodeById.set(node.id, node);
  }

  // Prepare edges & assign clean cardinal sides for Gateways/Events
  const rawEdges = pageDef.edges.map((e, idx) => ({
    ...e,
    kind: e.kind || (
      (nodeById.get(e.src)?.type === 'extpool' || nodeById.get(e.dst)?.type === 'extpool')
        ? 'message'
        : ((nodeById.get(e.src)?.type === 'datastore' || nodeById.get(e.dst)?.type === 'datastore' ||
            nodeById.get(e.src)?.type === 'dataobject' || nodeById.get(e.dst)?.type === 'dataobject' ||
            nodeById.get(e.src)?.type === 'annotation' || nodeById.get(e.dst)?.type === 'annotation')
            ? 'data' : 'sequence')
    ),
    idx
  }));

  // Track sides used on Gateways & Events so Gateway diamonds never get 2 ports on same tip,
  // and Event/Gateway external labels always sit on an edge-free side!
  const usedSides = new Map();
  for (const n of rawNodes) usedSides.set(n.id, { T: 0, B: 0, L: 0, R: 0 });

  for (const e of rawEdges) {
    const s = nodeById.get(e.src);
    const t = nodeById.get(e.dst);
    if (!s || !t) throw new Error(`[${pageDef.id}] Missing endpoint in edge ${e.src} -> ${e.dst}`);
    if (e.srcSide) usedSides.get(s.id)[e.srcSide]++;
    if (e.dstSide) usedSides.get(t.id)[e.dstSide]++;
    if (s.type === 'extpool' && !e.srcSide) { e.srcSide = 'T'; usedSides.get(s.id).T++; }
    if (t.type === 'extpool' && !e.dstSide) { e.dstSide = 'T'; usedSides.get(t.id).T++; }
    if (s.type === 'boundary' && !e.srcSide) { e.srcSide = 'B'; usedSides.get(s.id).B++; }
  }

  for (const e of rawEdges) {
    const s = nodeById.get(e.src);
    const t = nodeById.get(e.dst);
    if (!e.srcSide) {
      const strictSingle = (s.type === 'gateway' || s.type === 'start' || s.type === 'intermediate' || s.type === 'end');
      e.srcSide = chooseSideToward(s, t, usedSides.get(s.id), !strictSingle);
      usedSides.get(s.id)[e.srcSide]++;
    }
    if (!e.dstSide) {
      const strictSingle = (t.type === 'gateway' || t.type === 'start' || t.type === 'intermediate' || t.type === 'end');
      e.dstSide = chooseSideToward(t, s, usedSides.get(t.id), !strictSingle);
      usedSides.get(t.id)[e.dstSide]++;
    }
  }

  // Choose external label side for Events & Gateways on an unused side, then add label rects as passive obstacles!
  const extLabelMetaMap = new Map();
  const passiveObstacles = [];
  for (const n of rawNodes) {
    if ((n.type === 'start' || n.type === 'intermediate' || n.type === 'boundary' || n.type === 'end' || n.type === 'gateway') && n.label) {
      const us = usedSides.get(n.id);
      let chosenSide = n.labelSide;
      if (!chosenSide) {
        const pref = n.type === 'gateway' ? ['T', 'B', 'L', 'R'] : ['B', 'T', 'L', 'R'];
        chosenSide = pref.find((s) => us[s] === 0) || pref[0];
      }
      const rect = estimateExtLabelRect(n, chosenSide);
      extLabelMetaMap.set(n.id, { chosenSide, rect });
      passiveObstacles.push({
        id: `__extlbl_${n.id}`,
        isPassiveObstacle: true,
        ownerId: n.id,
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        w: Math.round(rect.w),
        h: Math.round(rect.h),
        kind: 'rect'
      });
    }
  }

  // Also add vertical header bar of pool + lanes as passive obstacle so routes never cross lane titles
  passiveObstacles.push({
    id: '__lane_headers',
    isPassiveObstacle: true,
    ownerId: '__pool',
    x: poolX,
    y: poolY,
    w: poolHeaderW + laneHeaderW,
    h: poolH,
    kind: 'rect'
  });

  // Note: Boundary events slightly overlap their host tasks (16px). Temporarily keep hostId & boundaryId untouched
  // because boundary exit ports are on 'B' (16px below host.y + host.h).
  const allRouterNodes = [...rawNodes, ...passiveObstacles];
  const routed = routeClusterEdges(allRouterNodes, rawEdges, {
    margin: 24,
    topMargin: 24,
    stubLen: 18,
    minPortSpacing: 12,
    nodeClearance: 7,
    parallelGap: 8,
    labelFontSize: 9.5,
    trackStep: 10
  });

  // Separate routed real nodes vs shifted passive obstacles
  const routedMap = new Map();
  const routedPassive = [];
  for (const rn of routed.nodes) {
    if (rn.isPassiveObstacle) routedPassive.push(rn);
    else routedMap.set(rn.id, rn);
  }

  // Reconstruct shifted Pool & Lanes cleanly around shifted nodes
  const hdrObj = routedPassive.find((p) => p.id === '__lane_headers');
  const shiftX = hdrObj.x - poolX;
  const shiftY = hdrObj.y - poolY;
  const shiftedLanes = lanes.map((ln) => ({
    ...ln,
    x: ln.x + shiftX,
    y: ln.y + shiftY
  }));

  let maxRight = poolX + shiftX + 600;
  for (const rn of routedMap.values()) {
    if (rn.type !== 'extpool') maxRight = Math.max(maxRight, rn.x + rn.w + 42);
    else maxRight = Math.max(maxRight, rn.x + rn.w + 20);
  }
  for (const re of routed.edges) {
    for (const [px] of re.points) maxRight = Math.max(maxRight, px + 30);
    if (re.labelPos) maxRight = Math.max(maxRight, re.labelPos.x + re.labelPos.w + 24);
  }
  for (const po of routedPassive) {
    if (po.ownerId !== '__pool') maxRight = Math.max(maxRight, po.x + po.w + 24);
  }

  const finalPoolX = poolX + shiftX;
  const finalPoolY = poolY + shiftY;
  const finalPoolW = Math.ceil((maxRight - finalPoolX) / 10) * 10;

  // Ensure external pools sit cleanly below finalPoolY + poolH (in case shift adjusted things, they shifted uniformly)
  const finalExtY = finalPoolY + poolH + 54;
  for (const rn of routedMap.values()) {
    if (rn.type === 'extpool') rn.y = finalExtY;
  }

  // =========================================================================
  // STRICT AUTOMATED GEOMETRY & SEMANTICS AUDIT
  // =========================================================================
  const errors = [];
  const realNodes = [...routedMap.values()];

  // 1. Node-to-node overlaps (allow only boundary event overlapping its hostId)
  for (let i = 0; i < realNodes.length; i++) {
    for (let j = i + 1; j < realNodes.length; j++) {
      const a = realNodes[i], b = realNodes[j];
      const isHostPair = (a.type === 'boundary' && a.hostId === b.id) || (b.type === 'boundary' && b.hostId === a.id);
      if (isHostPair) continue;
      if (lib.rectsOverlap(a, b, 4)) {
        errors.push(`Node overlap: ${a.id} (${a.x},${a.y},${a.w}x${a.h}) vs ${b.id} (${b.x},${b.y},${b.w}x${b.h})`);
      }
    }
  }

  // 2. Nodes (and their external labels) inside their own lane bounds (except extpool)
  const shiftedLaneMap = new Map(shiftedLanes.map((l) => [l.id, l]));
  for (const n of realNodes) {
    if (n.type === 'extpool') continue;
    const ln = shiftedLaneMap.get(n.laneId);
    if (n.x < ln.x + laneHeaderW + 6) errors.push(`Node ${n.id} intrudes lane header (${n.x} < ${ln.x + laneHeaderW + 6})`);
    if (n.y < ln.y + 4) errors.push(`Node ${n.id} overflows top of lane ${ln.id} (${n.y} < ${ln.y + 4})`);
    if (n.type !== 'boundary' && n.y + n.h > ln.y + ln.h - 4) {
      errors.push(`Node ${n.id} overflows bottom of lane ${ln.id} (${n.y + n.h} > ${ln.y + ln.h - 4})`);
    }
  }

  // 3. External Event/Gateway label overlap with other nodes, other labels, lane borders, or edges
  const extLabels = routedPassive.filter((p) => p.ownerId !== '__pool');
  for (let i = 0; i < extLabels.length; i++) {
    const la = extLabels[i];
    const owner = routedMap.get(la.ownerId);
    if (owner && owner.type !== 'extpool') {
      const ln = shiftedLaneMap.get(owner.laneId);
      if (la.y < ln.y + 2 || la.y + la.h > ln.y + ln.h - 2) {
        errors.push(`ExtLabel of ${la.ownerId} crosses lane ${owner.laneId} boundary (${la.y}..${la.y + la.h} vs ${ln.y}..${ln.y + ln.h})`);
      }
      if (la.x < ln.x + laneHeaderW + 4) {
        errors.push(`ExtLabel of ${la.ownerId} intrudes lane header`);
      }
    }
    for (const n of realNodes) {
      if (n.id === la.ownerId) continue;
      if (lib.rectsOverlap(la, n, 2)) {
        errors.push(`ExtLabel of ${la.ownerId} overlaps node ${n.id}`);
      }
    }
    for (let j = i + 1; j < extLabels.length; j++) {
      const lb = extLabels[j];
      if (lib.rectsOverlap(la, lb, 2)) {
        errors.push(`ExtLabel overlap: ${la.ownerId} vs ${lb.ownerId}`);
      }
    }
  }

  // 4. Edge-to-node collisions & Edge-to-ExtLabel collisions
  for (const e of routed.edges) {
    const pts = e.points;
    for (let s = 0; s < pts.length - 1; s++) {
      const p1 = pts[s], p2 = pts[s + 1];
      for (const n of realNodes) {
        if (n.id === e.src || n.id === e.dst) continue;
        // Skip host task only for first segment of boundary edge if needed (already outside, so check anyway)
        if (lib.segIntersectsRect(p1, p2, n, -2)) {
          errors.push(`Edge ${e.src}->${e.dst} seg ${s} collides with node ${n.id}`);
        }
      }
      for (const la of extLabels) {
        if (lib.segIntersectsRect(p1, p2, la, 0)) {
          errors.push(`Edge ${e.src}->${e.dst} seg ${s} crosses ExtLabel of ${la.ownerId}`);
        }
      }
      if (lib.segIntersectsRect(p1, p2, hdrObj, 0)) {
        errors.push(`Edge ${e.src}->${e.dst} seg ${s} crosses Pool/Lane vertical header`);
      }
    }
  }

  // 5. Collinear overlaps
  const colls = lib.findCollinearOverlaps(routed.edges, 5.5, 8);
  for (const c of colls) {
    const ea = routed.edges[c.i], eb = routed.edges[c.j];
    errors.push(`Collinear overlap (${c.axis}): ${ea.src}->${ea.dst} vs ${eb.src}->${eb.dst} (ov=${c.ov})`);
  }

  // 6. Edge label overlaps with nodes, extLabels, and other edge labels
  const edgeLbls = routed.edges.filter((e) => e.labelPos).map((e) => ({ id: `${e.src}->${e.dst}`, ...e.labelPos }));
  for (let i = 0; i < edgeLbls.length; i++) {
    const a = edgeLbls[i];
    for (const n of realNodes) {
      if (lib.rectsOverlap(a, n, 2)) errors.push(`EdgeLabel (${a.id}) overlaps node ${n.id}`);
    }
    for (const la of extLabels) {
      if (lib.rectsOverlap(a, la, 2)) errors.push(`EdgeLabel (${a.id}) overlaps ExtLabel ${la.ownerId}`);
    }
    for (let j = i + 1; j < edgeLbls.length; j++) {
      if (lib.rectsOverlap(a, edgeLbls[j], 2)) errors.push(`EdgeLabel overlap: ${a.id} vs ${edgeLbls[j].id}`);
    }
  }

  // 7. Gateway port uniqueness & BPMN semantics checks
  const gwSides = new Map();
  const inDeg = new Map();
  const outDeg = new Map();
  for (const n of realNodes) {
    inDeg.set(n.id, 0);
    outDeg.set(n.id, 0);
    if (n.type === 'gateway') gwSides.set(n.id, { T: 0, B: 0, L: 0, R: 0 });
  }
  for (const e of routed.edges) {
    const s = routedMap.get(e.src);
    const t = routedMap.get(e.dst);
    if (e.kind === 'sequence') {
      outDeg.set(s.id, outDeg.get(s.id) + 1);
      inDeg.set(t.id, inDeg.get(t.id) + 1);
      if (s.type === 'extpool' || t.type === 'extpool') errors.push(`Sequence flow crosses pool: ${s.id}->${t.id}`);
      if (s.type === 'datastore' || t.type === 'datastore' || s.type === 'dataobject' || t.type === 'dataobject') {
        errors.push(`Sequence flow touches data artifact: ${s.id}->${t.id}`);
      }
    } else if (e.kind === 'message') {
      if (!((s.type === 'extpool') !== (t.type === 'extpool'))) {
        errors.push(`Message flow must connect Main Pool and External Pool: ${s.id}->${t.id}`);
      }
    }
    if (s.type === 'gateway') gwSides.get(s.id)[e.srcSide]++;
    if (t.type === 'gateway') gwSides.get(t.id)[e.dstSide]++;
  }
  for (const [gwId, sc] of gwSides.entries()) {
    for (const side of ['T', 'B', 'L', 'R']) {
      if (sc[side] > 1) errors.push(`Gateway ${gwId} has ${sc[side]} edges on tip ${side} (must be <=1)`);
    }
  }
  for (const n of realNodes) {
    const ind = inDeg.get(n.id);
    const outd = outDeg.get(n.id);
    if ((n.type === 'start' || n.type === 'boundary') && (ind > 0 || outd < 1)) {
      errors.push(`${n.type} ${n.id} invalid degree (in=${ind}, out=${outd})`);
    }
    if (n.type === 'end' && (ind < 1 || outd > 0)) {
      errors.push(`End ${n.id} invalid degree (in=${ind}, out=${outd})`);
    }
    if ((n.type === 'task' || n.type === 'subprocess' || n.type === 'gateway') && (ind < 1 || outd < 1)) {
      errors.push(`${n.type} ${n.id} dead-end or unreachable (in=${ind}, out=${outd})`);
    }
  }

  // =========================================================================
  // SERIALIZE TO CLEAN DRAW.IO XML CELLS
  // =========================================================================
  const cellsXml = [];
  const poolCellId = `${pageDef.id}_pool`;
  const poolStyle = `swimlane;html=1;horizontal=0;startSize=${poolHeaderW};whiteSpace=wrap;resizeParent=0;resizeParentMax=0;resizeLast=0;collapsible=0;fillColor=#ffffff;swimlaneFillColor=#ffffff;strokeColor=#000000;strokeWidth=1.5;fontColor=#000000;fontStyle=1;fontSize=12;fontFamily=Helvetica;`;
  cellsXml.push(
    `<mxCell id="${poolCellId}" value="${lib.escapeHtmlAttr('Marketplace UMKM MyPeken')}" style="${poolStyle}" vertex="1" parent="1">`,
    `  <mxGeometry x="${finalPoolX}" y="${finalPoolY}" width="${finalPoolW}" height="${poolH}" as="geometry" />`,
    `</mxCell>`
  );

  for (const ln of shiftedLanes) {
    const lnId = `${pageDef.id}_${ln.id}`;
    const laneStyle = `swimlane;html=1;horizontal=0;startSize=${laneHeaderW};whiteSpace=wrap;resizeParent=0;resizeParentMax=0;resizeLast=0;collapsible=0;fillColor=#ffffff;swimlaneFillColor=#ffffff;strokeColor=#000000;strokeWidth=1;fontColor=#000000;fontStyle=1;fontSize=11;fontFamily=Helvetica;`;
    cellsXml.push(
      `<mxCell id="${lnId}" value="${lib.escapeHtmlAttr(ln.label)}" style="${laneStyle}" vertex="1" parent="${poolCellId}">`,
      `  <mxGeometry x="${poolHeaderW}" y="${ln.y - finalPoolY}" width="${finalPoolW - poolHeaderW}" height="${ln.h}" as="geometry" />`,
      `</mxCell>`
    );
  }

  for (const n of realNodes) {
    const cid = `${pageDef.id}_${n.id}`;
    const extMeta = extLabelMetaMap.get(n.id);
    const lblMeta = extMeta ? extLabelMetaMap.get(n.id).rect : null;
    const style = buildNodeStyle(n, lblMeta);
    const parentId = n.type === 'extpool' ? '1' : `${pageDef.id}_${n.laneId}`;
    const parentLn = n.type === 'extpool' ? { x: 0, y: 0 } : shiftedLaneMap.get(n.laneId);
    const relX = n.x - parentLn.x;
    const relY = n.y - parentLn.y;
    const val = n.label ? lib.escapeHtmlAttr(n.label) : '';
    cellsXml.push(
      `<mxCell id="${cid}" value="${val}" style="${style}" vertex="1" parent="${parentId}">`,
      `  <mxGeometry x="${relX}" y="${relY}" width="${n.w}" height="${n.h}" as="geometry" />`,
      `</mxCell>`
    );
  }

  for (const e of routed.edges) {
    const eid = `${pageDef.id}_e${e.idx + 1}`;
    const srcCid = `${pageDef.id}_${e.src}`;
    const dstCid = `${pageDef.id}_${e.dst}`;
    const style = buildEdgeStyle(e);
    const val = e.label ? lib.escapeHtmlAttr(e.label) : '';
    const relX = e.relX ?? 0;
    const offX = Math.round(e.labelOffsetX || 0);
    const offY = Math.round(e.labelOffsetY || 0);
    const pts = e.waypoints || [];

    cellsXml.push(`<mxCell id="${eid}" value="${val}" style="${style}" edge="1" parent="1" source="${srcCid}" target="${dstCid}">`);
    if (e.label || pts.length > 0) {
      const xAttr = e.label ? ` x="${relX}"` : '';
      cellsXml.push(`  <mxGeometry${xAttr} relative="1" as="geometry">`);
      if (pts.length > 0) {
        cellsXml.push(`    <Array as="points">`);
        for (const [px, py] of pts) {
          cellsXml.push(`      <mxPoint x="${px}" y="${py}" />`);
        }
        cellsXml.push(`    </Array>`);
      }
      if (e.label && (offX !== 0 || offY !== 0)) {
        cellsXml.push(`    <mxPoint x="${offX}" y="${offY}" as="offset" />`);
      }
      cellsXml.push(`  </mxGeometry>`);
    } else {
      cellsXml.push(`  <mxGeometry relative="1" as="geometry" />`);
    }
    cellsXml.push(`</mxCell>`);
  }

  const pageWidth = Math.max(routed.pageWidth, finalPoolX + finalPoolW + 24);
  const pageHeight = Math.max(routed.pageHeight, finalExtY + extPoolH + 36);

  const pageObj = {
    id: pageDef.id,
    name: pageDef.name,
    pngName: pageDef.pngName,
    pageWidth,
    pageHeight,
    cellsXml,
    errors,
    stats: {
      nodes: realNodes.length,
      edges: routed.edges.length,
      crossings: lib.countEdgeCrossings(routed.edges),
      collinear: colls.length
    }
  };
  return pageObj;
}

async function buildAndExportAll(pageDefs, outDrawioPath, outPngDir) {
  const pages = pageDefs.map(compileAndAuditPage);
  let totalErrors = 0;
  for (const p of pages) {
    console.log(`[${p.id}] ${p.name} -> nodes=${p.stats.nodes}, edges=${p.stats.edges}, crossings=${p.stats.crossings}, collinear=${p.stats.collinear}, errors=${p.errors.length}`);
    for (const err of p.errors) {
      console.log(`   ERROR: ${err}`);
    }
    totalErrors += p.errors.length;
  }

  const multiXml = lib.buildMultiPageMxfileXml(pages);
  lib.verifyNoAiMetadata(multiXml);
  if (/\bagent="/i.test(multiXml)) {
    throw new Error('Forbidden agent= attribute detected in generated XML!');
  }

  fs.mkdirSync(path.dirname(outDrawioPath), { recursive: true });
  fs.writeFileSync(outDrawioPath, multiXml, 'utf8');
  console.log(`Saved master XML: ${outDrawioPath}`);

  if (totalErrors > 0) {
    throw new Error(`Audit failed with ${totalErrors} error(s). Fix layout/routing before exporting PNGs.`);
  }

  fs.mkdirSync(outPngDir, { recursive: true });
  for (const p of pages) {
    const singleXml = lib.buildSinglePageMxfileXml(p);
    lib.verifyNoAiMetadata(singleXml);
    const pngPath = path.join(outPngDir, p.pngName);
    const res = await renderDrawioXmlToPng(singleXml, pngPath);
    // Double-check PNG chunk has no AI metadata
    const pngBuf = fs.readFileSync(pngPath);
    let off = 8;
    let decodedText = '';
    while (off + 12 <= pngBuf.length) {
      const len = pngBuf.readUInt32BE(off);
      const type = pngBuf.toString('ascii', off + 4, off + 8);
      if (type === 'tEXt') {
        const data = pngBuf.slice(off + 8, off + 8 + len);
        const nul = data.indexOf(0);
        if (nul >= 0 && data.slice(0, nul).toString('ascii') === 'mxfile') {
          decodedText = decodeURIComponent(data.slice(nul + 1).toString('ascii'));
        }
      }
      off += 12 + len;
    }
    if (!decodedText) throw new Error(`Missing tEXt:mxfile chunk in ${pngPath}`);
    lib.verifyNoAiMetadata(decodedText);
    console.log(`Exported PNG: ${p.pngName} (${res.width}x${res.height}, cdp=${res.usedCdp})`);
  }
}

module.exports = {
  compileAndAuditPage,
  buildAndExportAll
};
