const fs = require('fs');

const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  CRC_TABLE[n] = c >>> 0;
}

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = (c >>> 8) ^ CRC_TABLE[(c ^ buf[i]) & 0xff];
  return (c ^ -1) >>> 0;
}

function escapeXmlAttr(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\r?\n/g, '&#xa;');
}

function escapeHtmlAttr(str) {
  return escapeXmlAttr(String(str).replace(/\r?\n/g, '<br>'));
}

function buildDiagramInnerXml({ id, name, pageWidth, pageHeight, cellsXml }) {
  const safeName = escapeXmlAttr(name);
  return [
    `  <diagram id="${escapeXmlAttr(id)}" name="${safeName}">`,
    `    <mxGraphModel dx="${pageWidth}" dy="${pageHeight}" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="${pageWidth}" pageHeight="${pageHeight}" background="#ffffff" math="0" shadow="0">`,
    `      <root>`,
    `        <mxCell id="0" />`,
    `        <mxCell id="1" parent="0" />`,
    ...cellsXml.map((line) => `        ${line}`),
    `      </root>`,
    `    </mxGraphModel>`,
    `  </diagram>`
  ].join('\n');
}

function buildMultiPageMxfileXml(pages) {
  const inner = pages.map(buildDiagramInnerXml).join('\n');
  return [
    `<mxfile host="app.diagrams.net" version="24.7.17" pages="${pages.length}">`,
    inner,
    `</mxfile>`
  ].join('\n');
}

function buildSinglePageMxfileXml(page) {
  return [
    `<mxfile host="app.diagrams.net" scale="1" border="0">`,
    buildDiagramInnerXml(page),
    `</mxfile>`
  ].join('\n');
}

function embedMxfileInPng(pngPath, singlePageMxfileXml) {
  const cleanXml = singlePageMxfileXml.replace(/\s+agent="[^"]*"/g, '');
  const buf = fs.readFileSync(pngPath);
  const sig = buf.slice(0, 8);
  const chunks = [sig];
  let off = 8;
  let inserted = false;

  const textData = Buffer.concat([
    Buffer.from('mxfile\0', 'ascii'),
    Buffer.from(encodeURIComponent(cleanXml), 'ascii')
  ]);
  const makeTextChunk = () => {
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(textData.length, 0);
    const typeBuf = Buffer.from('tEXt', 'ascii');
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, textData])), 0);
    return Buffer.concat([lenBuf, typeBuf, textData, crcBuf]);
  };

  while (off < buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('ascii', off + 4, off + 8);
    const fullChunk = buf.slice(off, off + 12 + len);

    if (type === 'tEXt') {
      const data = buf.slice(off + 8, off + 8 + len);
      const nullIdx = data.indexOf(0);
      const key = nullIdx >= 0 ? data.slice(0, nullIdx).toString('ascii') : '';
      if (key === 'mxfile') {
        chunks.push(makeTextChunk());
        inserted = true;
        off += 12 + len;
        continue;
      }
    }
    if (type === 'IDAT' && !inserted) {
      chunks.push(makeTextChunk());
      inserted = true;
    }
    chunks.push(fullChunk);
    off += 12 + len;
  }

  fs.writeFileSync(pngPath, Buffer.concat(chunks));
}

function verifyNoAiMetadata(text) {
  const forbidden = [/antigravity/i, /ai[\s_-]*generated/i, /claude/i, /openai/i, /chatgpt/i, /gemini/i];
  for (const rx of forbidden) {
    if (rx.test(text)) {
      throw new Error(`Forbidden AI metadata pattern matched: ${rx}`);
    }
  }
}

function rectsOverlap(a, b, pad = 2) {
  return !(
    a.x + a.w + pad <= b.x ||
    b.x + b.w + pad <= a.x ||
    a.y + a.h + pad <= b.y ||
    b.y + b.h + pad <= a.y
  );
}

function segIntersectsRect(p1, p2, r, pad = 4) {
  const rx1 = r.x + pad;
  const ry1 = r.y + pad;
  const rx2 = r.x + r.w - pad;
  const ry2 = r.y + r.h - pad;
  if (rx2 <= rx1 || ry2 <= ry1) return false;

  const minX = Math.min(p1[0], p2[0]);
  const maxX = Math.max(p1[0], p2[0]);
  const minY = Math.min(p1[1], p2[1]);
  const maxY = Math.max(p1[1], p2[1]);

  if (maxX < rx1 || minX > rx2 || maxY < ry1 || minY > ry2) return false;

  // Axis-aligned quick check
  if (Math.abs(p1[0] - p2[0]) < 0.01) {
    return p1[0] > rx1 && p1[0] < rx2 && maxY > ry1 && minY < ry2;
  }
  if (Math.abs(p1[1] - p2[1]) < 0.01) {
    return p1[1] > ry1 && p1[1] < ry2 && maxX > rx1 && minX < rx2;
  }

  // Parametric Liang-Barsky for diagonal segments
  let t0 = 0;
  let t1 = 1;
  const dx = p2[0] - p1[0];
  const dy = p2[1] - p1[1];
  const checks = [
    [-dx, p1[0] - rx1],
    [dx, rx2 - p1[0]],
    [-dy, p1[1] - ry1],
    [dy, ry2 - p1[1]]
  ];
  for (const [p, q] of checks) {
    if (Math.abs(p) < 1e-9) {
      if (q < 0) return false;
    } else {
      const rVal = q / p;
      if (p < 0) {
        if (rVal > t1) return false;
        if (rVal > t0) t0 = rVal;
      } else {
        if (rVal < t0) return false;
        if (rVal < t1) t1 = rVal;
      }
    }
  }
  return t0 < t1;
}

function getEdgePoints(edge) {
  return (edge && (edge.points || edge.pts)) || [];
}

function findCollinearOverlaps(edges, minParallelGap = 6, minOverlapLen = 8) {
  const overlaps = [];
  for (let i = 0; i < edges.length; i++) {
    const ptsA = getEdgePoints(edges[i]);
    if (ptsA.length < 2) continue;
    for (let j = i + 1; j < edges.length; j++) {
      const ptsB = getEdgePoints(edges[j]);
      if (ptsB.length < 2) continue;
      let hit = false;
      for (let sa = 0; sa < ptsA.length - 1 && !hit; sa++) {
        const a1 = ptsA[sa], a2 = ptsA[sa + 1];
        if (Math.hypot(a2[0] - a1[0], a2[1] - a1[1]) < 1) continue;
        const aHoriz = Math.abs(a1[1] - a2[1]) < 1.5;
        const aVert = Math.abs(a1[0] - a2[0]) < 1.5;
        if (!aHoriz && !aVert) continue;
        for (let sb = 0; sb < ptsB.length - 1 && !hit; sb++) {
          const b1 = ptsB[sb], b2 = ptsB[sb + 1];
          if (Math.hypot(b2[0] - b1[0], b2[1] - b1[1]) < 1) continue;
          if (aHoriz && Math.abs(b1[1] - b2[1]) < 1.5) {
            const dy = Math.abs(0.5 * (a1[1] + a2[1]) - 0.5 * (b1[1] + b2[1]));
            const ov = Math.min(Math.max(a1[0], a2[0]), Math.max(b1[0], b2[0])) -
                       Math.max(Math.min(a1[0], a2[0]), Math.min(b1[0], b2[0]));
            if (dy < minParallelGap && ov > minOverlapLen) {
              overlaps.push({ i, j, axis: 'H', dy: Math.round(dy * 10) / 10, ov: Math.round(ov) });
              hit = true;
            }
          } else if (aVert && Math.abs(b1[0] - b2[0]) < 1.5) {
            const dx = Math.abs(0.5 * (a1[0] + a2[0]) - 0.5 * (b1[0] + b2[0]));
            const ov = Math.min(Math.max(a1[1], a2[1]), Math.max(b1[1], b2[1])) -
                       Math.max(Math.min(a1[1], a2[1]), Math.min(b1[1], b2[1]));
            if (dx < minParallelGap && ov > minOverlapLen) {
              overlaps.push({ i, j, axis: 'V', dx: Math.round(dx * 10) / 10, ov: Math.round(ov) });
              hit = true;
            }
          }
        }
      }
    }
  }
  return overlaps;
}

function countEdgeCrossings(edges) {
  let count = 0;
  for (let i = 0; i < edges.length; i++) {
    const ptsA = getEdgePoints(edges[i]);
    if (ptsA.length < 2) continue;
    for (let j = i + 1; j < edges.length; j++) {
      const ptsB = getEdgePoints(edges[j]);
      if (ptsB.length < 2) continue;
      for (let sa = 0; sa < ptsA.length - 1; sa++) {
        const a1 = ptsA[sa], a2 = ptsA[sa + 1];
        const dax = a2[0] - a1[0], day = a2[1] - a1[1];
        for (let sb = 0; sb < ptsB.length - 1; sb++) {
          const b1 = ptsB[sb], b2 = ptsB[sb + 1];
          const dbx = b2[0] - b1[0], dby = b2[1] - b1[1];
          const den = dax * dby - day * dbx;
          if (Math.abs(den) < 1e-6) continue;
          const qpx = b1[0] - a1[0], qpy = b1[1] - a1[1];
          const t = (qpx * dby - qpy * dbx) / den;
          const u = (qpx * day - qpy * dax) / den;
          if (t > 1e-3 && t < 1 - 1e-3 && u > 1e-3 && u < 1 - 1e-3) {
            count++;
          }
        }
      }
    }
  }
  return count;
}

module.exports = {
  crc32,
  escapeXmlAttr,
  escapeHtmlAttr,
  buildDiagramInnerXml,
  buildMultiPageMxfileXml,
  buildSinglePageMxfileXml,
  embedMxfileInPng,
  verifyNoAiMetadata,
  rectsOverlap,
  segIntersectsRect,
  findCollinearOverlaps,
  countEdgeCrossings
};
