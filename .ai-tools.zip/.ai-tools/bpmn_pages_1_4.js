const PAGES_1_4 = [
  // =========================================================================
  // HALAMAN 01: AUTENTIKASI, PROFIL & KEAMANAN AKUN
  // =========================================================================
  {
    id: 'p1',
    name: '01. Autentikasi, Profil & Keamanan',
    pngName: '01- BPMN Autentikasi, Profil & Keamanan Akun.drawio.png',
    lanes: [
      { id: 'guest', label: 'Pengunjung (Guest)', height: 256 },
      { id: 'user', label: 'Pembeli / Penjual UMKM', height: 335 },
      { id: 'admin', label: 'Admin (CS / Ops / Super)', height: 175 },
      { id: 'sys', label: 'Sistem MyPeken', height: 425, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 955, w: 215 },
      { id: 'ext_maps', label: 'Maps API', cx: 1565, w: 165 }
    ],
    nodes: [
      // --- Band A: Autentikasi Pengguna (FR-001, INV-01, INV-02) ---
      { id: 's_auth', laneId: 'guest', type: 'start', symbol: 'general', label: 'Akses Login /\nFitur Terproteksi', cx: 45, cy: 128, labelSide: 'B' },
      { id: 't_pick_auth', laneId: 'guest', type: 'task', marker: 'user', label: 'Pilih Metode\nAutentikasi', cx: 185, cy: 128 },
      { id: 'g_auth_m', laneId: 'guest', type: 'gateway', gwType: 'exclusive', label: '', cx: 315, cy: 128 },
      { id: 't_auth_wa', laneId: 'guest', type: 'task', marker: 'user', label: 'Input No. HP/WA\n& Nama Tampilan', cx: 515, cy: 48 },
      { id: 't_auth_email', laneId: 'guest', type: 'task', marker: 'user', label: 'Input Email, Pass >=8\n/ Lupa Password', cx: 515, cy: 128 },
      { id: 't_auth_google', laneId: 'guest', type: 'task', marker: 'user', label: 'Autentikasi Akun\nGoogle OAuth', cx: 515, cy: 208 },
      { id: 'g_auth_join', laneId: 'guest', type: 'gateway', gwType: 'exclusive', label: '', cx: 675, cy: 128 },

      { id: 't_cek_dup', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Identitas Tunggal\n& Status Suspend (INV-01)', cx: 675, cy: 78 },
      { id: 'g_need_otp', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Butuh\nOTP/HP?', cx: 815, cy: 78 },
      { id: 'sp_otp_auth', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Verifikasi OTP Multi-Saluran\n(WA -> SMS/Email 60 dtk)', cx: 945, cy: 175 },
      { id: 'b_otp_err', type: 'boundary', hostId: 'sp_otp_auth', posRatio: 0.04, symbol: 'error', label: '5x Salah\nBlokir 15m', cx: 0, cy: 0, labelSide: 'L' },
      { id: 'e_otp_fail', laneId: 'sys', type: 'end', symbol: 'error', label: 'OTP Gagal /\nBlokir 15 Menit', cx: 745, cy: 325, labelSide: 'B' },
      { id: 'ann_inv02', laneId: 'sys', type: 'annotation', label: 'INV-02: OTP TTL 5 mnt,\ncooldown 60 dtk, maks 5x salah', cx: 1185, cy: 345 },
      { id: 't_activate_sess', laneId: 'sys', type: 'task', marker: 'service', label: 'Aktifkan Akun / Taut\nGoogle & Buat Sesi', cx: 1185, cy: 78 },
      { id: 'd1_auth', laneId: 'sys', type: 'datastore', label: 'D1: Pengguna,\nAlamat & OTP', cx: 1185, cy: 235 },

      { id: 't_switch_mode', laneId: 'user', type: 'task', marker: 'user', label: 'Akses Beranda / Beralih\nMode Pembeli-Penjual', cx: 1185, cy: 78 },
      { id: 'e_auth_ok', laneId: 'user', type: 'end', symbol: 'general', label: 'Sesi Aktif', cx: 1305, cy: 78, labelSide: 'T' },

      // --- Band B1: Buku Alamat & Geofencing Sarbagita (FR-024, INV-03) ---
      { id: 's_addr', laneId: 'user', type: 'start', symbol: 'general', label: 'Kelola\nAlamat', cx: 1415, cy: 78, labelSide: 'T' },
      { id: 't_addr_in', laneId: 'user', type: 'task', marker: 'user', label: 'Isi Penerima, No HP,\nAlamat & Pin GPS', cx: 1565, cy: 78 },
      { id: 't_geo_cek', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi Geofencing\nSarbagita (INV-03)', cx: 1565, cy: 175 },
      { id: 'g_geo_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Area\nSarbagita?', cx: 1715, cy: 175 },
      { id: 'e_geo_fail', laneId: 'sys', type: 'end', symbol: 'error', label: 'Tolak Alamat\n(Luar Sarbagita)', cx: 1715, cy: 280, labelSide: 'B' },
      { id: 't_addr_save', laneId: 'sys', type: 'task', marker: 'service', label: 'Simpan Alamat &\nSet Alamat Utama', cx: 1865, cy: 175 },
      { id: 'e_addr_ok', laneId: 'user', type: 'end', symbol: 'general', label: 'Alamat\nTersimpan', cx: 1865, cy: 78, labelSide: 'T' },

      // --- Band B2: Profil, PIN Saldo, Ubah HP, Tutup Akun & Logout (FR-033) ---
      { id: 's_prof', laneId: 'user', type: 'start', symbol: 'general', label: 'Pengaturan\nKeamanan', cx: 1295, cy: 190, labelSide: 'L' },
      { id: 't_prof_pick', laneId: 'user', type: 'task', marker: 'user', label: 'Pilih Aksi Profil,\nPIN, HP / Tutup Akun', cx: 1435, cy: 190 },
      { id: 'g_prof_1', laneId: 'user', type: 'gateway', gwType: 'exclusive', label: '', cx: 1565, cy: 190 },
      { id: 'g_prof_2', laneId: 'user', type: 'gateway', gwType: 'exclusive', label: '', cx: 1565, cy: 272 },
      { id: 't_pin_in', laneId: 'user', type: 'task', marker: 'user', label: 'Atur / Reset\nPIN Saldo 6 Digit', cx: 1735, cy: 190 },
      { id: 't_hp_in', laneId: 'user', type: 'task', marker: 'user', label: 'Verifikasi Akun Lama\n& Input HP Baru', cx: 2045, cy: 78 },
      { id: 't_close_req', laneId: 'user', type: 'task', marker: 'user', label: 'Ajukan Hapus /\nTutup Akun', cx: 2045, cy: 190 },
      { id: 't_logout_u', laneId: 'user', type: 'task', marker: 'user', label: 'Tekan Keluar\n(Logout)', cx: 1735, cy: 272 },

      { id: 't_pin_save', laneId: 'sys', type: 'task', marker: 'service', label: 'Hash PIN & Blokir 15m\nJika Salah 5x', cx: 2045, cy: 175 },
      { id: 'e_pin_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'PIN Tersimpan', cx: 2045, cy: 280, labelSide: 'B' },

      { id: 'sp_hp_otp', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'OTP No. HP Baru &\nNotif Saluran Lama', cx: 2230, cy: 78 },
      { id: 'e_hp_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'No. HP\nDiperbarui', cx: 2385, cy: 78, labelSide: 'T' },

      { id: 't_close_cek', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Order Aktif=0,\nSaldo/Hold/Arrears=0', cx: 2230, cy: 180 },
      { id: 'd3_cek', laneId: 'sys', type: 'datastore', label: 'D3: Toko &\nKYC', cx: 2045, cy: 360 },
      { id: 'd7_cek', laneId: 'sys', type: 'datastore', label: 'D7: Pesanan', cx: 2165, cy: 360 },
      { id: 'd11_cek', laneId: 'sys', type: 'datastore', label: 'D11: Saldo &\nHold', cx: 2285, cy: 360 },
      { id: 'g_close_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Layak\nTutup?', cx: 2385, cy: 180 },
      { id: 'e_close_no', laneId: 'sys', type: 'end', symbol: 'error', label: 'Tolak Tutup\nAkun', cx: 2385, cy: 285, labelSide: 'B' },
      { id: 'sp_close_otp', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Konfirmasi OTP /\nRe-Auth Google', cx: 2545, cy: 180 },
      { id: 't_close_anon', laneId: 'sys', type: 'task', marker: 'service', label: 'Anonimisasi PII &\nArsip Log Finansial', cx: 2725, cy: 180 },
      { id: 'e_close_ok', laneId: 'sys', type: 'end', symbol: 'terminate', label: 'Akun Ditutup\nPermanen', cx: 2725, cy: 285, labelSide: 'B' },

      { id: 't_revoke_u', laneId: 'sys', type: 'task', marker: 'service', label: 'Cabut Sesi Login\nPengguna', cx: 1865, cy: 285 },
      { id: 'e_logout_u', laneId: 'sys', type: 'end', symbol: 'general', label: 'Logout\nSelesai', cx: 1865, cy: 365, labelSide: 'B' },

      // --- Band C: Autentikasi, RBAC & Sesi Admin (FR-028) ---
      { id: 's_adm', laneId: 'admin', type: 'start', symbol: 'general', label: 'Buka Portal\nAdmin', cx: 2430, cy: 65, labelSide: 'L' },
      { id: 't_adm_in', laneId: 'admin', type: 'task', marker: 'user', label: 'Input Email, Pass\n& Kode 2FA Wajib', cx: 2575, cy: 65 },
      { id: 't_adm_cek', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi 2FA TOTP &\nRBAC 3 Peran Admin', cx: 2575, cy: 78 },
      { id: 'd2_adm', laneId: 'sys', type: 'datastore', label: 'D2: Admin\n& RBAC', cx: 2575, cy: 360 },
      { id: 'g_adm_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: '2FA\nValid?', cx: 2785, cy: 78 },
      { id: 'e_adm_fail', laneId: 'sys', type: 'end', symbol: 'error', label: 'Akses Admin\nDitolak', cx: 2915, cy: 78, labelSide: 'R' },
      { id: 't_adm_work', laneId: 'admin', type: 'task', marker: 'user', label: 'Akses Dashboard\nSesuai Peran RBAC', cx: 2785, cy: 65 },
      { id: 'b_adm_idle', type: 'boundary', hostId: 't_adm_work', posRatio: 0.96, symbol: 'timer', label: 'Idle\n30 Menit', cx: 0, cy: 0, labelSide: 'R' },
      { id: 't_adm_end', laneId: 'admin', type: 'task', marker: 'user', label: 'Akhiri Sesi / Logout\nPortal Admin', cx: 3045, cy: 65 },
      { id: 'e_adm_out', laneId: 'admin', type: 'end', symbol: 'general', label: 'Sesi Admin\nBerakhir', cx: 3190, cy: 65, labelSide: 'R' }
    ],
    edges: [
      // Band A: Auth
      { src: 's_auth', dst: 't_pick_auth', srcSide: 'R', dstSide: 'L' },
      { src: 't_pick_auth', dst: 'g_auth_m', srcSide: 'R', dstSide: 'L' },
      { src: 'g_auth_m', dst: 't_auth_wa', srcSide: 'T', dstSide: 'L', label: 'No. HP/WA' },
      { src: 'g_auth_m', dst: 't_auth_email', srcSide: 'R', dstSide: 'L', label: 'Email & Pass' },
      { src: 'g_auth_m', dst: 't_auth_google', srcSide: 'B', dstSide: 'L', label: 'Google OAuth' },
      { src: 't_auth_wa', dst: 'g_auth_join', srcSide: 'R', dstSide: 'T' },
      { src: 't_auth_email', dst: 'g_auth_join', srcSide: 'R', dstSide: 'L' },
      { src: 't_auth_google', dst: 'g_auth_join', srcSide: 'R', dstSide: 'B' },
      { src: 'g_auth_join', dst: 't_cek_dup', srcSide: 'R', dstSide: 'T' },
      { src: 't_cek_dup', dst: 'g_need_otp', srcSide: 'R', dstSide: 'L' },
      { src: 'g_need_otp', dst: 't_activate_sess', srcSide: 'R', dstSide: 'L', label: 'Sesi Sudah Valid' },
      { src: 'g_need_otp', dst: 'sp_otp_auth', srcSide: 'B', dstSide: 'L', label: 'Verifikasi OTP' },
      { src: 'sp_otp_auth', dst: 't_activate_sess', srcSide: 'R', dstSide: 'B' },
      { src: 'b_otp_err', dst: 'e_otp_fail', srcSide: 'B', dstSide: 'R' },
      { src: 'sp_otp_auth', dst: 'ann_inv02', srcSide: 'R', dstSide: 'L', kind: 'data' },
      { src: 'sp_otp_auth', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Kirim OTP (WA/SMS/Email)' },
      { src: 'ext_otp', dst: 'sp_otp_auth', srcSide: 'T', dstSide: 'B', kind: 'message', label: 'Status Kirim' },
      { src: 't_activate_sess', dst: 'd1_auth', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_activate_sess', dst: 't_switch_mode', srcSide: 'T', dstSide: 'B' },
      { src: 't_switch_mode', dst: 'e_auth_ok', srcSide: 'R', dstSide: 'L' },

      // Band B1: Alamat
      { src: 's_addr', dst: 't_addr_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_addr_in', dst: 't_geo_cek', srcSide: 'B', dstSide: 'T' },
      { src: 't_geo_cek', dst: 'ext_maps', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Cek Koordinat Sarbagita' },
      { src: 't_geo_cek', dst: 'g_geo_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_geo_ok', dst: 'e_geo_fail', srcSide: 'B', dstSide: 'T', label: 'Tidak' },
      { src: 'g_geo_ok', dst: 't_addr_save', srcSide: 'R', dstSide: 'L', label: 'Ya' },
      { src: 't_addr_save', dst: 'd1_auth', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 't_addr_save', dst: 'e_addr_ok', srcSide: 'T', dstSide: 'B' },

      // Band B2: Profil & Keamanan
      { src: 's_prof', dst: 't_prof_pick', srcSide: 'R', dstSide: 'L' },
      { src: 't_prof_pick', dst: 'g_prof_1', srcSide: 'R', dstSide: 'L' },
      { src: 'g_prof_1', dst: 't_pin_in', srcSide: 'R', dstSide: 'L', label: 'PIN Saldo' },
      { src: 'g_prof_1', dst: 't_hp_in', srcSide: 'T', dstSide: 'L', label: 'Ubah HP' },
      { src: 'g_prof_1', dst: 'g_prof_2', srcSide: 'B', dstSide: 'T' },
      { src: 'g_prof_2', dst: 't_logout_u', srcSide: 'R', dstSide: 'L', label: 'Logout' },
      { src: 'g_prof_2', dst: 't_close_req', srcSide: 'B', dstSide: 'L', label: 'Tutup Akun' },

      { src: 't_pin_in', dst: 't_pin_save', srcSide: 'R', dstSide: 'T' },
      { src: 't_pin_save', dst: 'd1_auth', srcSide: 'B', dstSide: 'B', kind: 'data' },
      { src: 't_pin_save', dst: 'e_pin_ok', srcSide: 'B', dstSide: 'T' },

      { src: 't_hp_in', dst: 'sp_hp_otp', srcSide: 'R', dstSide: 'T' },
      { src: 'sp_hp_otp', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'OTP HP Baru & Notif Lama' },
      { src: 'sp_hp_otp', dst: 'e_hp_ok', srcSide: 'R', dstSide: 'L' },

      { src: 't_logout_u', dst: 't_revoke_u', srcSide: 'R', dstSide: 'T' },
      { src: 't_revoke_u', dst: 'e_logout_u', srcSide: 'B', dstSide: 'T' },

      { src: 't_close_req', dst: 't_close_cek', srcSide: 'R', dstSide: 'T' },
      { src: 'd3_cek', dst: 't_close_cek', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd7_cek', dst: 't_close_cek', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd11_cek', dst: 't_close_cek', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_close_cek', dst: 'g_close_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_close_ok', dst: 'e_close_no', srcSide: 'B', dstSide: 'T', label: 'Ada Sisa/Aktif' },
      { src: 'g_close_ok', dst: 'sp_close_otp', srcSide: 'R', dstSide: 'L', label: 'Bersih' },
      { src: 'sp_close_otp', dst: 't_close_anon', srcSide: 'R', dstSide: 'L' },
      { src: 't_close_anon', dst: 'e_close_ok', srcSide: 'B', dstSide: 'T' },

      // Band C: Admin Auth & RBAC
      { src: 's_adm', dst: 't_adm_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_adm_in', dst: 't_adm_cek', srcSide: 'R', dstSide: 'T' },
      { src: 'd2_adm', dst: 't_adm_cek', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_adm_cek', dst: 'g_adm_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_adm_ok', dst: 'e_adm_fail', srcSide: 'R', dstSide: 'L', label: 'Gagal' },
      { src: 'g_adm_ok', dst: 't_adm_work', srcSide: 'B', dstSide: 'T', label: 'Valid' },
      { src: 't_adm_work', dst: 't_adm_end', srcSide: 'R', dstSide: 'L', label: 'Logout' },
      { src: 'b_adm_idle', dst: 't_adm_end', srcSide: 'B', dstSide: 'B' },
      { src: 't_adm_end', dst: 'e_adm_out', srcSide: 'R', dstSide: 'L' }
    ]
  },

  // =========================================================================
  // HALAMAN 02: MANAJEMEN TOKO, KYC & KATALOG PRODUK
  // =========================================================================
  {
    id: 'p2',
    name: '02. Toko, KYC & Katalog',
    pngName: '02- BPMN Manajemen Toko, KYC & Katalog Produk.drawio.png',
    lanes: [
      { id: 'seller', label: 'Pembeli / Penjual UMKM', height: 275 },
      { id: 'ops', label: 'Admin Operasional / KYC', height: 155 },
      { id: 'super', label: 'Super Admin', height: 135 },
      { id: 'sys', label: 'Sistem MyPeken', height: 390, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_maps', label: 'Maps API', cx: 360, w: 165 },
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 790, w: 215 },
      { id: 'ext_pg', label: 'Payment Gateway', cx: 1350, w: 185 }
    ],
    nodes: [
      // --- Cluster 1: Pembukaan Toko & Verifikasi KYC (FR-004, FR-027) ---
      { id: 's_kyc', laneId: 'seller', type: 'start', symbol: 'general', label: 'Tekan Buka\nToko Gratis', cx: 45, cy: 74, labelSide: 'B' },
      { id: 't_kyc_form', laneId: 'seller', type: 'task', marker: 'user', label: 'Isi Profil, KTP, Selfie,\nRekening, GPS & >=1 Kurir', cx: 195, cy: 74 },
      { id: 'do_kyc', laneId: 'seller', type: 'dataobject', label: 'Dokumen KYC\n(KTP, Selfie, Rek)', cx: 195, cy: 195 },

      { id: 't_kyc_pre', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Blacklist NIK/Rek\n& GPS Sarbagita (INV-01/03)', cx: 360, cy: 78 },
      { id: 'd15_bl', laneId: 'sys', type: 'datastore', label: 'D15: Blacklist\n& Abuse', cx: 210, cy: 210 },
      { id: 'g_kyc_pre', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Lolos\nPre-Check?', cx: 510, cy: 78, labelSide: 'T' },
      { id: 'e_kyc_auto_no', laneId: 'sys', type: 'end', symbol: 'error', label: 'Ditolak Otomatis\n(Blacklist/Luar Area)', cx: 510, cy: 205, labelSide: 'B' },
      { id: 't_kyc_wait', laneId: 'sys', type: 'task', marker: 'service', label: 'Simpan Status\nMenunggu Verifikasi', cx: 660, cy: 78 },
      { id: 'd3_store', laneId: 'sys', type: 'datastore', label: 'D3: Toko,\nKYC & Kurir', cx: 660, cy: 295 },

      { id: 't_adm_kyc', laneId: 'ops', type: 'task', marker: 'user', label: 'Tinjau KTP, Selfie,\nRekening & Pin GPS', cx: 660, cy: 76 },
      { id: 'g_kyc_dec', laneId: 'ops', type: 'gateway', gwType: 'exclusive', label: 'Setuju?', cx: 810, cy: 76, labelSide: 'T' },
      { id: 't_kyc_rej_rsn', laneId: 'ops', type: 'task', marker: 'user', label: 'Input Alasan\nPenolakan Wajib', cx: 955, cy: 76 },

      { id: 't_kyc_rej_sys', laneId: 'sys', type: 'task', marker: 'send', label: 'Set Ditolak & Kirim\nNotif Perbaikan Data', cx: 955, cy: 185 },
      { id: 'g_kyc_par', laneId: 'sys', type: 'gateway', gwType: 'parallel', label: '', cx: 810, cy: 78 },
      { id: 't_kyc_act', laneId: 'sys', type: 'task', marker: 'service', label: 'Aktifkan Toko &\nUpgrade Role SELLER', cx: 955, cy: 78 },
      { id: 't_kyc_wa', laneId: 'sys', type: 'task', marker: 'send', label: 'Kirim Notif WA\nToko Resmi Aktif', cx: 810, cy: 285 },
      { id: 'd1_upd', laneId: 'sys', type: 'datastore', label: 'D1: Pengguna', cx: 955, cy: 295 },
      { id: 'sp_audit_kyc', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Catat Audit Log\nImmutable (FR-029)', cx: 1125, cy: 135 },
      { id: 'd16_aud', laneId: 'sys', type: 'datastore', label: 'D16: Notif &\nAudit Log', cx: 1125, cy: 295 },
      { id: 'e_kyc_done', laneId: 'sys', type: 'end', symbol: 'general', label: 'KYC Toko\nDiputuskan', cx: 1245, cy: 135, labelSide: 'R' },

      // --- Cluster 2: Pengaturan Toko & Ubah Rekening (FR-016, FR-037, FR-035) ---
      { id: 's_set', laneId: 'seller', type: 'start', symbol: 'general', label: 'Pengaturan\nToko', cx: 910, cy: 185, labelSide: 'L' },
      { id: 't_set_form', laneId: 'seller', type: 'task', marker: 'user', label: 'Ubah Profil, GPS, Jam,\nLibur atau Kurir (>=1)', cx: 1065, cy: 185 },
      { id: 't_set_save', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi Nama Unik, GPS,\n>=1 Kurir & Timer Order', cx: 1215, cy: 215 },
      { id: 'e_set_ok', laneId: 'seller', type: 'end', symbol: 'general', label: 'Pengaturan\nTersimpan', cx: 1215, cy: 74, labelSide: 'T' },

      { id: 's_bank', laneId: 'seller', type: 'start', symbol: 'general', label: 'Ubah\nRekening', cx: 1335, cy: 74, labelSide: 'L' },
      { id: 't_bank_cek', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Bebas WD Pending\n& Saldo Ditahan', cx: 1370, cy: 78 },
      { id: 'd11_wd', laneId: 'sys', type: 'datastore', label: 'D11: Saldo &\nHold', cx: 1370, cy: 295 },
      { id: 'g_bank_lock', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Bebas\nLock?', cx: 1510, cy: 78, labelSide: 'T' },
      { id: 'e_bank_lock', laneId: 'sys', type: 'end', symbol: 'error', label: 'Blokir Ubah\nRekening', cx: 1510, cy: 295, labelSide: 'B' },
      { id: 't_bank_in', laneId: 'seller', type: 'task', marker: 'user', label: 'Input Bank &\nNo. Rekening Baru', cx: 1510, cy: 185 },
      { id: 't_bank_inq', laneId: 'sys', type: 'task', marker: 'service', label: 'Inquiry Nama Pemilik\nRekening vs KTP KYC', cx: 1655, cy: 78 },
      { id: 'g_bank_match', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Cocok?', cx: 1795, cy: 78, labelSide: 'T' },
      { id: 'sp_bank_sec', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Verifikasi PIN Saldo\n& OTP + Update Rek', cx: 1795, cy: 195 },
      { id: 'e_bank_auto', laneId: 'sys', type: 'end', symbol: 'general', label: 'Rekening\nDiperbarui', cx: 1795, cy: 300, labelSide: 'B' },
      { id: 't_bank_fb', laneId: 'seller', type: 'task', marker: 'user', label: 'Ajukan Verifikasi Manual\n+ Bukti Buku Tabungan', cx: 1675, cy: 185 },
      { id: 't_adm_bank', laneId: 'super', type: 'task', marker: 'user', label: 'Tinjau & Putuskan\nManual + Alasan Wajib', cx: 1945, cy: 68 },
      { id: 'sp_bank_aud', laneId: 'sys', type: 'subprocess', marker: 'service', label: 'Update Rekening &\nAudit Log (FR-029)', cx: 1945, cy: 195 },
      { id: 'e_bank_man', laneId: 'sys', type: 'end', symbol: 'general', label: 'Putusan\nTersimpan', cx: 1945, cy: 300, labelSide: 'B' },

      // --- Cluster 3: Manajemen Katalog, Varian, Etalase & Diskon (FR-005) ---
      { id: 's_cat', laneId: 'seller', type: 'start', symbol: 'general', label: 'Kelola Produk\n& Etalase', cx: 1845, cy: 135, labelSide: 'L' },
      { id: 'g_cat_act', laneId: 'seller', type: 'gateway', gwType: 'exclusive', label: '', cx: 1975, cy: 135 },
      { id: 't_prod_crud', laneId: 'seller', type: 'task', marker: 'user', label: 'CRUD Produk, Varian 2-Lvl,\nBerat, PxLxT & Diskon', cx: 2175, cy: 52 },
      { id: 't_showcase', laneId: 'seller', type: 'task', marker: 'user', label: 'Kelola Etalase Toko\n(Maks 10 Etalase)', cx: 2175, cy: 135 },
      { id: 't_prod_hide', laneId: 'seller', type: 'task', marker: 'user', label: 'Nonaktifkan (Hide) atau\nHapus Produk (Soft)', cx: 2175, cy: 218 },
      { id: 't_cat_save', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi Diskon 1-90%,\nSimpan & Jaga Snapshot', cx: 2385, cy: 145 },
      { id: 'd4_cat', laneId: 'sys', type: 'datastore', label: 'D4: Kategori', cx: 2235, cy: 295 },
      { id: 'd5_prod', laneId: 'sys', type: 'datastore', label: 'D5: Produk,\nVarian & Etalase', cx: 2385, cy: 295 },
      { id: 'e_cat_done', laneId: 'sys', type: 'end', symbol: 'general', label: 'Katalog\nDiperbarui', cx: 2515, cy: 145, labelSide: 'R' }
    ],
    edges: [
      // Cluster 1
      { src: 's_kyc', dst: 't_kyc_form', srcSide: 'R', dstSide: 'L' },
      { src: 't_kyc_form', dst: 'do_kyc', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_kyc_form', dst: 't_kyc_pre', srcSide: 'R', dstSide: 'T' },
      { src: 'd15_bl', dst: 't_kyc_pre', srcSide: 'T', dstSide: 'L', kind: 'data' },
      { src: 't_kyc_pre', dst: 'ext_maps', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Validasi Sarbagita' },
      { src: 't_kyc_pre', dst: 'g_kyc_pre', srcSide: 'R', dstSide: 'L' },
      { src: 'g_kyc_pre', dst: 'e_kyc_auto_no', srcSide: 'B', dstSide: 'T', label: 'Blacklist / Luar Area' },
      { src: 'g_kyc_pre', dst: 't_kyc_wait', srcSide: 'R', dstSide: 'L', label: 'Lolos' },
      { src: 't_kyc_wait', dst: 'd3_store', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_kyc_wait', dst: 't_adm_kyc', srcSide: 'T', dstSide: 'B' },
      { src: 't_adm_kyc', dst: 'g_kyc_dec', srcSide: 'R', dstSide: 'L' },
      { src: 'g_kyc_dec', dst: 't_kyc_rej_rsn', srcSide: 'R', dstSide: 'L', label: 'Tolak' },
      { src: 't_kyc_rej_rsn', dst: 't_kyc_rej_sys', srcSide: 'B', dstSide: 'T' },
      { src: 't_kyc_rej_sys', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Notif Tolak' },
      { src: 't_kyc_rej_sys', dst: 'sp_audit_kyc', srcSide: 'R', dstSide: 'L' },
      { src: 'g_kyc_dec', dst: 'g_kyc_par', srcSide: 'B', dstSide: 'T', label: 'Setujui' },
      { src: 'g_kyc_par', dst: 't_kyc_act', srcSide: 'R', dstSide: 'L' },
      { src: 'g_kyc_par', dst: 't_kyc_wa', srcSide: 'B', dstSide: 'T' },
      { src: 't_kyc_act', dst: 'd1_upd', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_kyc_act', dst: 'sp_audit_kyc', srcSide: 'R', dstSide: 'T' },
      { src: 't_kyc_wa', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'WA Toko Aktif' },
      { src: 't_kyc_wa', dst: 'sp_audit_kyc', srcSide: 'R', dstSide: 'B' },
      { src: 'sp_audit_kyc', dst: 'd16_aud', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 'sp_audit_kyc', dst: 'e_kyc_done', srcSide: 'R', dstSide: 'L' },

      // Cluster 2A: Setting Toko
      { src: 's_set', dst: 't_set_form', srcSide: 'R', dstSide: 'L' },
      { src: 't_set_form', dst: 't_set_save', srcSide: 'R', dstSide: 'T' },
      { src: 't_set_save', dst: 'ext_maps', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Cek GPS Baru' },
      { src: 't_set_save', dst: 'd3_store', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 't_set_save', dst: 'e_set_ok', srcSide: 'T', dstSide: 'B' },

      // Cluster 2B: Ubah Rekening
      { src: 's_bank', dst: 't_bank_cek', srcSide: 'R', dstSide: 'T' },
      { src: 'd11_wd', dst: 't_bank_cek', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_bank_cek', dst: 'g_bank_lock', srcSide: 'R', dstSide: 'L' },
      { src: 'g_bank_lock', dst: 'e_bank_lock', srcSide: 'B', dstSide: 'T', label: 'Pending/Hold' },
      { src: 'g_bank_lock', dst: 't_bank_in', srcSide: 'R', dstSide: 'B', label: 'Bebas' },
      { src: 't_bank_in', dst: 't_bank_inq', srcSide: 'R', dstSide: 'T' },
      { src: 't_bank_inq', dst: 'ext_pg', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Bank Account Inquiry' },
      { src: 'ext_pg', dst: 't_bank_inq', srcSide: 'T', dstSide: 'L', kind: 'message', label: 'Nama Pemilik' },
      { src: 't_bank_inq', dst: 'g_bank_match', srcSide: 'R', dstSide: 'L' },
      { src: 'g_bank_match', dst: 'sp_bank_sec', srcSide: 'B', dstSide: 'T', label: 'Cocok KTP' },
      { src: 'sp_bank_sec', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'OTP & Notif Rek' },
      { src: 'sp_bank_sec', dst: 'e_bank_auto', srcSide: 'B', dstSide: 'T' },
      { src: 'g_bank_match', dst: 't_bank_fb', srcSide: 'R', dstSide: 'R', label: 'Beda Penulisan' },
      { src: 't_bank_fb', dst: 't_adm_bank', srcSide: 'R', dstSide: 'L' },
      { src: 't_adm_bank', dst: 'sp_bank_aud', srcSide: 'B', dstSide: 'T' },
      { src: 'sp_bank_aud', dst: 'd16_aud', srcSide: 'L', dstSide: 'R', kind: 'data' },
      { src: 'sp_bank_aud', dst: 'e_bank_man', srcSide: 'B', dstSide: 'T' },

      // Cluster 3: Katalog
      { src: 's_cat', dst: 'g_cat_act', srcSide: 'R', dstSide: 'L' },
      { src: 'g_cat_act', dst: 't_prod_crud', srcSide: 'T', dstSide: 'L', label: 'Produk/Varian' },
      { src: 'g_cat_act', dst: 't_showcase', srcSide: 'R', dstSide: 'L', label: 'Etalase' },
      { src: 't_prod_crud', dst: 't_cat_save', srcSide: 'R', dstSide: 'T' },
      { src: 't_showcase', dst: 't_cat_save', srcSide: 'R', dstSide: 'L' },
      { src: 'g_cat_act', dst: 't_prod_hide', srcSide: 'B', dstSide: 'L', label: 'Hide/Hapus' },
      { src: 't_prod_hide', dst: 't_cat_save', srcSide: 'R', dstSide: 'B' },
      { src: 'd4_cat', dst: 't_cat_save', srcSide: 'T', dstSide: 'L', kind: 'data' },
      { src: 't_cat_save', dst: 'd5_prod', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_cat_save', dst: 'e_cat_done', srcSide: 'R', dstSide: 'L' }
    ]
  },

  // =========================================================================
  // HALAMAN 03: EKSPLORASI KATALOG, ASISTEN AI & INTERAKSI SOSIAL
  // =========================================================================
  {
    id: 'p3',
    name: '03. Eksplorasi, AI & Chat',
    pngName: '03- BPMN Eksplorasi Katalog, Asisten AI & Chat.drawio.png',
    lanes: [
      { id: 'guest', label: 'Pengunjung (Guest)', height: 190 },
      { id: 'buyer', label: 'Pembeli', height: 225 },
      { id: 'seller', label: 'Penjual UMKM', height: 130 },
      { id: 'admin_cs', label: 'Admin CS', height: 135 },
      { id: 'sys', label: 'Sistem MyPeken', height: 395, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_maps', label: 'Maps API', cx: 430, w: 165 },
      { id: 'ext_ai', label: 'API AI / LLM', cx: 1715, w: 180 },
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 2295, w: 215 }
    ],
    nodes: [
      // --- Cluster 1: Beranda Guest, Filter & LBS Terdekat (FR-031, FR-026, FR-011) ---
      { id: 's_exp', laneId: 'guest', type: 'start', symbol: 'general', label: 'Buka Beranda\n(Guest Mode)', cx: 45, cy: 95, labelSide: 'T' },
      { id: 't_load_home', laneId: 'sys', type: 'task', marker: 'service', label: 'Muat Banner, Kategori\n& Katalog Diskon Coret', cx: 175, cy: 78 },
      { id: 'd4_ban', laneId: 'sys', type: 'datastore', label: 'D4: Kategori\n& Banner', cx: 95, cy: 255 },
      { id: 'd5_cat', laneId: 'sys', type: 'datastore', label: 'D5: Produk\n& Etalase', cx: 230, cy: 255 },
      { id: 't_browse', laneId: 'guest', type: 'task', marker: 'user', label: 'Jelajahi Detail Produk,\nToko Publik & Filter', cx: 295, cy: 95 },
      { id: 'g_lbs', laneId: 'guest', type: 'gateway', gwType: 'exclusive', label: 'Urut\nTerdekat?', cx: 430, cy: 95, labelSide: 'T' },
      { id: 't_std_flt', laneId: 'sys', type: 'task', marker: 'service', label: 'Filter Kategori, Sarbagita,\nHarga, Kurir & Rating', cx: 345, cy: 175 },
      { id: 't_lbs_gps', laneId: 'sys', type: 'task', marker: 'service', label: 'Minta Izin GPS &\nHitung Radius km (LBS)', cx: 525, cy: 78 },
      { id: 'g_gps_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Izin\nGPS?', cx: 525, cy: 185, labelSide: 'L' },
      { id: 't_lbs_fb', laneId: 'sys', type: 'task', marker: 'service', label: 'Pakai Alamat Utama /\nDefault Denpasar', cx: 705, cy: 185 },
      { id: 'd1_addr', laneId: 'sys', type: 'datastore', label: 'D1: Pengguna\n& Alamat', cx: 705, cy: 295 },
      { id: 'd3_toko', laneId: 'sys', type: 'datastore', label: 'D3: Lokasi\nToko', cx: 360, cy: 295 },
      { id: 'd9_rev', laneId: 'sys', type: 'datastore', label: 'D9: Ulasan', cx: 490, cy: 295 },
      { id: 't_prot_act', laneId: 'guest', type: 'task', marker: 'user', label: 'Klik Aksi Terproteksi\n(Beli/Keranjang/Chat/Lapor)', cx: 705, cy: 95 },
      { id: 'g_is_login', laneId: 'guest', type: 'gateway', gwType: 'exclusive', label: 'Login?', cx: 845, cy: 95, labelSide: 'B' },
      { id: 'e_need_login', laneId: 'guest', type: 'end', symbol: 'escalation', label: 'Arahkan ke\nLogin (FR-001)', cx: 965, cy: 48, labelSide: 'R' },
      { id: 'e_exp_ok', laneId: 'guest', type: 'end', symbol: 'general', label: 'Lanjut Fitur\nTerproteksi', cx: 965, cy: 128, labelSide: 'R' },

      // --- Cluster 2: Wishlist, Ikuti Toko & Report Abuse (FR-039, FR-040) ---
      { id: 's_wish', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Wishlist /\nIkuti Toko', cx: 965, cy: 62, labelSide: 'L' },
      { id: 't_wish_save', laneId: 'sys', type: 'task', marker: 'service', label: 'Simpan / Hapus\nWishlist & Follow Toko', cx: 965, cy: 185 },
      { id: 'd14_wish', laneId: 'sys', type: 'datastore', label: 'D14: Wishlist\n& Ikuti Toko', cx: 965, cy: 295 },
      { id: 'e_wish_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Favorit\nDiperbarui', cx: 1095, cy: 185, labelSide: 'R' },

      { id: 's_rep', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Lapor Produk/\nToko/Ulasan', cx: 1135, cy: 62, labelSide: 'T' },
      { id: 't_rep_form', laneId: 'buyer', type: 'task', marker: 'user', label: 'Pilih Kategori, Isi Alasan\n& Unggah <=3 Foto Bukti', cx: 1275, cy: 62 },
      { id: 't_rep_val', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi Anti Self-Report\n& 1 Laporan Aktif/Objek', cx: 1275, cy: 185 },
      { id: 'd15_ab', laneId: 'sys', type: 'datastore', label: 'D15: Laporan\nAbuse', cx: 1275, cy: 295 },
      { id: 'g_rep_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Valid?', cx: 1415, cy: 185, labelSide: 'T' },
      { id: 'e_rep_no', laneId: 'sys', type: 'end', symbol: 'error', label: 'Laporan\nDitolak', cx: 1415, cy: 295, labelSide: 'B' },
      { id: 'e_rep_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'Masuk Antrean\nAdmin (FR-018)', cx: 1535, cy: 185, labelSide: 'R' },

      // --- Cluster 3: Asisten Virtual AI & Live Chat Admin CS (FR-003, FR-017) ---
      { id: 's_ai', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Buka\nBantuan AI', cx: 1625, cy: 62, labelSide: 'L' },
      { id: 't_ai_ask', laneId: 'buyer', type: 'task', marker: 'user', label: 'Kirim Pertanyaan FAQ\n/ Nomor Pesanan', cx: 1775, cy: 62 },
      { id: 't_ai_proc', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Order Milik User\n& Query AI Knowledge', cx: 1775, cy: 175 },
      { id: 'd7_ord', laneId: 'sys', type: 'datastore', label: 'D7: Pesanan', cx: 1715, cy: 295 },
      { id: 'd12_ai', laneId: 'sys', type: 'datastore', label: 'D12: Sesi &\nPesan AI', cx: 1845, cy: 295 },
      { id: 't_ai_view', laneId: 'buyer', type: 'task', marker: 'user', label: 'Baca Jawaban AI &\nPilih Eskalasi Admin?', cx: 1945, cy: 62 },
      { id: 'g_ai_esc', laneId: 'buyer', type: 'gateway', gwType: 'exclusive', label: 'Eskalasi?', cx: 1945, cy: 165, labelSide: 'L' },
      { id: 'e_ai_ok', laneId: 'buyer', type: 'end', symbol: 'general', label: 'Selesai di AI', cx: 2085, cy: 165, labelSide: 'R' },
      { id: 't_cs_chat', laneId: 'admin_cs', type: 'task', marker: 'user', label: 'Baca Riwayat AI, Balas\nReal-Time & Tandai Selesai', cx: 1945, cy: 68 },
      { id: 'e_cs_ok', laneId: 'admin_cs', type: 'end', symbol: 'general', label: 'Sesi Live Chat\nSelesai', cx: 2115, cy: 68, labelSide: 'R' },

      // --- Cluster 4: Direct Chat Pembeli & Penjual (FR-036) ---
      { id: 's_dc', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Tekan Chat\nPenjual', cx: 2185, cy: 62, labelSide: 'T' },
      { id: 't_dc_send', laneId: 'buyer', type: 'task', marker: 'user', label: 'Kirim Teks, Kartu Produk\natau Gambar <=5MB', cx: 2335, cy: 62 },
      { id: 't_dc_sys', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi Anti Self-Chat,\nBanner Escrow & Simpan Chat', cx: 2335, cy: 175 },
      { id: 'd13_dc', laneId: 'sys', type: 'datastore', label: 'D13: Chat\nPermanen', cx: 2270, cy: 295 },
      { id: 'd16_dc', laneId: 'sys', type: 'datastore', label: 'D16: Notif', cx: 2405, cy: 295 },
      { id: 't_dc_reply', laneId: 'seller', type: 'task', marker: 'user', label: 'Terima Unread Badge &\nBalas Chat Pembeli', cx: 2515, cy: 65 },
      { id: 'e_dc_ok', laneId: 'seller', type: 'end', symbol: 'general', label: 'Riwayat Chat\nTersimpan', cx: 2655, cy: 65, labelSide: 'R' }
    ],
    edges: [
      // Cluster 1
      { src: 's_exp', dst: 't_load_home', srcSide: 'B', dstSide: 'T' },
      { src: 'd4_ban', dst: 't_load_home', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd5_cat', dst: 't_load_home', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_load_home', dst: 't_browse', srcSide: 'R', dstSide: 'B' },
      { src: 't_browse', dst: 'g_lbs', srcSide: 'R', dstSide: 'L' },
      { src: 'g_lbs', dst: 't_std_flt', srcSide: 'B', dstSide: 'T', label: 'Filter Biasa' },
      { src: 'g_lbs', dst: 't_lbs_gps', srcSide: 'R', dstSide: 'T', label: 'LBS Terdekat' },
      { src: 'd3_toko', dst: 't_std_flt', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 'd9_rev', dst: 't_std_flt', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_std_flt', dst: 't_prot_act', srcSide: 'R', dstSide: 'B' },
      { src: 't_lbs_gps', dst: 'g_gps_ok', srcSide: 'B', dstSide: 'T' },
      { src: 'g_gps_ok', dst: 'ext_maps', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Hitung Radius km' },
      { src: 'g_gps_ok', dst: 't_lbs_fb', srcSide: 'R', dstSide: 'L', label: 'Ditolak' },
      { src: 'd1_addr', dst: 't_lbs_fb', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_lbs_fb', dst: 't_prot_act', srcSide: 'T', dstSide: 'B' },
      { src: 't_prot_act', dst: 'g_is_login', srcSide: 'R', dstSide: 'L' },
      { src: 'g_is_login', dst: 'e_need_login', srcSide: 'T', dstSide: 'L', label: 'Belum' },
      { src: 'g_is_login', dst: 'e_exp_ok', srcSide: 'R', dstSide: 'L', label: 'Sudah' },

      // Cluster 2
      { src: 's_wish', dst: 't_wish_save', srcSide: 'B', dstSide: 'T' },
      { src: 't_wish_save', dst: 'd14_wish', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_wish_save', dst: 'e_wish_ok', srcSide: 'R', dstSide: 'L' },

      { src: 's_rep', dst: 't_rep_form', srcSide: 'R', dstSide: 'L' },
      { src: 't_rep_form', dst: 't_rep_val', srcSide: 'B', dstSide: 'T' },
      { src: 't_rep_val', dst: 'd15_ab', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_rep_val', dst: 'g_rep_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_rep_ok', dst: 'e_rep_no', srcSide: 'B', dstSide: 'T', label: 'Duplikat' },
      { src: 'g_rep_ok', dst: 'e_rep_ok', srcSide: 'R', dstSide: 'L', label: 'Valid' },

      // Cluster 3
      { src: 's_ai', dst: 't_ai_ask', srcSide: 'R', dstSide: 'L' },
      { src: 't_ai_ask', dst: 't_ai_proc', srcSide: 'B', dstSide: 'T' },
      { src: 'd7_ord', dst: 't_ai_proc', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_ai_proc', dst: 'd12_ai', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_ai_proc', dst: 'ext_ai', srcSide: 'L', dstSide: 'T', kind: 'message', label: 'Prompt Konteks' },
      { src: 'ext_ai', dst: 't_ai_proc', srcSide: 'T', dstSide: 'R', kind: 'message', label: 'Jawaban AI' },
      { src: 't_ai_proc', dst: 't_ai_view', srcSide: 'T', dstSide: 'B' },
      { src: 't_ai_view', dst: 'g_ai_esc', srcSide: 'B', dstSide: 'T' },
      { src: 'g_ai_esc', dst: 'e_ai_ok', srcSide: 'R', dstSide: 'L', label: 'Selesai' },
      { src: 'g_ai_esc', dst: 't_cs_chat', srcSide: 'B', dstSide: 'T', label: 'Hubungkan Admin' },
      { src: 't_cs_chat', dst: 'e_cs_ok', srcSide: 'R', dstSide: 'L' },

      // Cluster 4
      { src: 's_dc', dst: 't_dc_send', srcSide: 'R', dstSide: 'L' },
      { src: 't_dc_send', dst: 't_dc_sys', srcSide: 'B', dstSide: 'T' },
      { src: 't_dc_sys', dst: 'd13_dc', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_dc_sys', dst: 'd16_dc', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_dc_sys', dst: 'ext_otp', srcSide: 'L', dstSide: 'T', kind: 'message', label: 'Push Notif Chat' },
      { src: 't_dc_sys', dst: 't_dc_reply', srcSide: 'R', dstSide: 'B' },
      { src: 't_dc_reply', dst: 'e_dc_ok', srcSide: 'R', dstSide: 'L' }
    ]
  },

  // =========================================================================
  // HALAMAN 04: KERANJANG, CHECKOUT, ESCROW & PPOB
  // =========================================================================
  {
    id: 'p4',
    name: '04. Keranjang, Checkout & PPOB',
    pngName: '04- BPMN Keranjang, Checkout, Escrow & PPOB.drawio.png',
    lanes: [
      { id: 'buyer', label: 'Pembeli', height: 270 },
      { id: 'seller', label: 'Penjual UMKM', height: 125 },
      { id: 'sys', label: 'Sistem MyPeken', height: 470, isSystem: true }
    ],
    externalPools: [
      { id: 'ext_maps', label: 'Maps API', cx: 430, w: 165 },
      { id: 'ext_log', label: 'API Logistik', cx: 795, w: 170 },
      { id: 'ext_ppob', label: 'API Biller PPOB', cx: 990, w: 180 },
      { id: 'ext_pg', label: 'Payment Gateway', cx: 1555, w: 185 },
      { id: 'ext_otp', label: 'Gateway OTP & Notifikasi\n(WA / SMS / Email)', cx: 2305, w: 215 }
    ],
    nodes: [
      // --- Jalur Utama (Track 0): Keranjang / Direct Checkout Fisik + Escrow (FR-023, FR-012, FR-008, FR-007) ---
      { id: 's_buy', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Belanja\nProduk Fisik', cx: 45, cy: 75, labelSide: 'B' },
      { id: 'g_cart_dir', laneId: 'buyer', type: 'gateway', gwType: 'exclusive', label: 'Jalur?', cx: 155, cy: 75 },
      { id: 't_cart_add', laneId: 'buyer', type: 'task', marker: 'user', label: 'Kelola Keranjang &\nPilih Item 1 Toko', cx: 315, cy: 42 },
      { id: 't_direct_buy', laneId: 'buyer', type: 'task', marker: 'user', label: 'Tekan Beli Langsung\n(Direct Checkout)', cx: 315, cy: 112 },
      { id: 'g_cart_m', laneId: 'buyer', type: 'gateway', gwType: 'exclusive', label: '', cx: 455, cy: 75 },

      { id: 't_val_scope', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Single-Seller (INV-04),\nAnti Self-Buy, Stok & Toko', cx: 455, cy: 74 },
      { id: 'd6_cart', laneId: 'sys', type: 'datastore', label: 'D6: Keranjang', cx: 315, cy: 195 },
      { id: 'g_scope_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Valid?', cx: 615, cy: 74, labelSide: 'T' },
      { id: 'e_scope_no', laneId: 'sys', type: 'end', symbol: 'error', label: 'Blokir Checkout', cx: 615, cy: 195, labelSide: 'B' },

      { id: 't_ship_calc', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Sarbagita, Volumetrik\n(PxLxT/6000) & Ongkir/ETD', cx: 795, cy: 74 },
      { id: 'g_sar_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Kurir\nOK?', cx: 960, cy: 74 },
      { id: 'e_sar_no', laneId: 'sys', type: 'end', symbol: 'error', label: 'Luar Sarbagita /\nKurir Tidak Valid', cx: 960, cy: 195, labelSide: 'B' },

      { id: 't_pick_ship', laneId: 'buyer', type: 'task', marker: 'user', label: 'Pilih Alamat, Kurir,\nAsuransi (>=500rb Wajib)', cx: 960, cy: 75 },
      { id: 't_pay_click', laneId: 'buyer', type: 'task', marker: 'user', label: 'Tekan Bayar Sekarang\n& Pilih Metode Bayar', cx: 1170, cy: 75 },

      { id: 't_atomic_lock', laneId: 'sys', type: 'task', marker: 'service', label: 'Validasi Atomik, Kunci Stok\n& Snapshot Harga/Komisi (INV-05)', cx: 1170, cy: 74 },
      { id: 'd4_fee', laneId: 'sys', type: 'datastore', label: 'D4: Biaya\n& Komisi', cx: 1090, cy: 195 },
      { id: 'd5_stk', laneId: 'sys', type: 'datastore', label: 'D5: Stok\nProduk', cx: 1225, cy: 195 },
      { id: 'g_inc_pay', laneId: 'sys', type: 'gateway', gwType: 'inclusive', label: 'Metode?', cx: 1365, cy: 74 },
      { id: 't_pin_cut', laneId: 'sys', type: 'task', marker: 'service', label: 'Verifikasi PIN Saldo &\nPotong Reguler Dulu (INV-06)', cx: 1555, cy: 48 },
      { id: 't_pg_inv', laneId: 'sys', type: 'task', marker: 'service', label: 'Buat Tagihan PG\n(QRIS/EW 15m | VA 24j)', cx: 1555, cy: 132 },
      { id: 'g_inc_join', laneId: 'sys', type: 'gateway', gwType: 'inclusive', label: '', cx: 1715, cy: 74 },

      { id: 'g_ev_pay', laneId: 'sys', type: 'gateway', gwType: 'event', label: 'Tunggu\nBayar', cx: 1825, cy: 74, labelSide: 'T' },
      { id: 'ic_pg_ok', laneId: 'sys', type: 'intermediate', symbol: 'message', outline: 'catching', label: 'Lunas (PG /\nFull Saldo)', cx: 1965, cy: 74, labelSide: 'T' },
      { id: 'ic_pg_exp', laneId: 'sys', type: 'intermediate', symbol: 'timer', outline: 'catching', label: 'Kedaluwarsa\n/ Batal Manual', cx: 1825, cy: 195, labelSide: 'L' },
      { id: 't_rel_stk', laneId: 'sys', type: 'task', marker: 'service', label: 'Status Batal, Lepas Stok\n& Kembalikan Split Saldo', cx: 1995, cy: 195 },
      { id: 'e_pay_batal', laneId: 'sys', type: 'end', symbol: 'general', label: 'Tagihan Batal', cx: 2155, cy: 195, labelSide: 'R' },

      { id: 't_escrow_hold', laneId: 'sys', type: 'task', marker: 'service', label: 'Status Dibayar &\nTahan Dana di Escrow', cx: 2130, cy: 74 },
      { id: 'd7_ord', laneId: 'sys', type: 'datastore', label: 'D7: Pesanan\nSnapshot', cx: 2055, cy: 355 },
      { id: 'd8_esc', laneId: 'sys', type: 'datastore', label: 'D8: Escrow\n& PPOB', cx: 2200, cy: 355 },
      { id: 't_notif_seller', laneId: 'sys', type: 'task', marker: 'send', label: 'Kirim Notif Pesanan Baru\n(In-App & WA FR-007)', cx: 2305, cy: 74 },
      { id: 't_rec_seller', laneId: 'seller', type: 'task', marker: 'receive', label: 'Terima Notif Pesanan\nBaru Masuk & SLA', cx: 2305, cy: 62 },
      { id: 'e_checkout_ok', laneId: 'seller', type: 'end', symbol: 'general', label: 'Lanjut Pemenuhan\n(Proses 5.0)', cx: 2455, cy: 62, labelSide: 'R' },

      // --- Jalur Kedua (Track 1): Checkout Cepat Produk Digital PPOB (FR-002) ---
      { id: 's_ppob', laneId: 'buyer', type: 'start', symbol: 'general', label: 'Klik Shortcut\nPPOB', cx: 155, cy: 205, labelSide: 'L' },
      { id: 't_ppob_in', laneId: 'buyer', type: 'task', marker: 'user', label: 'Input No. Tujuan,\nPilih Nominal & Bayar', cx: 615, cy: 205 },
      { id: 't_ppob_exec', laneId: 'sys', type: 'task', marker: 'service', label: 'Cek Katalog, Bayar & Eksekusi\nAPI Biller PPOB (+Admin Flat)', cx: 960, cy: 305 },
      { id: 'g_ppob_ok', laneId: 'sys', type: 'gateway', gwType: 'exclusive', label: 'Biller\nSukses?', cx: 1185, cy: 305 },
      { id: 't_ppob_done', laneId: 'sys', type: 'task', marker: 'service', label: 'Set Selesai & Tampilkan\nToken / Bukti (Non-Escrow)', cx: 1380, cy: 265 },
      { id: 'e_ppob_ok', laneId: 'sys', type: 'end', symbol: 'general', label: 'PPOB\nSelesai', cx: 1535, cy: 265, labelSide: 'R' },
      { id: 't_ppob_ref', laneId: 'sys', type: 'task', marker: 'service', label: 'Set Batal & Auto-Refund 100%\nke Saldo Bebas Biaya Tarik', cx: 1380, cy: 360 },
      { id: 'd11_wal', laneId: 'sys', type: 'datastore', label: 'D11: Saldo Saya', cx: 1645, cy: 360 },
      { id: 'e_ppob_fail', laneId: 'sys', type: 'end', symbol: 'general', label: 'PPOB Gagal\n(Refund 100%)', cx: 1535, cy: 360, labelSide: 'B' }
    ],
    edges: [
      // Fisik Flow
      { src: 's_buy', dst: 'g_cart_dir', srcSide: 'R', dstSide: 'L' },
      { src: 'g_cart_dir', dst: 't_cart_add', srcSide: 'T', dstSide: 'L', label: 'Keranjang' },
      { src: 'g_cart_dir', dst: 't_direct_buy', srcSide: 'B', dstSide: 'L', label: 'Beli Langsung' },
      { src: 't_cart_add', dst: 'g_cart_m', srcSide: 'R', dstSide: 'T' },
      { src: 't_direct_buy', dst: 'g_cart_m', srcSide: 'R', dstSide: 'B' },
      { src: 'g_cart_m', dst: 't_val_scope', srcSide: 'R', dstSide: 'T' },
      { src: 'd6_cart', dst: 't_val_scope', srcSide: 'T', dstSide: 'L', kind: 'data' },
      { src: 't_val_scope', dst: 'g_scope_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_scope_ok', dst: 'e_scope_no', srcSide: 'B', dstSide: 'T', label: 'Tidak' },
      { src: 'g_scope_ok', dst: 't_ship_calc', srcSide: 'R', dstSide: 'L', label: 'Valid' },
      { src: 't_ship_calc', dst: 'ext_maps', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Validasi Rute Sarbagita' },
      { src: 't_ship_calc', dst: 'ext_log', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Ongkir, ETD & Premi' },
      { src: 't_ship_calc', dst: 'g_sar_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_sar_ok', dst: 'e_sar_no', srcSide: 'B', dstSide: 'T', label: 'Gagal' },
      { src: 'g_sar_ok', dst: 't_pick_ship', srcSide: 'T', dstSide: 'B', label: 'Ya' },
      { src: 't_pick_ship', dst: 't_pay_click', srcSide: 'R', dstSide: 'L' },
      { src: 't_pay_click', dst: 't_atomic_lock', srcSide: 'B', dstSide: 'T' },
      { src: 'd4_fee', dst: 't_atomic_lock', srcSide: 'T', dstSide: 'B', kind: 'data' },
      { src: 't_atomic_lock', dst: 'd5_stk', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_atomic_lock', dst: 'g_inc_pay', srcSide: 'R', dstSide: 'L' },
      { src: 'g_inc_pay', dst: 't_pin_cut', srcSide: 'T', dstSide: 'L', label: 'Saldo Saya' },
      { src: 'g_inc_pay', dst: 't_pg_inv', srcSide: 'B', dstSide: 'L', label: 'PG' },
      { src: 't_pg_inv', dst: 'ext_pg', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Buat Tagihan' },
      { src: 't_pin_cut', dst: 'g_inc_join', srcSide: 'R', dstSide: 'T' },
      { src: 't_pg_inv', dst: 'g_inc_join', srcSide: 'R', dstSide: 'B' },
      { src: 'g_inc_join', dst: 'g_ev_pay', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ev_pay', dst: 'ic_pg_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'ext_pg', dst: 'ic_pg_ok', srcSide: 'T', dstSide: 'B', kind: 'message', label: 'Webhook Lunas' },
      { src: 'g_ev_pay', dst: 'ic_pg_exp', srcSide: 'B', dstSide: 'T' },
      { src: 'ic_pg_exp', dst: 't_rel_stk', srcSide: 'R', dstSide: 'L' },
      { src: 't_rel_stk', dst: 'e_pay_batal', srcSide: 'R', dstSide: 'L' },
      { src: 'ic_pg_ok', dst: 't_escrow_hold', srcSide: 'R', dstSide: 'L' },
      { src: 't_escrow_hold', dst: 'd7_ord', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_escrow_hold', dst: 'd8_esc', srcSide: 'B', dstSide: 'T', kind: 'data' },
      { src: 't_escrow_hold', dst: 't_notif_seller', srcSide: 'R', dstSide: 'L' },
      { src: 't_notif_seller', dst: 'ext_otp', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'In-App & WA' },
      { src: 't_notif_seller', dst: 't_rec_seller', srcSide: 'T', dstSide: 'B' },
      { src: 't_rec_seller', dst: 'e_checkout_ok', srcSide: 'R', dstSide: 'L' },

      // PPOB Flow
      { src: 's_ppob', dst: 't_ppob_in', srcSide: 'R', dstSide: 'L' },
      { src: 't_ppob_in', dst: 't_ppob_exec', srcSide: 'B', dstSide: 'T' },
      { src: 't_ppob_exec', dst: 'ext_ppob', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Topup / Token PLN / PDAM' },
      { src: 'ext_ppob', dst: 't_ppob_exec', srcSide: 'T', dstSide: 'L', kind: 'message', label: 'Status Biller' },
      { src: 't_ppob_exec', dst: 'ext_pg', srcSide: 'B', dstSide: 'T', kind: 'message', label: 'Verifikasi Bayar' },
      { src: 't_ppob_exec', dst: 'g_ppob_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ppob_ok', dst: 't_ppob_done', srcSide: 'T', dstSide: 'L', label: 'Sukses' },
      { src: 't_ppob_done', dst: 'e_ppob_ok', srcSide: 'R', dstSide: 'L' },
      { src: 'g_ppob_ok', dst: 't_ppob_ref', srcSide: 'B', dstSide: 'L', label: 'Gagal' },
      { src: 't_ppob_ref', dst: 'd11_wal', srcSide: 'B', dstSide: 'L', kind: 'data' },
      { src: 't_ppob_ref', dst: 'e_ppob_fail', srcSide: 'R', dstSide: 'L' }
    ]
  }
];

module.exports = PAGES_1_4;
