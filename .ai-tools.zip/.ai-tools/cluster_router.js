const lib = require('./diagram_lib');

function cloneNodes(nodes) {
  return nodes.map((n) => ({ ...n }));
}

function nodeCenter(n) {
  return { cx: n.x + n.w * 0.5, cy: n.y + n.h * 0.5 };
}

function chooseBestSide(u, v, counts, capacity, biasSide) {
  const { cx: ux, cy: uy } = nodeCenter(u);
  const { cx: vx, cy: vy } = nodeCenter(v);
  const dx = vx - ux;
  const dy = vy - uy;

  const sideVec = {
    R: [1, 0],
    L: [-1, 0],
    T: [0, -1],
    B: [0, 1]
  };
  const len = Math.hypot(dx, dy) || 1;
  const nx = dx / len;
  const ny = dy / len;

  const candidates = ['T', 'B', 'L', 'R'].map((s) => {
    const [sx, sy] = sideVec[s];
    const dot = nx * sx + ny * sy;
    const cap = Math.max(1, capacity[s] || 4);
    const load = counts[s] / cap;
    let score = dot;
    if (biasSide === 'LR' && (s === 'L' || s === 'R')) score += 0.14;
    if (biasSide === 'TB' && (s === 'T' || s === 'B')) score += 0.14;
    // Penalize over-full sides strongly so high-degree nodes spill onto adjacent faces
    if (counts[s] >= cap) score -= 1.35 + 0.5 * (counts[s] - cap);
    else score -= 0.18 * load;
    return { s, score };
  });

  candidates.sort((a, b) => b.score - a.score);
  return candidates[0].s;
}

function getOppositeSide(side) {
  if (side === 'L') return 'R';
  if (side === 'R') return 'L';
  if (side === 'T') return 'B';
  return 'T';
}

function computeSideCapacities(n, minPortSpacing) {
  const padX = Math.min(20, Math.floor(n.w * 0.16));
  const padY = Math.min(18, Math.floor(n.h * 0.16));
  const usableW = Math.max(16, n.w - 2 * padX);
  const usableH = Math.max(16, n.h - 2 * padY);
  // Circular processes only use central 72% chord so exit points stay strictly radial/cardinal
  const mult = n.kind === 'process' ? 0.72 : 1.0;
  return {
    T: Math.max(1, Math.floor((usableW * mult) / minPortSpacing) + 1),
    B: Math.max(1, Math.floor((usableW * mult) / minPortSpacing) + 1),
    L: Math.max(1, Math.floor((usableH * mult) / minPortSpacing) + 1),
    R: Math.max(1, Math.floor((usableH * mult) / minPortSpacing) + 1)
  };
}

function sideSortKey(u, v, side, edgeIdx, sId, tId) {
  const { cx: ux, cy: uy } = nodeCenter(u);
  const { cx: vx, cy: vy } = nodeCenter(v);
  const dx = vx - ux;
  const dy = vy - uy;
  let primary = 0;
  if (side === 'T') primary = Math.atan2(dy, dx);          // -PI (left) -> 0 (right)
  else if (side === 'B') primary = -Math.atan2(dy, dx);    // -PI (left) -> 0 (right)
  else if (side === 'R') primary = Math.atan2(dy, dx);     // -PI/2 (top) -> +PI/2 (bottom)
  else if (side === 'L') primary = Math.atan2(dy, -dx);    // -PI/2 (top) -> +PI/2 (bottom)
  const dirTie = String(sId) < String(tId) ? 0 : 1;
  return { primary, tie1: dirTie, tie2: edgeIdx };
}

function placePortsOnSide(node, side, list, stubDist) {
  const count = list.length;
  const isHorizSide = side === 'T' || side === 'B';
  const defaultPad = isHorizSide
    ? Math.min(18, Math.max(8, Math.floor(node.w * 0.12)))
    : Math.min(14, Math.max(6, Math.floor(node.h * 0.12)));
  const pad = count >= 5 ? Math.min(defaultPad, 8) : defaultPad;
  const span = (isHorizSide ? node.w : node.h) - 2 * pad;
  const { cx, cy } = nodeCenter(node);
  const a = node.w * 0.5;
  const b = node.h * 0.5;

  for (let idx = 0; idx < count; idx++) {
    const item = list[idx];
    const frac = count === 1 ? 0.5 : (idx + 0.5) / count;
    // Keep circular ports within central chord +/- 0.68 radius so slope stays gentle
    const circleFrac = 0.5 + (frac - 0.5) * 0.68;
    const useFrac = node.kind === 'process' ? circleFrac : frac;
    const baseStub = Math.min(stubDist, 18);
    const layerStub = count > 1 ? baseStub + (idx % 3) * 10 : baseStub;

    let px, py, s1x, s1y;
    if (isHorizSide) {
      px = node.x + pad + useFrac * Math.max(4, span);
      if (node.kind === 'process') {
        const dxNorm = Math.max(-0.92, Math.min(0.92, (px - cx) / Math.max(1, a)));
        const dyCirc = b * Math.sqrt(Math.max(0.05, 1 - dxNorm * dxNorm));
        py = side === 'T' ? cy - dyCirc : cy + dyCirc;
      } else {
        py = side === 'T' ? node.y : node.y + node.h;
      }
      s1x = px;
      s1y = side === 'T' ? Math.min(py - 8, node.y - layerStub) : Math.max(py + 8, node.y + node.h + layerStub);
    } else {
      py = node.y + pad + useFrac * Math.max(4, span);
      if (node.kind === 'process') {
        const dyNorm = Math.max(-0.92, Math.min(0.92, (py - cy) / Math.max(1, b)));
        const dxCirc = a * Math.sqrt(Math.max(0.05, 1 - dyNorm * dyNorm));
        px = side === 'L' ? cx - dxCirc : cx + dxCirc;
      } else {
        px = side === 'L' ? node.x : node.x + node.w;
      }
      s1y = py;
      s1x = side === 'L' ? Math.min(px - 8, node.x - layerStub) : Math.max(px + 8, node.x + node.w + layerStub);
    }

    item.port = {
      side,
      x: px,
      y: py,
      stub: [s1x, s1y],
      relX: +Math.max(0, Math.min(1, (px - node.x) / Math.max(1, node.w))).toFixed(4),
      relY: +Math.max(0, Math.min(1, (py - node.y) / Math.max(1, node.h))).toFixed(4)
    };
  }
}

function simplifyOrthoPoints(pts) {
  if (!pts || pts.length <= 2) return pts ? pts.map((p) => [p[0], p[1]]) : [];
  const out = [[pts[0][0], pts[0][1]]];
  for (let i = 1; i < pts.length; i++) {
    const prev = out[out.length - 1];
    const cur = pts[i];
    if (Math.hypot(cur[0] - prev[0], cur[1] - prev[1]) < 0.5) continue;
    if (out.length >= 2) {
      const pprev = out[out.length - 2];
      const sameX = Math.abs(pprev[0] - prev[0]) < 0.8 && Math.abs(prev[0] - cur[0]) < 0.8;
      const sameY = Math.abs(pprev[1] - prev[1]) < 0.8 && Math.abs(prev[1] - cur[1]) < 0.8;
      if (sameX || sameY) {
        out[out.length - 1] = [cur[0], cur[1]];
        continue;
      }
    }
    out.push([cur[0], cur[1]]);
  }
  return out;
}

function segHitsAnyNode(p1, p2, nodes, excludeIds, pad) {
  for (const r of nodes) {
    if (excludeIds && excludeIds.has(r.id)) continue;
    if (lib.segIntersectsRect(p1, p2, r, pad)) return true;
  }
  return false;
}

function extractHV(pts) {
  const h = [];
  const v = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[i + 1];
    if (Math.hypot(x2 - x1, y2 - y1) < 1) continue;
    if (Math.abs(y1 - y2) < 1.2) {
      h.push({ y: 0.5 * (y1 + y2), x1: Math.min(x1, x2), x2: Math.max(x1, x2) });
    } else if (Math.abs(x1 - x2) < 1.2) {
      v.push({ x: 0.5 * (x1 + x2), y1: Math.min(y1, y2), y2: Math.max(y1, y2) });
    }
  }
  return { h, v };
}

function isHFree(placedH, y, x1, x2, gap, selfIdx = -1) {
  const lo = Math.min(x1, x2);
  const hi = Math.max(x1, x2);
  if (hi - lo < 1) return true;
  for (const s of placedH) {
    if (s.edgeIdx === selfIdx) continue;
    if (Math.abs(s.y - y) < gap && Math.min(hi, s.x2) - Math.max(lo, s.x1) > 1.5) return false;
  }
  return true;
}

function isVFree(placedV, x, y1, y2, gap, selfIdx = -1) {
  const lo = Math.min(y1, y2);
  const hi = Math.max(y1, y2);
  if (hi - lo < 1) return true;
  for (const s of placedV) {
    if (s.edgeIdx === selfIdx) continue;
    if (Math.abs(s.x - x) < gap && Math.min(hi, s.y2) - Math.max(lo, s.y1) > 1.5) return false;
  }
  return true;
}

function countPathCrossings(pts, placedH, placedV) {
  let c = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[i + 1];
    if (Math.abs(y1 - y2) < 1.2) {
      const y = 0.5 * (y1 + y2);
      const lo = Math.min(x1, x2), hi = Math.max(x1, x2);
      for (const vs of placedV) {
        if (vs.x > lo + 1 && vs.x < hi - 1 && y > vs.y1 + 1 && y < vs.y2 - 1) c++;
      }
    } else if (Math.abs(x1 - x2) < 1.2) {
      const x = 0.5 * (x1 + x2);
      const lo = Math.min(y1, y2), hi = Math.max(y1, y2);
      for (const hs of placedH) {
        if (hs.y > lo + 1 && hs.y < hi - 1 && x > hs.x1 + 1 && x < hs.x2 - 1) c++;
      }
    }
  }
  return c;
}

function pathLength(pts) {
  let d = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    d += Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
  }
  return d;
}

function checkSideDir(pBase, pOuter, side) {
  const dx = pOuter[0] - pBase[0];
  const dy = pOuter[1] - pBase[1];
  if (side === 'R') return dx >= 5 && Math.abs(dy) < 1.2;
  if (side === 'L') return dx <= -5 && Math.abs(dy) < 1.2;
  if (side === 'B') return dy >= 5 && Math.abs(dx) < 1.2;
  if (side === 'T') return dy <= -5 && Math.abs(dx) < 1.2;
  return true;
}

function validateCandidate(pts, srcNode, dstNode, srcSide, dstSide, allNodes, placedH, placedV, clearancePad, parallelGap, selfIdx = -1) {
  const simple = simplifyOrthoPoints(pts);
  if (simple.length < 2) return null;

  // Enforce outward start stub & inward end stub so paths never backtrack or seal adjacent ports
  if (srcSide && !checkSideDir(simple[0], simple[1], srcSide)) return null;
  if (dstSide && !checkSideDir(simple[simple.length - 1], simple[simple.length - 2], dstSide)) return null;

  // All segments must strictly be axis-aligned
  for (let i = 0; i < simple.length - 1; i++) {
    const dx = Math.abs(simple[i + 1][0] - simple[i][0]);
    const dy = Math.abs(simple[i + 1][1] - simple[i][1]);
    if (dx >= 1.2 && dy >= 1.2) return null;
  }

  // First & last segments only touch their own endpoint node; inner segments avoid ALL nodes
  const endExclude = new Set([srcNode.id, dstNode.id]);
  for (let i = 0; i < simple.length - 1; i++) {
    const isFirst = i === 0;
    const isLast = i === simple.length - 2;
    const ex = (isFirst && isLast) ? endExclude : (isFirst ? new Set([srcNode.id]) : (isLast ? new Set([dstNode.id]) : null));
    if (segHitsAnyNode(simple[i], simple[i + 1], allNodes, ex, clearancePad)) {
      return null;
    }
  }

  // Self-collinear check & existing segment check
  const { h, v } = extractHV(simple);
  for (const s of h) {
    if (!isHFree(placedH, s.y, s.x1, s.x2, parallelGap, selfIdx)) return null;
  }
  for (const s of v) {
    if (!isVFree(placedV, s.x, s.y1, s.y2, parallelGap, selfIdx)) return null;
  }
  return {
    pts: simple,
    bends: Math.max(0, simple.length - 2),
    crossings: countPathCrossings(simple, placedH, placedV),
    len: pathLength(simple)
  };
}

function buildSweepValues(center, minV, maxV, step, maxOffsets) {
  const vals = [center];
  for (let k = 1; k <= maxOffsets; k++) {
    const a = center + k * step;
    const b = center - k * step;
    if (a <= maxV) vals.push(a);
    if (b >= minV) vals.push(b);
  }
  return vals;
}

function dedupeCoords(arr, minDiff = 8) {
  const sorted = [...arr].sort((a, b) => a - b);
  const out = [];
  for (const v of sorted) {
    if (out.length === 0 || v - out[out.length - 1] >= minDiff) {
      out.push(Math.round(v * 2) / 2);
    }
  }
  return out;
}

function hananAStarRoute(s0, s1, t1, t0, srcNode, dstNode, srcSide, dstSide, allNodes, placedH, placedV, clearancePad, parallelGap, selfIdx = -1) {
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  const xs = [
    s1[0], t1[0], (s1[0] + t1[0]) * 0.5,
    s1[0] - 14, s1[0] + 14, s1[0] - 28, s1[0] + 28,
    t1[0] - 14, t1[0] + 14, t1[0] - 28, t1[0] + 28
  ];
  const ys = [
    s1[1], t1[1], (s1[1] + t1[1]) * 0.5,
    s1[1] - 14, s1[1] + 14, s1[1] - 28, s1[1] + 28,
    t1[1] - 14, t1[1] + 14, t1[1] - 28, t1[1] + 28
  ];

  const offsets = [48, 62, 76, 90];
  const outerRings = [28, 48, 66, 84, 104, 124];

  for (const r of allNodes) {
    minX = Math.min(minX, r.x);
    maxX = Math.max(maxX, r.x + r.w);
    minY = Math.min(minY, r.y);
    maxY = Math.max(maxY, r.y + r.h);
    for (const off of offsets) {
      xs.push(r.x - off, r.x + r.w + off);
      ys.push(r.y - off, r.y + r.h + off);
    }
  }
  // Outer ring lanes
  for (const outer of outerRings) {
    xs.push(minX - outer, maxX + outer);
    ys.push(minY - outer, maxY + outer);
  }
  // Mid-corridors across large empty spans
  const sortedX = [...xs].sort((a, b) => a - b);
  for (let i = 0; i < sortedX.length - 1; i++) {
    if (sortedX[i + 1] - sortedX[i] > 90) xs.push(0.5 * (sortedX[i] + sortedX[i + 1]));
  }
  const sortedY = [...ys].sort((a, b) => a - b);
  for (let i = 0; i < sortedY.length - 1; i++) {
    if (sortedY[i + 1] - sortedY[i] > 90) ys.push(0.5 * (sortedY[i] + sortedY[i + 1]));
  }
  const uxs = dedupeCoords(xs, 7);
  const uys = dedupeCoords(ys, 7);
  const insertExact = (arr, target) => {
    for (let i = 0; i < arr.length; i++) {
      if (Math.abs(arr[i] - target) < 0.05) return;
    }
    arr.push(target);
  };
  const findExactIdx = (arr, target) => {
    let bestI = 0, bestD = Infinity;
    for (let i = 0; i < arr.length; i++) {
      const d = Math.abs(arr[i] - target);
      if (d < bestD) { bestD = d; bestI = i; }
    }
    return bestI;
  };
  insertExact(uxs, s1[0]);
  insertExact(uxs, t1[0]);
  uxs.sort((a, b) => a - b);
  insertExact(uys, s1[1]);
  insertExact(uys, t1[1]);
  uys.sort((a, b) => a - b);

  const sx = findExactIdx(uxs, s1[0]);
  const sy = findExactIdx(uys, s1[1]);
  const tx = findExactIdx(uxs, t1[0]);
  const ty = findExactIdx(uys, t1[1]);

  const nx = uxs.length;
  const ny = uys.length;
  if (nx === 0 || ny === 0) return null;

  // Precompute valid adjacency steps avoiding ALL nodes (since s1 and t1 are outside all nodes)
  // State index: ((yi * nx + xi) * 3 + dirState), dirState: 0=init, 1=H, 2=V
  const totalStates = nx * ny * 3;
  const dist = new Float64Array(totalStates);
  const parent = new Int32Array(totalStates);
  const closed = new Uint8Array(totalStates);
  dist.fill(Infinity);
  parent.fill(-1);

  // Simple binary min-heap for fast Dijkstra/A*
  const heapIdx = [];
  const heapPri = [];
  const pushHeap = (idx, pri) => {
    let i = heapIdx.length;
    heapIdx.push(idx);
    heapPri.push(pri);
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (heapPri[p] <= heapPri[i]) break;
      [heapIdx[p], heapIdx[i]] = [heapIdx[i], heapIdx[p]];
      [heapPri[p], heapPri[i]] = [heapPri[i], heapPri[p]];
      i = p;
    }
  };
  const popHeap = () => {
    const top = heapIdx[0];
    const lastIdx = heapIdx.pop();
    const lastPri = heapPri.pop();
    if (heapIdx.length > 0) {
      heapIdx[0] = lastIdx;
      heapPri[0] = lastPri;
      let i = 0;
      const n = heapIdx.length;
      while (true) {
        let best = i;
        const l = 2 * i + 1, r = 2 * i + 2;
        if (l < n && heapPri[l] < heapPri[best]) best = l;
        if (r < n && heapPri[r] < heapPri[best]) best = r;
        if (best === i) break;
        [heapIdx[i], heapIdx[best]] = [heapIdx[best], heapIdx[i]];
        [heapPri[i], heapPri[best]] = [heapPri[best], heapPri[i]];
        i = best;
      }
    }
    return top;
  };

  const sState = (sy * nx + sx) * 3 + 0;
  dist[sState] = 0;
  pushHeap(sState, Math.abs(uxs[tx] - uxs[sx]) + Math.abs(uys[ty] - uys[sy]));

  const dirs = [[1, 0, 1], [-1, 0, 1], [0, 1, 2], [0, -1, 2]];
  let bestEndState = -1;
  let bestEndCost = Infinity;

  while (heapIdx.length > 0) {
    const cur = popHeap();
    if (closed[cur]) continue;
    closed[cur] = 1;
    const dCur = dist[cur];
    if (dCur >= bestEndCost) break;

    const dirState = cur % 3;
    const cell = (cur - dirState) / 3;
    const xi = cell % nx;
    const yi = (cell - xi) / nx;

    if (xi === tx && yi === ty) {
      bestEndState = cur;
      bestEndCost = dCur;
      break;
    }

    const x0 = uxs[xi], y0 = uys[yi];
    for (const [dx, dy, nextDir] of dirs) {
      if (dirState === 0) {
        if ((srcSide === 'R' && dx < 0) || (srcSide === 'L' && dx > 0) ||
            (srcSide === 'B' && dy < 0) || (srcSide === 'T' && dy > 0)) continue;
      }
      const nxi = xi + dx;
      const nyi = yi + dy;
      if (nxi < 0 || nxi >= nx || nyi < 0 || nyi >= ny) continue;
      if (nxi === tx && nyi === ty) {
        if ((dstSide === 'R' && dx > 0) || (dstSide === 'L' && dx < 0) ||
            (dstSide === 'B' && dy > 0) || (dstSide === 'T' && dy < 0)) continue;
      }
      const x1 = uxs[nxi], y1 = uys[nyi];
      if (segHitsAnyNode([x0, y0], [x1, y1], allNodes, null, clearancePad)) continue;

      let cross = 0;
      if (nextDir === 1) {
        if (!isHFree(placedH, y0, x0, x1, parallelGap, selfIdx)) continue;
        const lo = Math.min(x0, x1), hi = Math.max(x0, x1);
        for (const vs of placedV) {
          if (vs.x > lo + 1 && vs.x < hi - 1 && y0 > vs.y1 + 1 && y0 < vs.y2 - 1) cross++;
        }
      } else {
        if (!isVFree(placedV, x0, y0, y1, parallelGap, selfIdx)) continue;
        const lo = Math.min(y0, y1), hi = Math.max(y0, y1);
        for (const hs of placedH) {
          if (hs.y > lo + 1 && hs.y < hi - 1 && x0 > hs.x1 + 1 && x0 < hs.x2 - 1) cross++;
        }
      }

      const stepDist = Math.abs(x1 - x0) + Math.abs(y1 - y0);
      const bendPen = (dirState !== 0 && dirState !== nextDir) ? 40 : 0;
      const crossPen = cross * 480;
      const nState = (nyi * nx + nxi) * 3 + nextDir;
      const nCost = dCur + stepDist + bendPen + crossPen;

      if (nCost < dist[nState]) {
        dist[nState] = nCost;
        parent[nState] = cur;
        const h = Math.abs(uxs[tx] - x1) + Math.abs(uys[ty] - y1);
        pushHeap(nState, nCost + h);
      }
    }
  }

  if (bestEndState < 0) return null;
  const chain = [];
  let c = bestEndState;
  while (c >= 0) {
    const dS = c % 3;
    const cell = (c - dS) / 3;
    const xi = cell % nx;
    const yi = (cell - xi) / nx;
    chain.push([uxs[xi], uys[yi]]);
    c = parent[c];
  }
  chain.reverse();
  const full = [s0, ...chain, t0];
  return validateCandidate(full, srcNode, dstNode, srcSide, dstSide, allNodes, placedH, placedV, clearancePad, parallelGap, selfIdx);
}

function scoreAndPickBest(candidates) {
  if (!candidates.length) return null;
  candidates.sort((a, b) => {
    const sa = a.crossings * 600 + a.bends * 35 + a.len * 0.25 + (a.penalty || 0);
    const sb = b.crossings * 600 + b.bends * 35 + b.len * 0.25 + (b.penalty || 0);
    return sa - sb;
  });
  return candidates[0];
}

function estimateLabelSize(label, fontSize) {
  if (!label) return { w: 0, h: 0 };
  const lines = String(label).split('\n');
  let maxLen = 0;
  for (const l of lines) maxLen = Math.max(maxLen, l.length);
  return {
    w: Math.max(24, Math.ceil(maxLen * fontSize * 0.56 + 10)),
    h: Math.max(16, Math.ceil(lines.length * (fontSize + 3) + 6))
  };
}

function pointAtFractionOnPath(pts, segIdx, frac) {
  let total = 0;
  let distAt = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const segLen = Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
    if (i < segIdx) distAt += segLen;
    else if (i === segIdx) distAt += segLen * frac;
    total += segLen;
  }
  const p1 = pts[segIdx];
  const p2 = pts[segIdx + 1];
  const x = p1[0] + (p2[0] - p1[0]) * frac;
  const y = p1[1] + (p2[1] - p1[1]) * frac;
  const relX = total > 1 ? +(2 * (distAt / total) - 1).toFixed(4) : 0;
  return { x, y, relX };
}

function placeEdgeLabels(routedEdges, allNodes, fontSize) {
  const placedLabels = [];
  for (let ei = 0; ei < routedEdges.length; ei++) {
    const edge = routedEdges[ei];
    if (!edge.label) {
      edge.relX = 0;
      edge.labelOffsetY = 0;
      edge.labelPos = null;
      continue;
    }
    const sz = estimateLabelSize(edge.label, fontSize);
    const pts = edge.points;
    let bestCand = null;
    let bestScore = Infinity;

    const segInfos = [];
    for (let s = 0; s < pts.length - 1; s++) {
      const len = Math.hypot(pts[s + 1][0] - pts[s][0], pts[s + 1][1] - pts[s][1]);
      if (len >= 16) segInfos.push({ s, len });
    }
    if (!segInfos.length) segInfos.push({ s: 0, len: 10 });

    // Longest segments first; also prefer middle segments
    for (const { s, len } of segInfos) {
      const pA = pts[s], pB = pts[s + 1];
      const isHoriz = Math.abs(pA[1] - pB[1]) < 2;
      const fracs = [0.5, 0.38, 0.62, 0.26, 0.74, 0.16, 0.84];
      const shifts = isHoriz
        ? [[0, 0], [0, -15], [0, 15], [0, -28], [0, 28], [-18, -14], [18, 14]]
        : [[0, 0], [-18, 0], [18, 0], [-34, 0], [34, 0], [0, -15], [0, 15]];
      for (const f of fracs) {
        const pt = pointAtFractionOnPath(pts, s, f);
        for (const [dx, dy] of shifts) {
          const rx = pt.x + dx - sz.w * 0.5;
          const ry = pt.y + dy - sz.h * 0.5;
          const rect = { x: rx, y: ry, w: sz.w, h: sz.h };

          let score = Math.abs(f - 0.5) * 40 + (len < sz.w * 0.6 ? 120 : 0) - Math.min(len, 180) * 0.15 + (Math.abs(dx) + Math.abs(dy)) * 2.5 + (isHoriz ? 0 : 12);
          for (const n of allNodes) {
            if (lib.rectsOverlap(rect, n, 4)) score += 10000;
          }
          for (const pl of placedLabels) {
            if (lib.rectsOverlap(rect, pl, 4)) score += 9000;
          }
          // Check crossing with OTHER edges
          for (let oj = 0; oj < routedEdges.length; oj++) {
            if (oj === ei) continue;
            const oPts = routedEdges[oj].points;
            for (let os = 0; os < oPts.length - 1; os++) {
              if (lib.segIntersectsRect(oPts[os], oPts[os + 1], rect, 0)) {
                score += 450;
                break;
              }
            }
          }
          if (score < bestScore) {
            bestScore = score;
            bestCand = { rect, relX: pt.relX, offsetX: dx, offsetY: dy, cx: pt.x + dx, cy: pt.y + dy };
          }
        }
      }
    }

    if (bestCand) {
      placedLabels.push(bestCand.rect);
      edge.relX = bestCand.relX;
      edge.labelOffsetX = bestCand.offsetX;
      edge.labelOffsetY = bestCand.offsetY;
      edge.labelPos = bestCand.rect;
    } else {
      edge.relX = 0;
      edge.labelOffsetX = 0;
      edge.labelOffsetY = 0;
      edge.labelPos = null;
    }
  }
}

function routeClusterEdges(inputNodes, edgeSpecs, opts = {}) {
  const margin = opts.margin ?? 50;
  const stubLen = opts.stubLen ?? 20;
  const minPortSpacing = opts.minPortSpacing ?? 10;
  const clearancePad = -(opts.nodeClearance ?? 8);
  const parallelGap = opts.parallelGap ?? 9;
  const labelFontSize = opts.labelFontSize ?? 10;
  const trackStep = opts.trackStep ?? 12;

  const nodes = cloneNodes(inputNodes);
  const nodeMap = new Map();
  for (const n of nodes) nodeMap.set(n.id, n);

  const sideCounts = new Map();
  const sideCaps = new Map();
  const nodeSideLists = new Map();
  for (const n of nodes) {
    sideCounts.set(n.id, { T: 0, B: 0, L: 0, R: 0 });
    sideCaps.set(n.id, computeSideCapacities(n, minPortSpacing));
    nodeSideLists.set(n.id, { T: [], B: [], L: [], R: [] });
  }

  // Assign sides greedily shortest edges first so tight neighbor links take direct facing sides
  const indexedEdges = edgeSpecs.map((spec, idx) => {
    const s = nodeMap.get(spec.src);
    const t = nodeMap.get(spec.dst);
    if (!s || !t) throw new Error(`Missing node in edge ${idx}: ${spec.src} -> ${spec.dst}`);
    const sc = nodeCenter(s);
    const tc = nodeCenter(t);
    const dist = Math.hypot(tc.cx - sc.cx, tc.cy - sc.cy);
    return { spec, idx, s, t, dist };
  });
  indexedEdges.sort((a, b) => a.dist - b.dist || a.idx - b.idx);

  const portPairs = new Array(edgeSpecs.length);

  for (const item of indexedEdges) {
    const { spec, idx, s, t } = item;
    let sSide, tSide;
    if (s.id === t.id) {
      sSide = 'T';
      tSide = 'R';
    } else {
      sSide = spec.srcSide || chooseBestSide(s, t, sideCounts.get(s.id), sideCaps.get(s.id), opts.biasSide);
      tSide = spec.dstSide || chooseBestSide(t, s, sideCounts.get(t.id), sideCaps.get(t.id), opts.biasSide);
    }
    sideCounts.get(s.id)[sSide]++;
    sideCounts.get(t.id)[tSide]++;

    const srcEntry = { edgeIdx: idx, other: t, isTarget: false, key: sideSortKey(s, t, sSide, idx, s.id, t.id) };
    const dstEntry = { edgeIdx: idx, other: s, isTarget: true, key: sideSortKey(t, s, tSide, idx, s.id, t.id) };
    nodeSideLists.get(s.id)[sSide].push(srcEntry);
    nodeSideLists.get(t.id)[tSide].push(dstEntry);
    portPairs[idx] = { srcEntry, dstEntry };
  }

  // Sort ports monotonically on every side & compute exact exit/entry coordinates
  for (const n of nodes) {
    const sides = nodeSideLists.get(n.id);
    for (const sName of ['T', 'B', 'L', 'R']) {
      const list = sides[sName];
      list.sort((a, b) => {
        if (Math.abs(a.key.primary - b.key.primary) > 1e-4) return a.key.primary - b.key.primary;
        if (a.key.tie1 !== b.key.tie1) return a.key.tie1 - b.key.tie1;
        return a.key.tie2 - b.key.tie2;
      });
      if (list.length > 0) {
        // Compute safe stub distance avoiding hitting a very close adjacent opposing node
        placePortsOnSide(n, sName, list, stubLen);
      }
    }
  }

  // Adjust stubLen locally ONLY if stubEnd lands inside another node (when gap < 2*stubLen)
  const capStub = (port, ownerNode, allNodes) => {
    const p0 = [port.x, port.y];
    let p1 = port.stub;
    const dx = p1[0] - p0[0];
    const dy = p1[1] - p0[1];
    for (const r of allNodes) {
      if (r.id === ownerNode.id) continue;
      if (lib.segIntersectsRect(p0, p1, r, -2)) {
        // Pull stub back toward midpoint before r
        let maxFrac = 0.5;
        if (dx > 0 && r.x > p0[0]) maxFrac = Math.min(maxFrac, Math.max(0.25, (r.x - 4 - p0[0]) / dx));
        if (dx < 0 && r.x + r.w < p0[0]) maxFrac = Math.min(maxFrac, Math.max(0.25, (p0[0] - (r.x + r.w + 4)) / (-dx)));
        if (dy > 0 && r.y > p0[1]) maxFrac = Math.min(maxFrac, Math.max(0.25, (r.y - 4 - p0[1]) / dy));
        if (dy < 0 && r.y + r.h < p0[1]) maxFrac = Math.min(maxFrac, Math.max(0.25, (p0[1] - (r.y + r.h + 4)) / (-dy)));
        p1 = [p0[0] + dx * maxFrac, p0[1] + dy * maxFrac];
      }
    }
    port.stub = p1;
  };
  for (const pp of portPairs) {
    const e = edgeSpecs[pp.srcEntry.edgeIdx];
    capStub(pp.srcEntry.port, nodeMap.get(e.src), nodes);
    capStub(pp.dstEntry.port, nodeMap.get(e.dst), nodes);
  }

  // Route edges shortest first (same deterministic order), pre-reserving all terminal port stubs
  const placedH = [];
  const placedV = [];
  const routedEdges = new Array(edgeSpecs.length);

  for (const pp of portPairs) {
    const eIdx = pp.srcEntry.edgeIdx;
    const sp0 = pp.srcEntry.port;
    const tp0 = pp.dstEntry.port;
    const sHV = extractHV([[sp0.x, sp0.y], sp0.stub]);
    for (const hs of sHV.h) placedH.push({ ...hs, edgeIdx: eIdx });
    for (const vs of sHV.v) placedV.push({ ...vs, edgeIdx: eIdx });
    const tHV = extractHV([tp0.stub, [tp0.x, tp0.y]]);
    for (const hs of tHV.h) placedH.push({ ...hs, edgeIdx: eIdx });
    for (const vs of tHV.v) placedV.push({ ...vs, edgeIdx: eIdx });
  }

  for (const item of indexedEdges) {
    const { spec, idx, s, t } = item;
    const sp = portPairs[idx].srcEntry.port;
    const tp = portPairs[idx].dstEntry.port;
    const s0 = [sp.x, sp.y];
    const s1 = sp.stub;
    const t0 = [tp.x, tp.y];
    const t1 = tp.stub;

    let chosen = null;

    if (s.id === t.id) {
      // Self-loop T -> R outside top-right corner
      const topY = Math.min(s1[1], s.y - 26);
      const rightX = Math.max(t1[0], s.x + s.w + 28);
      for (let off = 0; off <= 60; off += trackStep) {
        const cand = validateCandidate(
          [s0, [s0[0], topY - off], [rightX + off, topY - off], [rightX + off, t0[1]], t0],
          s, t, sp.side, tp.side, nodes, placedH, placedV, clearancePad, parallelGap, idx
        );
        if (cand) { chosen = cand; break; }
      }
    } else {
      const sHoriz = sp.side === 'L' || sp.side === 'R';
      const tHoriz = tp.side === 'L' || tp.side === 'R';

      const findFastOrtho = (gap) => {
        const cands = [];
        const tryPush = (pts, extraPen = 0) => {
          const v = validateCandidate(pts, s, t, sp.side, tp.side, nodes, placedH, placedV, clearancePad, gap, idx);
          if (v) { v.penalty = extraPen; cands.push(v); }
        };

        // 0-bend or 1-bend L
        if (sHoriz && tHoriz) {
          if (Math.abs(s0[1] - t0[1]) < 1.2) tryPush([s0, t0]);
        } else if (!sHoriz && !tHoriz) {
          if (Math.abs(s0[0] - t0[0]) < 1.2) tryPush([s0, t0]);
        } else if (sHoriz && !tHoriz) {
          const cx = t0[0], cy = s0[1];
          const okS = sp.side === 'R' ? cx >= s1[0] - 1 : cx <= s1[0] + 1;
          const okT = tp.side === 'T' ? cy <= t1[1] + 1 : cy >= t1[1] - 1;
          if (okS && okT) tryPush([s0, [cx, cy], t0]);
        } else {
          const cx = s0[0], cy = t0[1];
          const okS = sp.side === 'T' ? cy <= s1[1] + 1 : cy >= s1[1] - 1;
          const okT = tp.side === 'R' ? cx >= t1[0] - 1 : cx <= t1[0] + 1;
          if (okS && okT) tryPush([s0, [cx, cy], t0]);
        }

        // 2-bend Z / U sweeps along X (when sHoriz & tHoriz)
        if (sHoriz && tHoriz) {
          let baseM = 0.5 * (s1[0] + t1[0]);
          if (sp.side === tp.side) {
            baseM = sp.side === 'R' ? Math.max(s1[0], t1[0]) + 16 : Math.min(s1[0], t1[0]) - 16;
          }
          const mVals = buildSweepValues(baseM, baseM - 220, baseM + 220, trackStep, 12);
          for (const mx of mVals) {
            const okS = sp.side === 'R' ? mx >= s1[0] - 0.5 : mx <= s1[0] + 0.5;
            const okT = tp.side === 'R' ? mx >= t1[0] - 0.5 : mx <= t1[0] + 0.5;
            if (okS && okT) {
              tryPush([s0, [mx, s0[1]], [mx, t0[1]], t0], Math.abs(mx - baseM) * 0.25);
            }
          }
        }

        // 2-bend Z / U sweeps along Y (when !sHoriz & !tHoriz)
        if (!sHoriz && !tHoriz) {
          let baseM = 0.5 * (s1[1] + t1[1]);
          if (sp.side === tp.side) {
            baseM = sp.side === 'B' ? Math.max(s1[1], t1[1]) + 16 : Math.min(s1[1], t1[1]) - 16;
          }
          const mVals = buildSweepValues(baseM, baseM - 220, baseM + 220, trackStep, 12);
          for (const my of mVals) {
            const okS = sp.side === 'B' ? my >= s1[1] - 0.5 : my <= s1[1] + 0.5;
            const okT = tp.side === 'B' ? my >= t1[1] - 0.5 : my <= t1[1] + 0.5;
            if (okS && okT) {
              tryPush([s0, [s0[0], my], [t0[0], my], t0], Math.abs(my - baseM) * 0.25);
            }
          }
        }

        // Quick 3-bend U-dogleg when L fails due to wrong stub direction
        for (const myOff of buildSweepValues(0.5 * (s1[1] + t1[1]), -Infinity, Infinity, 20, 6)) {
          tryPush([s0, s1, [s1[0], myOff], [t1[0], myOff], t1, t0], 25);
        }
        for (const mxOff of buildSweepValues(0.5 * (s1[0] + t1[0]), -Infinity, Infinity, 20, 6)) {
          tryPush([s0, s1, [mxOff, s1[1]], [mxOff, t1[1]], t1, t0], 25);
        }
        return scoreAndPickBest(cands);
      };

      chosen = findFastOrtho(parallelGap);
      if (!chosen && parallelGap > 7) chosen = findFastOrtho(7);
      if (!chosen) {
        chosen = hananAStarRoute(s0, s1, t1, t0, s, t, sp.side, tp.side, nodes, placedH, placedV, clearancePad, parallelGap, idx);
      }
      if (!chosen) {
        chosen = hananAStarRoute(s0, s1, t1, t0, s, t, sp.side, tp.side, nodes, placedH, placedV, -5, 7, idx);
      }
      if (!chosen) {
        chosen = hananAStarRoute(s0, s1, t1, t0, s, t, sp.side, tp.side, nodes, placedH, placedV, -4, 6.2, idx);
      }
      if (!chosen) {
        const midY = 0.5 * (s1[1] + t1[1]);
        chosen = { pts: simplifyOrthoPoints([s0, s1, [s1[0], midY], [t1[0], midY], t1, t0]) };
      }
    }

    const { h, v } = extractHV(chosen.pts);
    for (const hs of h) placedH.push({ ...hs, edgeIdx: idx });
    for (const vs of v) placedV.push({ ...vs, edgeIdx: idx });

    routedEdges[idx] = {
      ...spec,
      src: s.id,
      dst: t.id,
      srcSide: sp.side,
      dstSide: tp.side,
      exitX: sp.relX,
      exitY: sp.relY,
      entryX: tp.relX,
      entryY: tp.relY,
      points: chosen.pts,
      waypoints: chosen.pts.length > 2 ? chosen.pts.slice(1, -1) : []
    };
  }

  placeEdgeLabels(routedEdges, nodes, labelFontSize);

  // Normalize global bounding box (all nodes + all edge points + all placed labels) cleanly to (margin, margin)
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const n of nodes) {
    minX = Math.min(minX, n.x);
    minY = Math.min(minY, n.y);
    maxX = Math.max(maxX, n.x + n.w);
    maxY = Math.max(maxY, n.y + n.h);
  }
  for (const e of routedEdges) {
    for (const [px, py] of e.points) {
      minX = Math.min(minX, px);
      minY = Math.min(minY, py);
      maxX = Math.max(maxX, px);
      maxY = Math.max(maxY, py);
    }
    if (e.labelPos) {
      minX = Math.min(minX, e.labelPos.x);
      minY = Math.min(minY, e.labelPos.y);
      maxX = Math.max(maxX, e.labelPos.x + e.labelPos.w);
      maxY = Math.max(maxY, e.labelPos.y + e.labelPos.h);
    }
  }

  const topMargin = opts.topMargin ?? margin;
  const shiftX = Math.round(margin - minX);
  const shiftY = Math.round(topMargin - minY);

  if (shiftX !== 0 || shiftY !== 0) {
    for (const n of nodes) {
      n.x += shiftX;
      n.y += shiftY;
    }
    for (const e of routedEdges) {
      e.points = e.points.map(([px, py]) => [+(px + shiftX).toFixed(1), +(py + shiftY).toFixed(1)]);
      e.waypoints = e.points.length > 2 ? e.points.slice(1, -1) : [];
      if (e.labelPos) {
        e.labelPos = {
          ...e.labelPos,
          x: e.labelPos.x + shiftX,
          y: e.labelPos.y + shiftY
        };
      }
    }
    maxX += shiftX;
    maxY += shiftY;
  }

  const pageWidth = Math.max(600, Math.ceil((maxX + margin) / 10) * 10);
  const pageHeight = Math.max(400, Math.ceil((maxY + margin) / 10) * 10);

  return { nodes, edges: routedEdges, pageWidth, pageHeight };
}

module.exports = {
  routeClusterEdges,
  estimateLabelSize
};
