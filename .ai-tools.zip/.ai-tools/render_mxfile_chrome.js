const fs = require('fs');
const path = require('path');
const { execFileSync, spawn } = require('child_process');
const lib = require('./diagram_lib');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

function decodeXmlAttr(str) {
  return String(str || '')
    .replace(/&#xa;/gi, '\n')
    .replace(/&#x0a;/gi, '\n')
    .replace(/&#10;/g, '\n')
    .replace(/&#13;/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function parseStyle(styleStr) {
  const map = {};
  if (!styleStr) return map;
  for (const part of styleStr.split(';')) {
    if (!part) continue;
    const eq = part.indexOf('=');
    if (eq >= 0) {
      map[part.slice(0, eq).trim()] = part.slice(eq + 1).trim();
    } else {
      map[part.trim()] = '1';
    }
  }
  return map;
}

function parseAttrs(tagStr) {
  const attrs = {};
  const rx = /([a-zA-Z0-9_:-]+)="([^"]*)"/g;
  let m;
  while ((m = rx.exec(tagStr)) !== null) {
    attrs[m[1]] = decodeXmlAttr(m[2]);
  }
  return attrs;
}

function parseSingleDiagramXml(xml) {
  const diagMatch = xml.match(/<diagram\b([^>]*)>([\s\S]*?)<\/diagram>/);
  const gmMatch = xml.match(/<mxGraphModel\b([^>]*)>/);
  const gmAttrs = gmMatch ? parseAttrs(gmMatch[1]) : {};

  // Parse all top-level <mxCell ...> blocks inside <root>
  const cells = [];
  const rootMatch = xml.match(/<root>([\s\S]*?)<\/root>/);
  const rootXml = rootMatch ? rootMatch[1] : xml;

  let pos = 0;
  while (pos < rootXml.length) {
    const start = rootXml.indexOf('<mxCell ', pos);
    if (start < 0) break;
    const tagEnd = rootXml.indexOf('>', start);
    if (tagEnd < 0) break;
    const selfClosing = rootXml[tagEnd - 1] === '/';
    let innerXml = '';
    let nextPos = tagEnd + 1;
    if (!selfClosing) {
      const closeIdx = rootXml.indexOf('</mxCell>', tagEnd);
      if (closeIdx < 0) break;
      innerXml = rootXml.slice(tagEnd + 1, closeIdx);
      nextPos = closeIdx + '</mxCell>'.length;
    }
    const openTag = rootXml.slice(start, tagEnd + 1);
    const attrs = parseAttrs(openTag);
    const style = parseStyle(attrs.style || '');

    let geom = null;
    const gStart = innerXml.indexOf('<mxGeometry');
    if (gStart >= 0) {
      const gTagEnd = innerXml.indexOf('>', gStart);
      const gAttrs = parseAttrs(innerXml.slice(gStart, gTagEnd + 1));
      const gSelf = innerXml[gTagEnd - 1] === '/';
      let gInner = '';
      if (!gSelf) {
        const gClose = innerXml.indexOf('</mxGeometry>', gTagEnd);
        if (gClose >= 0) gInner = innerXml.slice(gTagEnd + 1, gClose);
      }
      const points = [];
      const arrMatch = gInner.match(/<Array\s+as="points">([\s\S]*?)<\/Array>/);
      if (arrMatch) {
        const ptRx = /<mxPoint\b([^>]*)\/>/g;
        let pm;
        while ((pm = ptRx.exec(arrMatch[1])) !== null) {
          const pa = parseAttrs(pm[1]);
          points.push([parseFloat(pa.x || 0), parseFloat(pa.y || 0)]);
        }
      }
      let offset = { x: 0, y: 0 };
      const offMatch = gInner.match(/<mxPoint\b([^>]*as="offset"[^>]*)\/>/);
      if (offMatch) {
        const oa = parseAttrs(offMatch[1]);
        offset = { x: parseFloat(oa.x || 0), y: parseFloat(oa.y || 0) };
      }
      geom = {
        x: parseFloat(gAttrs.x || 0),
        y: parseFloat(gAttrs.y || 0),
        width: parseFloat(gAttrs.width || 0),
        height: parseFloat(gAttrs.height || 0),
        relative: gAttrs.relative === '1',
        points,
        offset
      };
    }

    cells.push({
      id: attrs.id,
      value: attrs.value || '',
      styleStr: attrs.style || '',
      style,
      vertex: attrs.vertex === '1',
      edge: attrs.edge === '1',
      parent: attrs.parent || '',
      source: attrs.source || '',
      target: attrs.target || '',
      geom
    });
    pos = nextPos;
  }

  return {
    pageWidth: parseFloat(gmAttrs.pageWidth || 1200),
    pageHeight: parseFloat(gmAttrs.pageHeight || 800),
    background: gmAttrs.background || '#ffffff',
    cells
  };
}

function escapeSvgText(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function pointOnEllipse(cx, cy, rx, ry, relX, relY) {
  const dx = (relX - 0.5) * 2;
  const dy = (relY - 0.5) * 2;
  // Since cluster_router already emits relX, relY right on circumference, normalize mildly ONLY if inside/corner
  const r2 = dx * dx + dy * dy;
  if (r2 < 0.01) return [cx, cy - ry];
  if (Math.abs(r2 - 1) < 0.08) return [cx + dx * rx, cy + dy * ry];
  const r = Math.sqrt(r2);
  return [cx + (dx / r) * rx, cy + (dy / r) * ry];
}

function pointOnRhombus(x, y, w, h, relX, relY) {
  const rx = isFinite(relX) ? relX : 0.5;
  const ry = isFinite(relY) ? relY : 0.5;
  if (Math.abs(rx - 0.5) < 0.02 && ry <= 0.02) return [x + w * 0.5, y];
  if (rx >= 0.98 && Math.abs(ry - 0.5) < 0.02) return [x + w, y + h * 0.5];
  if (Math.abs(rx - 0.5) < 0.02 && ry >= 0.98) return [x + w * 0.5, y + h];
  if (rx <= 0.02 && Math.abs(ry - 0.5) < 0.02) return [x, y + h * 0.5];
  const dx = rx - 0.5;
  const dy = ry - 0.5;
  const manhattan = Math.abs(dx) + Math.abs(dy);
  if (manhattan < 1e-4) return [x + w * 0.5, y];
  const scale = 0.5 / manhattan;
  return [x + (0.5 + dx * scale) * w, y + (0.5 + dy * scale) * h];
}

function getPortPoint(node, relX, relY, defaultSidePt) {
  if (!node || !node.absGeom) return defaultSidePt || [0, 0];
  const g = node.absGeom;
  const rx = isFinite(relX) ? relX : 0.5;
  const ry = isFinite(relY) ? relY : 0.5;
  if (node.style.ellipse === '1' || node.style.shape === 'mxgraph.bpmn.event') {
    const px = g.x + rx * g.width;
    const py = g.y + ry * g.height;
    // If exitPerimeter=0 is set and relX/relY already lies close to the ellipse curve, preserve exact pixel!
    const cx = g.x + g.width * 0.5;
    const cy = g.y + g.height * 0.5;
    const a = g.width * 0.5;
    const b = g.height * 0.5;
    const nx = (px - cx) / Math.max(1, a);
    const ny = (py - cy) / Math.max(1, b);
    const norm = Math.hypot(nx, ny);
    if (norm > 0.01 && Math.abs(norm - 1) > 0.04 && node.style.exitPerimeter !== '0') {
      return pointOnEllipse(cx, cy, a, b, rx, ry);
    }
    return [px, py];
  }
  if (node.style.shape === 'mxgraph.bpmn.gateway2') {
    return pointOnRhombus(g.x, g.y, g.width, g.height, rx, ry);
  }
  return [g.x + rx * g.width, g.y + ry * g.height];
}

function pointAtRelX(pts, relX) {
  let total = 0;
  const lens = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const d = Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
    lens.push(d);
    total += d;
  }
  if (total < 1) return pts[0];
  const frac = Math.max(0, Math.min(1, (relX + 1) * 0.5));
  let rem = frac * total;
  for (let i = 0; i < lens.length; i++) {
    if (rem <= lens[i] + 1e-6 || i === lens.length - 1) {
      const t = lens[i] > 0 ? rem / lens[i] : 0.5;
      return [
        pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t,
        pts[i][1] + (pts[i + 1][1] - pts[i][1]) * t
      ];
    }
    rem -= lens[i];
  }
  return pts[pts.length - 1];
}

function getMarkerShorten(arrowType, arrowSize, filled) {
  if (!arrowType || arrowType === 'none') return 0;
  const sz = arrowSize || 9;
  if (arrowType === 'block') return sz + 0.5;
  if (arrowType === 'diamondThin') return sz * 1.45;
  if (arrowType === 'classic') return filled ? Math.max(4, sz * 0.72) : Math.max(4, sz * 0.85);
  if (arrowType === 'open') return 1.5;
  if (arrowType === 'oval') return sz * 0.88;
  return 0;
}

function drawMarkerSvg(tip, unitDx, unitDy, arrowType, arrowSize, strokeColor, filled) {
  if (!arrowType || arrowType === 'none') return '';
  // unitDx, unitDy points FROM inside line TOWARD tip at box boundary!
  const sz = arrowSize || 9;
  const px = -unitDy;
  const py = unitDx;
  const tipX = tip[0], tipY = tip[1];

  if (arrowType === 'classic') {
    const len = sz * 0.95;
    const hw = sz * 0.42;
    const bx = tipX - unitDx * len;
    const by = tipY - unitDy * len;
    const notchX = tipX - unitDx * (len * 0.72);
    const notchY = tipY - unitDy * (len * 0.72);
    const p1 = `${(bx + px * hw).toFixed(1)},${(by + py * hw).toFixed(1)}`;
    const p2 = `${(bx - px * hw).toFixed(1)},${(by - py * hw).toFixed(1)}`;
    const fill = filled ? strokeColor : '#ffffff';
    return `<polygon points="${tipX.toFixed(1)},${tipY.toFixed(1)} ${p1} ${notchX.toFixed(1)},${notchY.toFixed(1)} ${p2}" fill="${fill}" stroke="${strokeColor}" stroke-width="1.2" stroke-linejoin="round" />`;
  }
  if (arrowType === 'block') {
    const len = sz;
    const hw = sz * 0.48;
    const bx = tipX - unitDx * len;
    const by = tipY - unitDy * len;
    const p1 = `${(bx + px * hw).toFixed(1)},${(by + py * hw).toFixed(1)}`;
    const p2 = `${(bx - px * hw).toFixed(1)},${(by - py * hw).toFixed(1)}`;
    const fill = filled ? strokeColor : '#ffffff';
    return `<polygon points="${tipX.toFixed(1)},${tipY.toFixed(1)} ${p1} ${p2}" fill="${fill}" stroke="${strokeColor}" stroke-width="1.4" stroke-linejoin="round" />`;
  }
  if (arrowType === 'open') {
    const len = sz * 0.95;
    const hw = sz * 0.45;
    const bx = tipX - unitDx * len;
    const by = tipY - unitDy * len;
    const p1 = `${(bx + px * hw).toFixed(1)},${(by + py * hw).toFixed(1)}`;
    const p2 = `${(bx - px * hw).toFixed(1)},${(by - py * hw).toFixed(1)}`;
    return `<polyline points="${p1} ${tipX.toFixed(1)},${tipY.toFixed(1)} ${p2}" fill="none" stroke="${strokeColor}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" />`;
  }
  if (arrowType === 'diamondThin') {
    const len = sz * 1.45;
    const mid = len * 0.5;
    const hw = sz * 0.44;
    const mx = tipX - unitDx * mid;
    const my = tipY - unitDy * mid;
    const tailX = tipX - unitDx * len;
    const tailY = tipY - unitDy * len;
    const p1 = `${(mx + px * hw).toFixed(1)},${(my + py * hw).toFixed(1)}`;
    const p2 = `${(mx - px * hw).toFixed(1)},${(my - py * hw).toFixed(1)}`;
    const fill = filled ? strokeColor : '#ffffff';
    return `<polygon points="${tipX.toFixed(1)},${tipY.toFixed(1)} ${p1} ${tailX.toFixed(1)},${tailY.toFixed(1)} ${p2}" fill="${fill}" stroke="${strokeColor}" stroke-width="1.3" stroke-linejoin="round" />`;
  }
  if (arrowType === 'oval') {
    const r = sz * 0.44;
    const cx = tipX - unitDx * r;
    const cy = tipY - unitDy * r;
    const fill = filled ? strokeColor : '#ffffff';
    return `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${r.toFixed(1)}" fill="${fill}" stroke="${strokeColor}" stroke-width="1.3" />`;
  }
  return '';
}

function buildRoundedEdgePathD(pts, vertSegmentsBefore, jumpRadius = 4.5, cornerR = 8) {
  if (pts.length < 2) return '';
  const n = pts.length;

  // Build smoothed polyline path replacing sharp bends with Q arcs and inserting jump arcs on horiz segments
  let d = `M ${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;

  const emitSegWithJumps = (p1, p2, trimStart, trimEnd) => {
    const dx = p2[0] - p1[0];
    const dy = p2[1] - p1[1];
    const L = Math.hypot(dx, dy);
    if (L < 0.5) return;
    const ux = dx / L, uy = dy / L;
    const sx = p1[0] + ux * trimStart;
    const sy = p1[1] + uy * trimStart;
    const ex = p2[0] - ux * trimEnd;
    const ey = p2[1] - uy * trimEnd;

    const isHoriz = Math.abs(dy) < 1.2 && Math.abs(dx) > jumpRadius * 3;
    if (!isHoriz || !vertSegmentsBefore.length) {
      d += ` L ${ex.toFixed(1)} ${ey.toFixed(1)}`;
      return;
    }

    const y = 0.5 * (sy + ey);
    const minX = Math.min(sx, ex) + jumpRadius + 4;
    const maxX = Math.max(sx, ex) - jumpRadius - 4;
    const hits = [];
    for (const vs of vertSegmentsBefore) {
      if (vs.x > minX && vs.x < maxX && y > vs.y1 + 2 && y < vs.y2 - 2) {
        hits.push(vs.x);
      }
    }
    if (!hits.length) {
      d += ` L ${ex.toFixed(1)} ${ey.toFixed(1)}`;
      return;
    }
    hits.sort((a, b) => (ux > 0 ? a - b : b - a));
    const dir = ux > 0 ? 1 : -1;
    let lastX = sx;
    for (const hx of hits) {
      const ax1 = hx - dir * jumpRadius;
      const ax2 = hx + dir * jumpRadius;
      if ((dir > 0 && ax1 <= lastX + 1) || (dir < 0 && ax1 >= lastX - 1)) continue;
      d += ` L ${ax1.toFixed(1)} ${y.toFixed(1)}`;
      // Arch upward (smaller Y): sweep=1 if going right, sweep=0 if going left
      const sweep = dir > 0 ? 1 : 0;
      d += ` A ${jumpRadius} ${jumpRadius} 0 0 ${sweep} ${ax2.toFixed(1)} ${y.toFixed(1)}`;
      lastX = ax2;
    }
    d += ` L ${ex.toFixed(1)} ${ey.toFixed(1)}`;
  };

  const radii = new Array(n).fill(0);
  for (let i = 1; i < n - 1; i++) {
    const L1 = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    const L2 = Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
    radii[i] = Math.min(cornerR, L1 * 0.42, L2 * 0.42);
    if (radii[i] < 1.5) radii[i] = 0;
  }

  for (let i = 0; i < n - 1; i++) {
    const tStart = i === 0 ? 0 : radii[i];
    const tEnd = i === n - 2 ? 0 : radii[i + 1];
    emitSegWithJumps(pts[i], pts[i + 1], tStart, tEnd);
    if (i < n - 2 && radii[i + 1] > 0) {
      const pNext = pts[i + 1];
      const pAfter = pts[i + 2];
      const L2 = Math.hypot(pAfter[0] - pNext[0], pAfter[1] - pNext[1]);
      const ux2 = (pAfter[0] - pNext[0]) / Math.max(1, L2);
      const uy2 = (pAfter[1] - pNext[1]) / Math.max(1, L2);
      const cx2 = pNext[0] + ux2 * radii[i + 1];
      const cy2 = pNext[1] + uy2 * radii[i + 1];
      d += ` Q ${pNext[0].toFixed(1)} ${pNext[1].toFixed(1)} ${cx2.toFixed(1)} ${cy2.toFixed(1)}`;
    }
  }
  return d;
}

function computeExternalLabelMetrics(v) {
  if (!v || !v.value || !v.absGeom) return null;
  const st = v.style || {};
  const isExtShape = st.shape === 'mxgraph.bpmn.event' || st.shape === 'mxgraph.bpmn.gateway2';
  if (!isExtShape) return null;
  const vPos = st.verticalLabelPosition || 'bottom';
  const hPos = st.labelPosition || 'center';
  const plain = String(v.value).replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '');
  const lines = plain.split('\n');
  const fSize = parseFloat(st.fontSize || 9.5);
  const maxLen = Math.max(...lines.map((l) => l.length));
  const estW = Math.max(36, Math.min(220, Math.ceil(maxLen * fSize * 0.56 + 10)));
  const estH = Math.ceil(lines.length * (fSize * 1.24) + 6);
  const g = v.absGeom;
  const cx = g.x + g.width * 0.5;
  const cy = g.y + g.height * 0.5;
  let rx = cx - estW * 0.5;
  let ry = g.y + g.height + 3;
  let align = st.align || 'center';
  if (vPos === 'top') {
    ry = g.y - estH - 3;
  } else if (vPos === 'middle') {
    ry = cy - estH * 0.5;
    if (hPos === 'left') {
      rx = g.x - estW - 4;
      align = st.align || 'right';
    } else if (hPos === 'right') {
      rx = g.x + g.width + 4;
      align = st.align || 'left';
    }
  }
  return { x: rx, y: ry, w: estW, h: estH, fSize, align, vPos, hPos };
}

function drawTaskMarkerIcon(x, y, marker, strokeCol) {
  if (!marker || marker === 'abstract' || marker === 'none') return '';
  const ix = x + 7;
  const iy = y + 6;
  const c = (strokeCol && strokeCol !== 'none') ? strokeCol : '#000000';
  if (marker === 'user') {
    return [
      `<circle cx="${ix + 6}" cy="${iy + 3.2}" r="2.6" fill="none" stroke="${c}" stroke-width="1.25" />`,
      `<path d="M ${ix + 1.4} ${iy + 11.2} C ${ix + 1.4} ${iy + 7.6}, ${ix + 10.6} ${iy + 7.6}, ${ix + 10.6} ${iy + 11.2}" fill="none" stroke="${c}" stroke-width="1.25" stroke-linecap="round" />`
    ].join('');
  }
  if (marker === 'service') {
    const cx1 = ix + 4.8, cy1 = iy + 6.5, r1 = 3.1;
    const cx2 = ix + 9.4, cy2 = iy + 3.8, r2 = 2.2;
    const drawGear = (cx, cy, r, teeth) => {
      let pts = [];
      for (let i = 0; i < teeth * 2; i++) {
        const ang = (i * Math.PI) / teeth;
        const rad = i % 2 === 0 ? r + 1.1 : r - 0.5;
        pts.push(`${(cx + Math.cos(ang) * rad).toFixed(1)},${(cy + Math.sin(ang) * rad).toFixed(1)}`);
      }
      return `<polygon points="${pts.join(' ')}" fill="#ffffff" stroke="${c}" stroke-width="1.05" stroke-linejoin="round" /><circle cx="${cx}" cy="${cy}" r="${(r * 0.42).toFixed(1)}" fill="none" stroke="${c}" stroke-width="1" />`;
    };
    return drawGear(cx2, cy2, r2, 6) + drawGear(cx1, cy1, r1, 7);
  }
  if (marker === 'send') {
    return [
      `<rect x="${ix}" y="${iy + 1.5}" width="13" height="9" rx="1" fill="${c}" stroke="${c}" stroke-width="1.1" />`,
      `<polyline points="${ix + 0.8},${iy + 2.2} ${ix + 6.5},${iy + 6.5} ${ix + 12.2},${iy + 2.2}" fill="none" stroke="#ffffff" stroke-width="1.2" stroke-linejoin="round" />`
    ].join('');
  }
  if (marker === 'receive') {
    return [
      `<rect x="${ix}" y="${iy + 1.5}" width="13" height="9" rx="1" fill="#ffffff" stroke="${c}" stroke-width="1.2" />`,
      `<polyline points="${ix + 0.8},${iy + 2.2} ${ix + 6.5},${iy + 6.5} ${ix + 12.2},${iy + 2.2}" fill="none" stroke="${c}" stroke-width="1.15" stroke-linejoin="round" />`
    ].join('');
  }
  if (marker === 'script') {
    return [
      `<path d="M ${ix + 2} ${iy + 1} L ${ix + 11} ${iy + 1} C ${ix + 9} ${iy + 4}, ${ix + 12} ${iy + 8}, ${ix + 10} ${iy + 11} L ${ix + 1} ${iy + 11} C ${ix + 3} ${iy + 8}, ${ix} ${iy + 4}, ${ix + 2} ${iy + 1} Z" fill="#ffffff" stroke="${c}" stroke-width="1.1" />`,
      `<line x1="${ix + 3.5}" y1="${iy + 4}" x2="${ix + 8.5}" y2="${iy + 4}" stroke="${c}" stroke-width="1" />`,
      `<line x1="${ix + 3.2}" y1="${iy + 6.5}" x2="${ix + 8.2}" y2="${iy + 6.5}" stroke="${c}" stroke-width="1" />`,
      `<line x1="${ix + 3.0}" y1="${iy + 9}" x2="${ix + 7.5}" y2="${iy + 9}" stroke="${c}" stroke-width="1" />`
    ].join('');
  }
  return '';
}

function drawBpmnEventInnerIcon(cx, cy, r, symbol, outline, strokeCol) {
  if (!symbol || symbol === 'general' || symbol === 'none') return '';
  const isThrowing = outline === 'throwing' || outline === 'end';
  const ir = r * 0.56;
  if (symbol === 'timer') {
    const cr = ir * 0.96;
    const els = [`<circle cx="${cx}" cy="${cy}" r="${cr.toFixed(1)}" fill="#ffffff" stroke="${strokeCol}" stroke-width="1.25" />`];
    for (let k = 0; k < 8; k++) {
      const a = (k * Math.PI) / 4;
      const x1 = cx + Math.cos(a) * (cr * 0.72);
      const y1 = cy + Math.sin(a) * (cr * 0.72);
      const x2 = cx + Math.cos(a) * (cr * 0.96);
      const y2 = cy + Math.sin(a) * (cr * 0.96);
      els.push(`<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${strokeCol}" stroke-width="1" />`);
    }
    els.push(`<polyline points="${cx.toFixed(1)},${(cy - cr * 0.56).toFixed(1)} ${cx.toFixed(1)},${cy.toFixed(1)} ${(cx + cr * 0.45).toFixed(1)},${(cy + cr * 0.12).toFixed(1)}" fill="none" stroke="${strokeCol}" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" />`);
    return els.join('');
  }
  if (symbol === 'message') {
    const ew = ir * 1.95;
    const eh = ir * 1.32;
    const ex = cx - ew * 0.5;
    const ey = cy - eh * 0.5;
    const fill = isThrowing ? strokeCol : '#ffffff';
    const flapCol = isThrowing ? '#ffffff' : strokeCol;
    return [
      `<rect x="${ex.toFixed(1)}" y="${ey.toFixed(1)}" width="${ew.toFixed(1)}" height="${eh.toFixed(1)}" rx="1" fill="${fill}" stroke="${strokeCol}" stroke-width="1.25" />`,
      `<polyline points="${(ex + 0.6).toFixed(1)},${(ey + 0.8).toFixed(1)} ${cx.toFixed(1)},${(cy + eh * 0.08).toFixed(1)} ${(ex + ew - 0.6).toFixed(1)},${(ey + 0.8).toFixed(1)}" fill="none" stroke="${flapCol}" stroke-width="1.25" stroke-linejoin="round" />`
    ].join('');
  }
  if (symbol === 'error') {
    const s = ir * 0.94;
    const pts = [
      [cx - s * 0.82, cy + s * 0.68],
      [cx - s * 0.18, cy - s * 0.58],
      [cx + s * 0.16, cy - s * 0.04],
      [cx + s * 0.82, cy - s * 0.68],
      [cx + s * 0.18, cy + s * 0.58],
      [cx - s * 0.16, cy + s * 0.04]
    ].map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
    return `<polygon points="${pts}" fill="${isThrowing ? strokeCol : '#ffffff'}" stroke="${strokeCol}" stroke-width="1.15" stroke-linejoin="round" />`;
  }
  if (symbol === 'terminate') {
    return `<circle cx="${cx}" cy="${cy}" r="${(ir * 0.92).toFixed(1)}" fill="${strokeCol}" />`;
  }
  if (symbol === 'escalation') {
    const s = ir * 0.88;
    const pts = [
      [cx, cy - s],
      [cx + s * 0.75, cy + s * 0.78],
      [cx, cy + s * 0.25],
      [cx - s * 0.75, cy + s * 0.78]
    ].map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
    return `<polygon points="${pts}" fill="${isThrowing ? strokeCol : '#ffffff'}" stroke="${strokeCol}" stroke-width="1.2" stroke-linejoin="round" />`;
  }
  if (symbol === 'signal') {
    const s = ir * 0.85;
    const pts = [
      [cx, cy - s * 0.9],
      [cx + s * 0.82, cy + s * 0.68],
      [cx - s * 0.82, cy + s * 0.68]
    ].map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
    return `<polygon points="${pts}" fill="${isThrowing ? strokeCol : '#ffffff'}" stroke="${strokeCol}" stroke-width="1.2" stroke-linejoin="round" />`;
  }
  return '';
}

function drawBpmnGatewayInnerIcon(cx, cy, w, h, st, strokeCol) {
  const s = Math.min(w, h) * 0.22;
  const col = (strokeCol && strokeCol !== 'none') ? strokeCol : '#000000';
  let gwType = st.gwType;
  if (!gwType || gwType === 'event') {
    if (st.outline === 'end' && st.symbol === 'general') gwType = 'inclusive';
    else if (st.outline === 'catching' && st.symbol === 'multiple') gwType = 'event';
    else if (!gwType) gwType = 'exclusive';
  }
  if (gwType === 'exclusive') {
    return [
      `<line x1="${(cx - s * 0.85).toFixed(1)}" y1="${(cy - s * 0.85).toFixed(1)}" x2="${(cx + s * 0.85).toFixed(1)}" y2="${(cy + s * 0.85).toFixed(1)}" stroke="${col}" stroke-width="2.4" stroke-linecap="round" />`,
      `<line x1="${(cx + s * 0.85).toFixed(1)}" y1="${(cy - s * 0.85).toFixed(1)}" x2="${(cx - s * 0.85).toFixed(1)}" y2="${(cy + s * 0.85).toFixed(1)}" stroke="${col}" stroke-width="2.4" stroke-linecap="round" />`
    ].join('');
  }
  if (gwType === 'parallel') {
    return [
      `<line x1="${(cx - s * 1.05).toFixed(1)}" y1="${cy.toFixed(1)}" x2="${(cx + s * 1.05).toFixed(1)}" y2="${cy.toFixed(1)}" stroke="${col}" stroke-width="2.6" stroke-linecap="round" />`,
      `<line x1="${cx.toFixed(1)}" y1="${(cy - s * 1.05).toFixed(1)}" x2="${cx.toFixed(1)}" y2="${(cy + s * 1.05).toFixed(1)}" stroke="${col}" stroke-width="2.6" stroke-linecap="round" />`
    ].join('');
  }
  if (gwType === 'inclusive') {
    return `<circle cx="${cx}" cy="${cy}" r="${(s * 0.96).toFixed(1)}" fill="none" stroke="${col}" stroke-width="2.6" />`;
  }
  if (gwType === 'event') {
    const r1 = s * 1.15;
    const r2 = s * 0.92;
    const rp = s * 0.56;
    const pts = [];
    for (let k = 0; k < 5; k++) {
      const a = -Math.PI / 2 + (k * 2 * Math.PI) / 5;
      pts.push(`${(cx + Math.cos(a) * rp).toFixed(1)},${(cy + Math.sin(a) * rp).toFixed(1)}`);
    }
    return [
      `<circle cx="${cx}" cy="${cy}" r="${r1.toFixed(1)}" fill="none" stroke="${col}" stroke-width="1.2" />`,
      `<circle cx="${cx}" cy="${cy}" r="${r2.toFixed(1)}" fill="none" stroke="${col}" stroke-width="1.2" />`,
      `<polygon points="${pts.join(' ')}" fill="none" stroke="${col}" stroke-width="1.35" stroke-linejoin="round" />`
    ].join('');
  }
  return '';
}

function buildHtmlFromDiagramXml(singleXml) {
  const model = parseSingleDiagramXml(singleXml);
  const byId = new Map();
  for (const c of model.cells) byId.set(c.id, c);

  // Resolve absolute geometry for vertices
  const resolveAbs = (cell) => {
    if (cell.absGeom) return cell.absGeom;
    if (!cell.geom) { cell.absGeom = { x: 0, y: 0, width: 0, height: 0 }; return cell.absGeom; }
    if (!cell.parent || cell.parent === '1' || cell.parent === '0' || !byId.has(cell.parent)) {
      cell.absGeom = { x: cell.geom.x, y: cell.geom.y, width: cell.geom.width, height: cell.geom.height };
    } else {
      const pg = resolveAbs(byId.get(cell.parent));
      cell.absGeom = {
        x: pg.x + cell.geom.x,
        y: pg.y + cell.geom.y,
        width: cell.geom.width,
        height: cell.geom.height
      };
    }
    return cell.absGeom;
  };
  for (const c of model.cells) {
    if (c.vertex) resolveAbs(c);
  }

  // Compute routed edges & tight bounding box (Size: Diagram, Border: 0)
  const vertices = model.cells.filter((c) => c.vertex && c.id !== '0' && c.id !== '1');
  const edges = model.cells.filter((c) => c.edge);

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  const expandBbox = (x, y, w = 0, h = 0) => {
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x + w);
    maxY = Math.max(maxY, y + h);
  };

  for (const v of vertices) {
    if (v.absGeom && v.absGeom.width > 0 && v.absGeom.height > 0) {
      expandBbox(v.absGeom.x - 2, v.absGeom.y - 2, v.absGeom.width + 4, v.absGeom.height + 4);
      const ext = computeExternalLabelMetrics(v);
      if (ext) {
        expandBbox(ext.x - 2, ext.y - 2, ext.w + 4, ext.h + 4);
      }
    }
  }

  const vertSegsAccum = [];
  const edgeDrawList = [];

  for (const e of edges) {
    const sNode = byId.get(e.source);
    const tNode = byId.get(e.target);
    const st = e.style;
    const pStart = getPortPoint(sNode, parseFloat(st.exitX), parseFloat(st.exitY), [0, 0]);
    const pEnd = getPortPoint(tNode, parseFloat(st.entryX), parseFloat(st.entryY), [0, 0]);
    const midPts = (e.geom && e.geom.points) ? e.geom.points : [];
    const fullPts = [pStart, ...midPts, pEnd];
    for (const [px, py] of fullPts) expandBbox(px - 6, py - 6, 12, 12);

    // Label placement via relX + screen offset
    const relX = (e.geom && isFinite(e.geom.x)) ? e.geom.x : 0;
    const off = (e.geom && e.geom.offset) ? e.geom.offset : { x: 0, y: 0 };
    const anchor = pointAtRelX(fullPts, relX);
    const lblCx = anchor[0] + off.x;
    const lblCy = anchor[1] + off.y;
    if (e.value) {
      const plain = e.value.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '');
      const lines = plain.split('\n');
      const maxLen = Math.max(...lines.map((l) => l.length));
      const fSize = parseFloat(st.fontSize || 10);
      const estW = Math.max(24, maxLen * fSize * 0.58 + 10);
      const estH = lines.length * (fSize * 1.28) + 6;
      expandBbox(lblCx - estW * 0.5, lblCy - estH * 0.5, estW, estH);
    }

    const vertSnap = vertSegsAccum.slice();
    for (let i = 0; i < fullPts.length - 1; i++) {
      const a = fullPts[i], b = fullPts[i + 1];
      if (Math.abs(a[0] - b[0]) < 1.5 && Math.abs(a[1] - b[1]) >= 4) {
        vertSegsAccum.push({ x: 0.5 * (a[0] + b[0]), y1: Math.min(a[1], b[1]), y2: Math.max(a[1], b[1]) });
      }
    }

    edgeDrawList.push({ cell: e, fullPts, lblCx, lblCy, vertSnap });
  }

  if (!isFinite(minX)) { minX = 0; minY = 0; maxX = model.pageWidth; maxY = model.pageHeight; }
  const pad = 4;
  const shiftX = -minX + pad;
  const shiftY = -minY + pad;
  const svgW = Math.ceil(maxX - minX + 2 * pad);
  const svgH = Math.ceil(maxY - minY + 2 * pad);

  const swimlaneEls = [];
  const shapeEls = [];
  const boundaryEls = [];
  const edgeEls = [];
  const labelEls = [];

  for (const v of vertices) {
    const g = v.absGeom;
    if (!g) continue;
    const st = v.style;
    const x = g.x + shiftX;
    const y = g.y + shiftY;
    const w = g.width;
    const h = g.height;
    const sw = parseFloat(st.strokeWidth || 1.4);
    const strokeCol = (st.strokeColor && st.strokeColor !== 'none') ? st.strokeColor : 'none';
    const fillCol = (st.fillColor && st.fillColor !== 'none') ? st.fillColor : 'none';
    const fontCol = st.fontColor || '#000000';
    const fontSize = parseFloat(st.fontSize || 11);
    const fontWeight = st.fontStyle === '1' ? '700' : '400';
    const dashAttr = st.dashed === '1'
      ? `stroke-dasharray="${(st.dashPattern || '6 4').replace(/\s+/g, ',')}"`
      : '';

    if (st.swimlane === '1') {
      const startSize = parseFloat(st.startSize || 30);
      const bodyFill = st.swimlaneFillColor || '#ffffff';
      if (st.horizontal === '0') {
        const hx = x + startSize * 0.5;
        const hy = y + h * 0.5;
        const foW = Math.max(20, h - 10);
        swimlaneEls.push(
          `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${bodyFill}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
          `<rect x="${x}" y="${y}" width="${startSize}" height="${h}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
          `<g transform="translate(${hx.toFixed(1)}, ${hy.toFixed(1)}) rotate(-90)"><foreignObject x="${(-foW * 0.5).toFixed(1)}" y="${(-startSize * 0.5).toFixed(1)}" width="${foW.toFixed(1)}" height="${startSize}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${foW.toFixed(1)}px;height:${startSize}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:700;color:${fontCol};padding:0 4px;line-height:1.15;overflow:hidden;"><div>${v.value}</div></div></foreignObject></g>`
        );
      } else {
        swimlaneEls.push(
          `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${bodyFill}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
          `<rect x="${x}" y="${y}" width="${w}" height="${startSize}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
          `<foreignObject x="${x}" y="${y}" width="${w}" height="${startSize}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${w}px;height:${startSize}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:700;color:${fontCol};padding:0 6px;line-height:1.15;overflow:hidden;"><div>${v.value}</div></div></foreignObject>`
        );
      }
    } else if (st.shape === 'mxgraph.bpmn.task2') {
      const marker = st.taskMarker || 'abstract';
      const isSub = st.isLoopSub === '1';
      const padTop = (marker !== 'abstract' && marker !== 'none') ? 16 : 3;
      const padBot = isSub ? 15 : 3;
      const boxH = Math.max(12, h - padTop - padBot);
      const subMark = isSub
        ? `<rect x="${(x + w * 0.5 - 6).toFixed(1)}" y="${(y + h - 14).toFixed(1)}" width="12" height="12" fill="#ffffff" stroke="${strokeCol}" stroke-width="1.1" />` +
          `<line x1="${(x + w * 0.5 - 3).toFixed(1)}" y1="${(y + h - 8).toFixed(1)}" x2="${(x + w * 0.5 + 3).toFixed(1)}" y2="${(y + h - 8).toFixed(1)}" stroke="${strokeCol}" stroke-width="1.2" />` +
          `<line x1="${(x + w * 0.5).toFixed(1)}" y1="${(y + h - 11).toFixed(1)}" x2="${(x + w * 0.5).toFixed(1)}" y2="${(y + h - 5).toFixed(1)}" stroke="${strokeCol}" stroke-width="1.2" />`
        : '';
      shapeEls.push(
        `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" ry="8" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
        drawTaskMarkerIcon(x, y, marker, strokeCol),
        subMark,
        `<foreignObject x="${x + 5}" y="${y + padTop}" width="${Math.max(10, w - 10)}" height="${boxH}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${Math.max(10, w - 10)}px;height:${boxH}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.2;"><div>${v.value}</div></div></foreignObject>`
      );
    } else if (st.shape === 'mxgraph.bpmn.event') {
      const cx = x + w * 0.5;
      const cy = y + h * 0.5;
      const r = Math.min(w, h) * 0.5;
      const outline = st.outline || 'standard';
      const evSw = outline === 'end' ? Math.max(sw * 3, 2.8) : Math.max(sw, 1.2);
      const isDouble = outline === 'eventInt' || outline === 'boundInt' || outline === 'catching' || outline === 'throwing';
      const targetArr = outline === 'boundInt' ? boundaryEls : shapeEls;
      targetArr.push(`<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${r.toFixed(1)}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${evSw}" ${dashAttr} />`);
      if (isDouble) {
        targetArr.push(`<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${(r - 3.2).toFixed(1)}" fill="none" stroke="${strokeCol}" stroke-width="1.0" ${dashAttr} />`);
      }
      targetArr.push(drawBpmnEventInnerIcon(cx, cy, r, st.symbol || 'general', outline, strokeCol));
      const ext = computeExternalLabelMetrics(v);
      if (ext) {
        const jAlign = ext.hPos === 'right' ? 'flex-start' : (ext.hPos === 'left' ? 'flex-end' : 'center');
        const bx = ext.x + shiftX;
        const by = ext.y + shiftY;
        const boxW = Math.max(ext.w + 40, 220);
        let lx = bx + ext.w * 0.5 - boxW * 0.5;
        if (ext.hPos === 'right') lx = bx;
        else if (ext.hPos === 'left') lx = bx + ext.w - boxW;
        labelEls.push(
          `<foreignObject x="${lx.toFixed(1)}" y="${by.toFixed(1)}" width="${boxW}" height="${ext.h + 10}" style="overflow:visible;"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${boxW}px;display:flex;align-items:flex-start;justify-content:${jAlign};text-align:${ext.align};"><span style="display:inline-block;background:rgba(255,255,255,0.92);padding:1px 3px;border-radius:2px;font-family:Helvetica,Arial,sans-serif;font-size:${ext.fSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.22;white-space:nowrap;">${v.value}</span></div></foreignObject>`
        );
      }
    } else if (st.shape === 'mxgraph.bpmn.gateway2') {
      const cx = x + w * 0.5;
      const cy = y + h * 0.5;
      shapeEls.push(
        `<polygon points="${cx.toFixed(1)},${y.toFixed(1)} ${(x + w).toFixed(1)},${cy.toFixed(1)} ${cx.toFixed(1)},${(y + h).toFixed(1)} ${x.toFixed(1)},${cy.toFixed(1)}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" stroke-linejoin="round" />`,
        drawBpmnGatewayInnerIcon(cx, cy, w, h, st, strokeCol)
      );
      const ext = computeExternalLabelMetrics(v);
      if (ext) {
        const jAlign = ext.hPos === 'right' ? 'flex-start' : (ext.hPos === 'left' ? 'flex-end' : 'center');
        const bx = ext.x + shiftX;
        const by = ext.y + shiftY;
        const boxW = Math.max(ext.w + 40, 220);
        let lx = bx + ext.w * 0.5 - boxW * 0.5;
        if (ext.hPos === 'right') lx = bx;
        else if (ext.hPos === 'left') lx = bx + ext.w - boxW;
        labelEls.push(
          `<foreignObject x="${lx.toFixed(1)}" y="${by.toFixed(1)}" width="${boxW}" height="${ext.h + 10}" style="overflow:visible;"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${boxW}px;display:flex;align-items:flex-start;justify-content:${jAlign};text-align:${ext.align};"><span style="display:inline-block;background:rgba(255,255,255,0.92);padding:1px 3px;border-radius:2px;font-family:Helvetica,Arial,sans-serif;font-size:${ext.fSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.22;white-space:nowrap;">${v.value}</span></div></foreignObject>`
        );
      }
    } else if (st.shape === 'datastore') {
      const rx = w * 0.5;
      const ry = Math.min(7, h * 0.16);
      const bodyD = `M ${x} ${y + ry} L ${x} ${y + h - ry} A ${rx} ${ry} 0 0 0 ${x + w} ${y + h - ry} L ${x + w} ${y + ry} Z`;
      const topArc = (dy) => `M ${x} ${y + ry + dy} A ${rx} ${ry} 0 0 0 ${x + w} ${y + ry + dy}`;
      const capEllipse = `<ellipse cx="${(x + rx).toFixed(1)}" cy="${(y + ry).toFixed(1)}" rx="${rx.toFixed(1)}" ry="${ry.toFixed(1)}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" />`;
      const txtTop = y + ry * 2 + 4;
      const txtH = Math.max(12, h - ry * 2 - 6);
      shapeEls.push(
        `<path d="${bodyD}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" />`,
        capEllipse,
        `<path d="${topArc(3.2)}" fill="none" stroke="${strokeCol}" stroke-width="1" />`,
        `<path d="${topArc(6.4)}" fill="none" stroke="${strokeCol}" stroke-width="1" />`,
        `<foreignObject x="${x + 3}" y="${txtTop}" width="${Math.max(10, w - 6)}" height="${txtH}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${Math.max(10, w - 6)}px;height:${txtH}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.15;"><div>${v.value}</div></div></foreignObject>`
      );
    } else if (st.shape === 'note' || st.shape === 'mxgraph.bpmn.data2') {
      const fold = parseFloat(st.size || 10);
      const docD = `M ${x} ${y} L ${x + w - fold} ${y} L ${x + w} ${y + fold} L ${x + w} ${y + h} L ${x} ${y + h} Z`;
      const foldD = `M ${x + w - fold} ${y} L ${x + w - fold} ${y + fold} L ${x + w} ${y + fold}`;
      shapeEls.push(
        `<path d="${docD}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" stroke-linejoin="round" />`,
        `<path d="${foldD}" fill="none" stroke="${strokeCol}" stroke-width="${Math.max(1, sw - 0.2)}" stroke-linejoin="round" />`,
        `<foreignObject x="${x + 4}" y="${y + 4}" width="${Math.max(10, w - 8)}" height="${Math.max(10, h - 8)}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${Math.max(10, w - 8)}px;height:${Math.max(10, h - 8)}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.18;"><div>${v.value}</div></div></foreignObject>`
      );
    } else if (st.ellipse === '1') {
      const cx = x + w * 0.5, cy = y + h * 0.5;
      shapeEls.push(
        `<ellipse cx="${cx}" cy="${cy}" rx="${w * 0.5}" ry="${h * 0.5}" fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
        `<foreignObject x="${x + 4}" y="${y + 4}" width="${Math.max(10, w - 8)}" height="${Math.max(10, h - 8)}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${Math.max(10, w - 8)}px;height:${Math.max(10, h - 8)}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.22;"><div>${v.value}</div></div></foreignObject>`
      );
    } else if (st.shape === 'partialRectangle') {
      const pL = parseFloat(st.spacingLeft || 8);
      const pR = parseFloat(st.spacingRight || 6);
      shapeEls.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fillCol}" stroke="none" />`);
      if (st.top === '1') shapeEls.push(`<line x1="${x}" y1="${y}" x2="${x + w}" y2="${y}" stroke="${strokeCol}" stroke-width="${sw}" />`);
      if (st.bottom === '1') shapeEls.push(`<line x1="${x}" y1="${y + h}" x2="${x + w}" y2="${y + h}" stroke="${strokeCol}" stroke-width="${sw}" />`);
      if (st.left === '1') shapeEls.push(`<line x1="${x}" y1="${y}" x2="${x}" y2="${y + h}" stroke="${strokeCol}" stroke-width="${sw}" />`);
      if (st.right === '1') shapeEls.push(`<line x1="${x + w}" y1="${y}" x2="${x + w}" y2="${y + h}" stroke="${strokeCol}" stroke-width="${sw}" />`);
      shapeEls.push(
        `<foreignObject x="${x}" y="${y}" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${w}px;height:${h}px;display:flex;align-items:center;justify-content:flex-start;text-align:left;padding-left:${pL}px;padding-right:${pR}px;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.22;"><div>${v.value}</div></div></foreignObject>`
      );
    } else if (st.line === '1') {
      if (st.direction === 'south') {
        const lx = x + w * 0.5;
        shapeEls.push(`<line x1="${lx}" y1="${y}" x2="${lx}" y2="${y + h}" stroke="${strokeCol}" stroke-width="${sw}" />`);
      } else {
        const ly = y + h * 0.5;
        shapeEls.push(`<line x1="${x}" y1="${ly}" x2="${x + w}" y2="${ly}" stroke="${strokeCol}" stroke-width="${sw}" />`);
      }
    } else if (st.text === '1') {
      const pL = parseFloat(st.spacingLeft || 4);
      const pR = parseFloat(st.spacingRight || 4);
      const pT = parseFloat(st.spacingTop || 0);
      const align = st.align || 'center';
      const vAlign = st.verticalAlign || 'middle';
      const jAlign = align === 'left' ? 'flex-start' : (align === 'right' ? 'flex-end' : 'center');
      const aItems = vAlign === 'top' ? 'flex-start' : (vAlign === 'bottom' ? 'flex-end' : 'center');
      const ws = st.whiteSpace === 'nowrap' ? 'white-space:nowrap;' : '';
      shapeEls.push(
        `<foreignObject x="${x}" y="${y}" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${w}px;height:${h}px;display:flex;align-items:${aItems};justify-content:${jAlign};text-align:${align};padding-left:${pL}px;padding-right:${pR}px;padding-top:${pT}px;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.33;overflow:hidden;${ws}"><div>${v.value}</div></div></foreignObject>`
      );
    } else {
      const rx = st.rounded === '1' ? 'rx="6" ry="6"' : '';
      shapeEls.push(
        `<rect x="${x}" y="${y}" width="${w}" height="${h}" ${rx} fill="${fillCol}" stroke="${strokeCol}" stroke-width="${sw}" ${dashAttr} />`,
        `<foreignObject x="${x + 4}" y="${y + 2}" width="${Math.max(10, w - 8)}" height="${Math.max(10, h - 4)}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${Math.max(10, w - 8)}px;height:${Math.max(10, h - 4)}px;display:flex;align-items:center;justify-content:center;text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:${fontSize}px;font-weight:${fontWeight};color:${fontCol};line-height:1.22;"><div>${v.value}</div></div></foreignObject>`
      );
    }
  }

  for (const ed of edgeDrawList) {
    const { cell: e, fullPts, lblCx, lblCy, vertSnap } = ed;
    const st = e.style;
    const shiftedPts = fullPts.map(([px, py]) => [px + shiftX, py + shiftY]);
    const shiftedVert = vertSnap.map((vs) => ({ x: vs.x + shiftX, y1: vs.y1 + shiftY, y2: vs.y2 + shiftY }));

    const strokeCol = st.strokeColor || '#000000';
    const sw = parseFloat(st.strokeWidth || 1.4);
    const dashAttr = st.dashed === '1' ? `stroke-dasharray="${(st.dashPattern || '6 4').replace(/\s+/g, ',')}"` : '';

    const sArrow = st.startArrow || 'none';
    const eArrow = st.endArrow || 'classic';
    const sFill = st.startFill !== '0';
    const eFill = st.endFill !== '0';
    const sSize = parseFloat(st.startSize || 9);
    const eSize = parseFloat(st.endSize || 9);

    // Compute trimmed copy for stroke so markers never overlap stroke line
    const drawPts = shiftedPts.map((p) => [p[0], p[1]]);
    let startDir = [0, 0], endDir = [0, 0];
    if (drawPts.length >= 2) {
      const L0 = Math.hypot(drawPts[1][0] - drawPts[0][0], drawPts[1][1] - drawPts[0][1]);
      if (L0 > 0.1) {
        // unit FROM inside TOWARD start tip
        startDir = [(drawPts[0][0] - drawPts[1][0]) / L0, (drawPts[0][1] - drawPts[1][1]) / L0];
        const trimS = Math.min(L0 * 0.8, getMarkerShorten(sArrow, sSize, sFill));
        drawPts[0] = [shiftedPts[0][0] - startDir[0] * trimS, shiftedPts[0][1] - startDir[1] * trimS];
      }
      const n = drawPts.length;
      const L1 = Math.hypot(shiftedPts[n - 1][0] - drawPts[n - 2][0], shiftedPts[n - 1][1] - drawPts[n - 2][1]);
      if (L1 > 0.1) {
        // unit FROM inside TOWARD end tip
        endDir = [(shiftedPts[n - 1][0] - drawPts[n - 2][0]) / L1, (shiftedPts[n - 1][1] - drawPts[n - 2][1]) / L1];
        const trimE = Math.min(L1 * 0.8, getMarkerShorten(eArrow, eSize, eFill));
        drawPts[n - 1] = [shiftedPts[n - 1][0] - endDir[0] * trimE, shiftedPts[n - 1][1] - endDir[1] * trimE];
      }
    }

    const cornerR = st.rounded === '1' ? parseFloat(st.arcSize || 8) : 0;
    const jumpR = st.jumpStyle === 'arc' ? 4.5 : 0;
    const pathD = buildRoundedEdgePathD(drawPts, jumpR > 0 ? shiftedVert : [], jumpR, cornerR);
    edgeEls.push(`<path d="${pathD}" fill="none" stroke="${strokeCol}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" ${dashAttr} />`);

    if (sArrow !== 'none' && shiftedPts.length >= 2) {
      edgeEls.push(drawMarkerSvg(shiftedPts[0], startDir[0], startDir[1], sArrow, sSize, strokeCol, sFill));
    }
    if (eArrow !== 'none' && shiftedPts.length >= 2) {
      edgeEls.push(drawMarkerSvg(shiftedPts[shiftedPts.length - 1], endDir[0], endDir[1], eArrow, eSize, strokeCol, eFill));
    }

    if (e.value) {
      const fSize = parseFloat(st.fontSize || 10);
      const fCol = st.fontColor || strokeCol;
      const fWt = st.fontStyle === '1' ? '700' : '400';
      const bg = st.labelBackgroundColor || '#ffffff';
      const boxW = 360;
      const boxH = 120;
      const lx = lblCx + shiftX - boxW * 0.5;
      const ly = lblCy + shiftY - boxH * 0.5;
      labelEls.push(
        `<foreignObject x="${lx}" y="${ly}" width="${boxW}" height="${boxH}" style="overflow:visible;"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${boxW}px;height:${boxH}px;display:flex;align-items:center;justify-content:center;text-align:center;"><span style="display:inline-block;background:${bg};padding:1px 3px;border-radius:2px;font-family:Helvetica,Arial,sans-serif;font-size:${fSize}px;font-weight:${fWt};color:${fCol};line-height:1.22;white-space:nowrap;">${e.value}</span></div></foreignObject>`
      );
    }
  }

  const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { width: ${svgW}px; height: ${svgH}px; overflow: hidden; background: ${model.background}; font-family: Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; }
</style>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" width="${svgW}" height="${svgH}" viewBox="0 0 ${svgW} ${svgH}" style="display:block;background:${model.background};">
  <g>${swimlaneEls.join('\n')}</g>
  <g>${shapeEls.join('\n')}</g>
  <g>${boundaryEls.join('\n')}</g>
  <g>${edgeEls.join('\n')}</g>
  <g>${labelEls.join('\n')}</g>
</svg>
</body>
</html>`;

  return { html, width: svgW, height: svgH };
}

function readPngDimensions(pngPath) {
  const buf = fs.readFileSync(pngPath);
  if (buf.slice(0, 8).toString('hex') !== '89504e470d0a1a0a') return { w: 0, h: 0 };
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}

async function captureWithCdp(fileUrl, outPngPath, width, height, userDataDir) {
  const child = spawn(CHROME_PATH, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--remote-debugging-port=0',
    `--user-data-dir=${userDataDir}`,
    fileUrl
  ], { stdio: ['ignore', 'ignore', 'pipe'] });

  try {
    const wsUrl = await new Promise((resolve, reject) => {
      let buf = '';
      const timer = setTimeout(() => reject(new Error('CDP startup timeout')), 12000);
      child.stderr.on('data', (d) => {
        buf += d.toString('utf8');
        const m = buf.match(/DevTools listening on (ws:\/\/[^\s]+)/);
        if (m) {
          clearTimeout(timer);
          resolve(m[1]);
        }
      });
      child.on('error', (err) => { clearTimeout(timer); reject(err); });
      child.on('exit', (code) => { clearTimeout(timer); reject(new Error(`Chrome exited ${code}: ${buf}`)); });
    });

    const portMatch = wsUrl.match(/:(\d+)\//);
    const port = portMatch ? portMatch[1] : null;
    const targetsResp = await fetch(`http://127.0.0.1:${port}/json/list`);
    const targets = await targetsResp.json();
    const pageTarget = targets.find((t) => t.type === 'page') || targets[0];
    if (!pageTarget || !pageTarget.webSocketDebuggerUrl) throw new Error('No CDP page target found');

    const ws = new WebSocket(pageTarget.webSocketDebuggerUrl);
    await new Promise((res, rej) => {
      ws.addEventListener('open', res, { once: true });
      ws.addEventListener('error', rej, { once: true });
    });

    let msgId = 1;
    const callCdp = (method, params = {}) => new Promise((resolve, reject) => {
      const id = msgId++;
      const onMsg = (ev) => {
        const data = JSON.parse(typeof ev.data === 'string' ? ev.data : ev.data.toString());
        if (data.id === id) {
          ws.removeEventListener('message', onMsg);
          if (data.error) reject(new Error(data.error.message));
          else resolve(data.result);
        }
      };
      ws.addEventListener('message', onMsg);
      ws.send(JSON.stringify({ id, method, params }));
    });

    await callCdp('Emulation.setDeviceMetricsOverride', {
      width,
      height,
      deviceScaleFactor: 1,
      mobile: false
    });
    await callCdp('Page.navigate', { url: fileUrl });
    await new Promise((r) => setTimeout(r, 350));
    const cap = await callCdp('Page.captureScreenshot', {
      format: 'png',
      clip: { x: 0, y: 0, width, height, scale: 1 },
      captureBeyondViewport: true,
      fromSurface: true
    });
    fs.writeFileSync(outPngPath, Buffer.from(cap.data, 'base64'));
    ws.close();
  } finally {
    try { child.kill('SIGKILL'); } catch {}
  }
}

async function renderDrawioXmlToPng(xmlPathOrStr, outPngPathInput) {
  const outPngPath = path.resolve(outPngPathInput);
  const singleXml = xmlPathOrStr.trim().startsWith('<')
    ? xmlPathOrStr
    : fs.readFileSync(xmlPathOrStr, 'utf8');
  lib.verifyNoAiMetadata(singleXml);

  const { html, width, height } = buildHtmlFromDiagramXml(singleXml);
  const tmpDir = path.join(__dirname, 'tmp_render');
  const profileDir = path.join(tmpDir, 'chrome_prof_' + process.pid + '_' + Math.floor(Math.random() * 1e6));
  fs.mkdirSync(tmpDir, { recursive: true });
  fs.mkdirSync(path.dirname(outPngPath), { recursive: true });

  const stem = path.basename(outPngPath).replace(/[^a-zA-Z0-9._-]/g, '_');
  const htmlPath = path.join(tmpDir, stem + '.html');
  fs.writeFileSync(htmlPath, html, 'utf8');
  const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/').replace(/#/g, '%23');

  let usedCdp = false;
  try {
    try {
      execFileSync(CHROME_PATH, [
        '--headless=new',
        '--disable-gpu',
        '--hide-scrollbars',
        '--no-first-run',
        '--no-default-browser-check',
        '--force-device-scale-factor=1',
        `--user-data-dir=${profileDir}`,
        `--window-size=${width},${height}`,
        `--screenshot=${outPngPath}`,
        fileUrl
      ], { stdio: 'pipe', timeout: 25000 });
    } catch {}

    const dim = fs.existsSync(outPngPath) ? readPngDimensions(outPngPath) : { w: 0, h: 0 };
    if (dim.w !== width || dim.h !== height) {
      usedCdp = true;
      await captureWithCdp(fileUrl, outPngPath, width, height, profileDir + '_cdp');
    }
  } finally {
    try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch {}
    try { fs.rmSync(profileDir + '_cdp', { recursive: true, force: true }); } catch {}
  }

  lib.embedMxfileInPng(outPngPath, singleXml);
  const finalDim = readPngDimensions(outPngPath);
  return { outPngPath, width: finalDim.w, height: finalDim.h, expectedW: width, expectedH: height, usedCdp };
}

module.exports = {
  renderDrawioXmlToPng
};
