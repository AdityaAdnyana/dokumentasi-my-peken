---
document_title: "Requirement Marketplace UMKM MyPeken"
version: "UPDT22"
total_requirements: 41
id_range: "FR-001..FR-041"
geographic_scope: "Sarbagita (Kota Denpasar, Kab. Badung, Kab. Gianyar, Kab. Tabanan - Provinsi Bali)"
figma_ui_url: "https://www.figma.com/design/H75A4PbI7NiACWFYe9bQ2J/MYPEKEN?node-id=0-1&t=s3TQN4ssW0kPquNf-1"
team_members:
  - "I Putu Gde Aditya Stiti A"
  - "I Gede Putu Artha Jaya Winangun"
  - "Muhammad Rasyid Isnain Chandra"
  - "Farid Abdurrochman A"
  - "Daffa’ Azhar"
---

# Requirement Marketplace UMKM MyPeken (AI / LLM Optimized Specification)

## 1. Informasi Dokumen & Anggota Kelompok

- **Nama Proyek**: Marketplace UMKM MyPeken
- **Cakupan Wilayah Operasional**: Sarbagita (Kota Denpasar, Kab. Badung, Kab. Gianyar, Kab. Tabanan — Provinsi Bali)
- **Total Kebutuhan Fungsional**: 41 Functional Requirements (`FR-001` s.d. `FR-041`)
- **Link Gambaran UI (Figma)**: [Figma - MYPEKEN](https://www.figma.com/design/H75A4PbI7NiACWFYe9bQ2J/MYPEKEN?node-id=0-1&t=s3TQN4ssW0kPquNf-1)
- **Nama Anggota Kelompok**:
  1. I Putu Gde Aditya Stiti A
  2. I Gede Putu Artha Jaya Winangun
  3. Muhammad Rasyid Isnain Chandra
  4. Farid Abdurrochman A
  5. Daffa’ Azhar

---

## 2. Ringkasan Aktor & Aturan Bisnis Global (System Invariants)

### 2.1 Daftar Aktor Sistem
| ID Aktor | Nama Aktor | Deskripsi Hak Akses & Peran |
| :--- | :--- | :--- |
| `GUEST` | **Pengunjung (Guest Mode)** | Pengguna tanpa login yang dapat menjelajahi beranda, detail produk, halaman toko publik, serta menggunakan pencarian dan filter. |
| `BUYER` | **Pembeli (Buyer)** | Pengguna terdaftar dengan akses standar untuk membeli produk fisik UMKM maupun produk digital PPOB. |
| `SELLER` | **Penjual (Seller UMKM)** | Pengguna terdaftar yang telah melewati verifikasi KYC (KTP, Rekening Bank, Lokasi GPS Sarbagita) dan disetujui Admin untuk mengelola toko. |
| `ADMIN_CS` | **Admin CS** | Peran Admin untuk menangani Live Chat Handover dari AI (FR-017) serta Resolusi Konflik/Sengketa Retur (FR-010). |
| `ADMIN_OPS_KYC` | **Admin Operasional/KYC** | Peran Admin untuk menangani Verifikasi Toko Baru (FR-027), Moderasi & Tindak Lanjut Laporan Pelanggaran (FR-018, FR-040), serta Manajemen Kategori & Banner Beranda (FR-034). |
| `SUPER_ADMIN` | **Super Admin** | Peran Admin dengan akses penuh termasuk konfigurasi Biaya Layanan & Komisi (FR-009), Monitoring Penarikan/Tunggakan/Penahanan Saldo (FR-019), Fallback Verifikasi Rekening Penjual (FR-035), Dashboard Analitik/Keuangan/Rekonsiliasi (FR-041), dan Audit Log (FR-029). |

### 2.2 Aturan Bisnis Global (Core Invariants)
- **`INV-01` — Aturan Identitas Tunggal & Anti-Duplikasi**: 1 Email = 1 Akun, 1 Nomor HP/WhatsApp = 1 Akun, serta validasi daftar blokir (blacklist) NIK KTP dan Nomor Rekening Bank penunggak saat pembukaan toko (FR-001, FR-004, FR-015, FR-018).
- **`INV-02` — OTP Multi-Saluran (Anti-Single Point of Failure)**: Saluran utama: API WhatsApp. Fallback otomatis/manual setelah jeda 60 detik atau timeout: SMS Gateway ('Kirim lewat SMS') dan Email ('Kirim lewat Email' bagi email terverifikasi). Berlaku 5 menit (sekali pakai), cooldown resend 60 detik, maksimal 5 kali percobaan salah (blokir sementara 15 menit) (FR-001).
- **`INV-03` — Geofencing Wilayah Sarbagita**: Lokasi toko penjual (FR-004, FR-016), alamat pengiriman pembeli (FR-024), dan rute pengiriman logistik (FR-012) wajib berada di wilayah Sarbagita (Kota Denpasar, Kab. Badung, Kab. Gianyar, Kab. Tabanan, Provinsi Bali).
- **`INV-04` — Single-Seller Checkout & Anti Self-Purchase**: Satu transaksi checkout produk fisik hanya boleh memuat item dari satu toko yang sama, dan pengguna dilarang membeli atau memasukkan produk dari tokonya sendiri ke keranjang (FR-023).
- **`INV-05` — Penguncian Stok Atomik & Snapshot Harga/Komisi**: Stok produk/varian dikunci (reserve) secara atomik saat tagihan dibuat (FR-008). Harga normal, harga diskon, dan tarif komisi kategori disimpan sebagai snapshot pada pesanan (price snapshot & rate snapshot) serta produk dihapus secara soft delete (FR-005, FR-008, FR-009, FR-038).
- **`INV-06` — Pemisahan 2 Komponen Saldo Saya (Pembeli)**: 'Saldo Saya' dipisah menjadi: (1) 'Saldo Bebas Biaya Tarik' (refund akibat kesalahan penjual/kurir/sistem/gagal PPOB; bebas minimum penarikan & biaya transfer Rp0 ditanggung platform) dan (2) 'Saldo Reguler' (refund akibat pembatalan mandiri pembeli setelah 'Dibayar' atau komplain bukan kesalahan penjual/kurir; kena batas minimum penarikan & biaya transfer antar-bank). Saat berbelanja kembali, sistem memotong 'Saldo Reguler' terlebih dahulu (FR-025).
- **`INV-07` — Mitigasi Saldo Tertunggak Penjual (Auto-Suspend & Blacklist)**: Batas maksimum Saldo Tertunggak toko adalah Rp250.000 dengan tenggat pelunasan maksimal 14 hari kalender (pengingat H-3 dan H-1). Jika terlampaui, toko terkena Auto-Suspend. Jika ditelantarkan > 30 hari kalender, Admin dapat mem-blacklist NIK KTP dan Rekening Bank penjual (FR-004, FR-010, FR-015, FR-018, FR-019).
- **`INV-08` — Immutable Audit Log Admin**: Seluruh aksi sensitif Admin menyangkut dana, skema tarif, moderasi akun/toko/produk/ulasan, blacklist, dan ekspor laporan keuangan wajib menyertakan alasan dan tercatat permanen (immutable) di Audit Log yang hanya dapat dilihat Super Admin (FR-029).

---

## 3. Indeks Kebutuhan Fungsional (`FR-001` s.d. `FR-041`)

| No | Kode | Kategori Dokumen | Modul Domain | Judul FR | Relasi FR |
| :---: | :---: | :--- | :--- | :--- | :--- |
| 1 | `FR-001` | Autentikasi & Keamanan | Auth & Security | **Autentikasi Pengguna (OTP Multi-Saluran, Email & Password, & Google OAuth)** | `FR-026`, `FR-031`, `FR-039`, `FR-040` |
| 2 | `FR-002` | Fitur Pembeli (Buyer) | Buyer - Digital Products (PPOB) | **Transaksi Langsung (Checkout Cepat) Produk Digital PPOB** | `FR-025` |
| 3 | `FR-003` | Fitur Pembeli (Buyer) | Buyer - AI Customer Service | **Asisten Virtual Layanan Pelanggan Berbasis AI** | `FR-017` |
| 4 | `FR-004` | Fitur Penjual (Seller UMKM) | Seller - Onboarding & KYC | **Pembukaan Toko & Verifikasi Identitas Penjual (KYC)** | `FR-015`, `FR-018`, `FR-027`, `FR-037` |
| 5 | `FR-005` | Fitur Penjual (Seller UMKM) | Seller - Catalog, Variants, Showcase & Discounts | **Manajemen Produk, Varian, Etalase Toko, & Diskon Produk (CRUD)** | `FR-008`, `FR-012`, `FR-031`, `FR-032`, `FR-034`, `FR-038` |
| 6 | `FR-006` | Fitur Penjual (Seller UMKM) | Seller - Analytics Dashboard | **Dashboard Statistik & Performa Penjualan** | - |
| 7 | `FR-007` | Fitur Penjual (Seller UMKM) | Seller - Notifications | **Notifikasi Aktivitas Pesanan Penjual (In-App & WhatsApp)** | `FR-008`, `FR-010`, `FR-014`, `FR-020`, `FR-021` |
| 8 | `FR-008` | Transaksi, Pembayaran, & Admin | Transaction - Payment Gateway, Wallet & Escrow | **Integrasi Payment Gateway, Pembayaran Saldo, & Sistem Rekening Bersama (Escrow)** | `FR-002`, `FR-005`, `FR-009`, `FR-010`, `FR-012`, `FR-014`, `FR-016`, `FR-018`, `FR-020`, `FR-021`, `FR-025`, `FR-030`, `FR-033` |
| 9 | `FR-009` | Transaksi, Pembayaran, & Admin | Admin - Platform Fees & Commission Scheme | **Manajemen Skema Biaya Layanan Pembeli & Komisi Penjual** | `FR-002`, `FR-005`, `FR-008`, `FR-010`, `FR-020`, `FR-021`, `FR-025`, `FR-028`, `FR-029`, `FR-034`, `FR-041` |
| 10 | `FR-010` | Transaksi, Pembayaran, & Admin | Admin - Conflict Resolution & Return Disputes | **Panel Admin untuk Resolusi Konflik (Komplain, Partial Refund, & Sengketa Retur)** | `FR-007`, `FR-009`, `FR-012`, `FR-013`, `FR-015`, `FR-020`, `FR-022`, `FR-025`, `FR-029`, `FR-030`, `FR-036` |
| 11 | `FR-011` | Fitur Tambahan Pembeli | Buyer - Location-Based Search (LBS) | **Pencarian Produk/Toko Berbasis Lokasi (LBS) Terdekat** | `FR-001`, `FR-024`, `FR-026` |
| 12 | `FR-012` | Fitur Tambahan Pembeli | Buyer - Shipping & Insurance Calculation | **Kalkulasi Otomatis Ongkos Kirim & Asuransi Pengiriman (Integrasi Logistik)** | `FR-004`, `FR-005`, `FR-008`, `FR-010`, `FR-020`, `FR-023`, `FR-024`, `FR-037` |
| 13 | `FR-013` | Fitur Tambahan Pembeli | Buyer & Seller - Ratings, Reviews & Moderation | **Sistem Penilaian (Rating), Ulasan Produk, Balasan Penjual, & Moderasi Ulasan** | `FR-008`, `FR-010`, `FR-018`, `FR-020`, `FR-031`, `FR-040` |
| 14 | `FR-014` | Fitur Tambahan Penjual | Seller - Order Fulfillment & Shipping SLA | **Pemrosesan Pesanan & Resi Pengiriman** | `FR-012`, `FR-016`, `FR-021`, `FR-032`, `FR-036`, `FR-038` |
| 15 | `FR-015` | Fitur Tambahan Penjual | Seller - Store Balance, Arrears & Withdrawal | **Mutasi, Pelunasan Saldo Tertunggak, & Penarikan Saldo Pendapatan Toko (Withdrawal)** | `FR-001`, `FR-004`, `FR-008`, `FR-009`, `FR-010`, `FR-018`, `FR-019`, `FR-020`, `FR-033`, `FR-035` |
| 16 | `FR-016` | Fitur Tambahan Penjual | Seller - Store Profile, Operating Hours & Holiday Mode | **Pengaturan Profil, Hari/Jam Operasional, & Status Libur Toko** | `FR-004`, `FR-014` |
| 17 | `FR-017` | Fitur Tambahan Admin | Admin - Live Chat Support (AI Handover) | **Live Chat Dukungan Pelanggan (Handover dari AI)** | - |
| 18 | `FR-018` | Fitur Tambahan Admin | Admin - Platform Moderation & Abuse Reports | **Moderasi Akun Pengguna, Toko, Produk, Ulasan, & Tindak Lanjut Laporan Pelanggaran** | `FR-004`, `FR-008`, `FR-010`, `FR-013`, `FR-015`, `FR-017`, `FR-019`, `FR-021`, `FR-025`, `FR-029`, `FR-030`, `FR-031`, `FR-040` |
| 19 | `FR-019` | Fitur Tambahan Admin | Admin - Withdrawal Monitoring, Arrears & Balance Hold | **Monitoring Penarikan, Saldo Tertunggak, & Penahanan Saldo Penjual** | `FR-015`, `FR-018`, `FR-029`, `FR-041` |
| 20 | `FR-020` | Tambahan | Buyer & Seller - Order Confirmation, Mediation & Complaints | **Konfirmasi Penerimaan Pesanan, Mediasi Penjual, & Pengajuan Komplain** | `FR-008`, `FR-009`, `FR-010`, `FR-012`, `FR-013`, `FR-015`, `FR-025`, `FR-032`, `FR-036` |
| 21 | `FR-021` | Tambahan | Transaction - Order Cancellation & Automated Refunds | **Pembatalan Pesanan & Pengembalian Dana (Refund) Otomatis** | `FR-008`, `FR-009`, `FR-012`, `FR-014`, `FR-018`, `FR-025` |
| 22 | `FR-022` | Tambahan | Buyer - Order & Complaint Notifications | **Notifikasi Pelacakan Status Pesanan & Komplain Pembeli** | `FR-007`, `FR-010`, `FR-020`, `FR-021` |
| 23 | `FR-023` | Tambahan | Buyer - Shopping Cart, Direct Checkout & Single-Seller Scope | **Manajemen Keranjang Belanja, Beli Langsung (Direct Checkout), & Single-Seller Checkout** | `FR-005`, `FR-008`, `FR-012`, `FR-016`, `FR-018`, `FR-031` |
| 24 | `FR-024` | Tambahan | Buyer - Address Book Management | **Manajemen Buku Alamat Pengiriman Pembeli** | `FR-011`, `FR-012` |
| 25 | `FR-025` | Tambahan | Buyer - Refund Wallet (Saldo Saya) & Withdrawal | **Manajemen & Penarikan Saldo Refund Pembeli** | `FR-001`, `FR-002`, `FR-008`, `FR-010`, `FR-020`, `FR-021`, `FR-033` |
| 26 | `FR-026` | Tambahan | Buyer - Advanced Search, Filtering & Sorting | **Pencarian Lanjutan, Filter, & Pengurutan Produk** | `FR-004`, `FR-005`, `FR-011`, `FR-013`, `FR-016`, `FR-031`, `FR-034`, `FR-037` |
| 27 | `FR-027` | Tambahan | Admin - New Store KYC Approval | **Tinjauan & Persetujuan Verifikasi Toko Baru (Admin)** | `FR-004`, `FR-029` |
| 28 | `FR-028` | Tambahan | Admin - Authentication, RBAC & Session Management | **Autentikasi, RBAC Admin, & Logout Admin** | `FR-009`, `FR-010`, `FR-017`, `FR-018`, `FR-019`, `FR-027`, `FR-029`, `FR-034`, `FR-035`, `FR-040`, `FR-041` |
| 29 | `FR-029` | Tambahan | Admin - Immutable Audit Log | **Audit Log Aksi Admin** | `FR-009`, `FR-010`, `FR-018`, `FR-019`, `FR-027`, `FR-028`, `FR-035`, `FR-040`, `FR-041` |
| 30 | `FR-030` | Tambahan | Buyer & Logistics - Shipment Tracking & Status Sync | **Sinkronisasi Status & Pelacakan Pengiriman** | `FR-010`, `FR-014` |
| 31 | `FR-031` | Tambahan | Public & Buyer - Homepage, Product Detail & Storefront | **Eksplorasi Beranda (Guest Mode), Detail Produk, & Halaman Toko Publik (Etalase Toko)** | `FR-001`, `FR-005`, `FR-013`, `FR-016`, `FR-023`, `FR-026`, `FR-034`, `FR-036`, `FR-037`, `FR-039`, `FR-040` |
| 32 | `FR-032` | Tambahan | Buyer - Order List & Transaction History | **Daftar & Riwayat Pesanan Pembeli** | `FR-002`, `FR-012`, `FR-014`, `FR-020`, `FR-021`, `FR-030`, `FR-036`, `FR-038` |
| 33 | `FR-033` | Tambahan | User Account - Profile, PIN Saldo, Security & Account Closure | **Manajemen Profil Pengguna, Keamanan Akun (PIN Saldo & Password), Penutupan Akun, & Logout** | `FR-001`, `FR-008`, `FR-010`, `FR-015`, `FR-017`, `FR-019`, `FR-025`, `FR-035` |
| 34 | `FR-034` | Tambahan | Admin - Category Hierarchy & Homepage Banners | **Manajemen Kategori, Sub-Kategori Produk, & Banner Beranda (Admin)** | `FR-005`, `FR-009`, `FR-026`, `FR-028`, `FR-031` |
| 35 | `FR-035` | Tambahan | Seller - Self-Service Bank Account Change | **Perubahan Rekening Bank Penjual (Mandiri / Self-Service)** | `FR-001`, `FR-004`, `FR-015`, `FR-016`, `FR-019`, `FR-028`, `FR-029`, `FR-033` |
| 36 | `FR-036` | Tambahan | Buyer & Seller - Direct In-App Chat | **Fitur Chat (Komunikasi Langsung) Pembeli & Penjual** | `FR-008`, `FR-010`, `FR-014`, `FR-031`, `FR-032` |
| 37 | `FR-037` | Tambahan | Seller - Store Courier Service Configuration | **Pengaturan Layanan Kurir Pengiriman Toko (Penjual)** | `FR-012`, `FR-016` |
| 38 | `FR-038` | Tambahan | Buyer & Seller - Shipping Label & Transaction Invoice PDF | **Cetak Label Pengiriman & Invoice Transaksi** | `FR-005`, `FR-008`, `FR-012`, `FR-014`, `FR-024`, `FR-032` |
| 39 | `FR-039` | Tambahan | Buyer - Product Wishlist & Store Follow | **Wishlist Produk & Ikuti Toko (Follow)** | `FR-001`, `FR-031` |
| 40 | `FR-040` | Tambahan | User - Report Abuse (Products, Stores & Spam Reviews) | **Pelaporan Produk, Toko, & Ulasan Spam (Report Abuse)** | `FR-001`, `FR-013`, `FR-018`, `FR-028`, `FR-029`, `FR-031` |
| 41 | `FR-041` | Tambahan | Super Admin - Platform Analytics, Financial Position & Reconciliation | **Dashboard Analitik, Keuangan, & Rekonsiliasi Pendapatan Platform (Super Admin)** | `FR-002`, `FR-008`, `FR-009`, `FR-010`, `FR-012`, `FR-015`, `FR-019`, `FR-020`, `FR-021`, `FR-025`, `FR-028`, `FR-029`, `FR-034` |

---

## 4. Spesifikasi Detail Kebutuhan Fungsional (Functional Requirements)

### Kategori: Autentikasi & Keamanan

#### [FR-001] Autentikasi Pengguna (OTP Multi-Saluran, Email & Password, & Google OAuth)
- **No**: 1
- **Kode FR**: `FR-001`
- **Kategori**: Autentikasi & Keamanan
- **Modul Domain**: Auth & Security
- **Aktor Terkait**: `Pengunjung (Guest)`, `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-026`, `FR-031`, `FR-039`, `FR-040`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengguna (pembeli/penjual), saya ingin mendaftar dan login menggunakan nomor HP/WhatsApp (OTP dengan cadangan SMS/Email), Email & Password, maupun akun Google, sehingga saya memiliki fleksibilitas metode masuk dengan keamanan terjamin tanpa ketergantungan tunggal pada satu layanan.
- **Acceptance Criteria**:
  - Pengunjung tanpa login (Guest Mode) dapat melihat Beranda Utama, Detail Produk, Halaman Toko, dan menggunakan pencarian/filter (FR-026, FR-031); autentikasi wajib baru dipicu saat pengunjung menekan "Masukkan Keranjang", "Beli", "Chat Penjual", "Wishlist/Favorit", "Ikuti Toko", "Laporkan Produk/Toko/Ulasan", atau "Buka Toko" (selaras dengan FR-031, FR-039, FR-040).
  - Halaman login/register menyediakan tiga pilihan metode autentikasi: (1) Masuk/Daftar langsung dengan Nomor HP/WhatsApp (passwordless via OTP), (2) Masuk/Daftar dengan Email & Password, dan (3) "Login with Google" (Google OAuth).
  - Jalur Nomor HP/WhatsApp: Pengguna menginput nomor HP/WhatsApp aktif lalu memverifikasi 6 digit kode OTP (dikirim via WhatsApp dengan cadangan SMS OTP). Jika nomor sudah terdaftar, pengguna langsung masuk ke akunnya; jika belum terdaftar, sistem membuat akun baru (meminta input Nama Tampilan dasar) dan langsung mengaktifkannya.
  - Jalur Email & Password: Pengguna mendaftar dengan menginput Nama Tampilan, alamat Email aktif, dan Password (minimal 8 karakter kombinasi huruf dan angka, disimpan terenkripsi/hashed), lalu memverifikasi alamat email via 6 digit kode Email OTP serta menautkan dan memverifikasi nomor HP aktif via OTP (WhatsApp/SMS) sebelum melakukan transaksi atau penarikan dana (aturan 1 Email = 1 Akun dan 1 Nomor HP = 1 Akun). Tersedia fitur "Lupa Password" untuk mengatur ulang password menggunakan verifikasi 6 digit Email OTP (atau SMS/WhatsApp OTP ke nomor tertaut).
  - Jalur Google OAuth: Setelah autentikasi Google berhasil, sistem mengecek apakah akun Google sudah terdaftar. Jika pengguna baru, sistem mewajibkan input dan verifikasi nomor HP/WhatsApp aktif via 6 digit kode OTP (WhatsApp dengan cadangan SMS) untuk kebutuhan notifikasi dan verifikasi transaksi; jika nomor tersebut sudah terdaftar sebelumnya, sistem menawarkan penautan akun Google ke akun eksisting setelah OTP berhasil (aturan 1 Nomor HP/WhatsApp = 1 Akun guna mencegah duplikasi).
  - Ketentuan Pengiriman 6 Digit Kode OTP Multi-Saluran (Anti-Single Point of Failure): Sistem menggunakan API WhatsApp sebagai saluran utama pengiriman OTP; apabila API WhatsApp mengalami gangguan/timeout atau pengguna tidak menerima pesan setelah jeda 60 detik, sistem menyediakan pengalihan (fallback) otomatis maupun tombol manual "Kirim lewat SMS" (SMS Gateway) serta "Kirim lewat Email" (khusus pengguna yang telah memiliki email terverifikasi). Kode OTP berlaku selama 5 menit (sekali pakai), jeda kirim ulang (resend) minimal 60 detik, dan batas maksimal 5 kali percobaan salah (jika terlampaui, kode hangus dan permintaan OTP baru diblokir sementara 15 menit).
  - Setelah autentikasi berhasil, akun otomatis aktif dengan akses standar (Pembeli) dan diarahkan kembali ke halaman terakhir atau Beranda Utama.
  - Pada halaman Profil Pengguna, tersedia tombol "Buka Toko Gratis" (jika belum memiliki toko) atau "Toko Saya / Dashboard Toko" (jika toko sudah aktif) untuk beralih antarmuka antara mode Pembeli dan Penjual.

### Kategori: Fitur Pembeli (Buyer)

#### [FR-002] Transaksi Langsung (Checkout Cepat) Produk Digital PPOB
- **No**: 2
- **Kode FR**: `FR-002`
- **Kategori**: Fitur Pembeli (Buyer)
- **Modul Domain**: Buyer - Digital Products (PPOB)
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-025`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin melihat Action Chip (shortcut) di halaman utama untuk pembelian produk seperti (Pulsa, Paket Data, Token Listrik, PDAM), sehingga saya bisa bertransaksi dengan cepat langsung ke pembayaran tanpa masuk ke keranjang belanja.
- **Acceptance Criteria**:
  - Terdapat deretan ikon shortcut di bagian atas homepage.
  - Klik ikon mengarahkan ke halaman form spesifik (contoh: form input nomor meteran PLN atau nomor HP).
  - Harga dan ketersediaan terhubung dengan API PPOB pihak ketiga.
  - Setelah nominal/produk dipilih, pengguna langsung diarahkan ke halaman checkout (lewati keranjang) untuk segera melakukan pembayaran.
  - Setelah pembayaran produk digital (contoh: Token Listrik) berhasil, sistem wajib menampilkan Nomor Token atau bukti bayar secara langsung di halaman Detail Pesanan.
  - Jika pembayaran pembeli sudah berhasil terverifikasi oleh Payment Gateway namun sistem PPOB pihak ketiga gagal memproses transaksi (misalnya gangguan server biller atau nomor tujuan tidak valid), status pesanan otomatis berubah menjadi "Batal" dan sistem mengembalikan 100% dana pembayaran secara otomatis ke "Saldo Saya" milik pembeli (FR-025).

#### [FR-003] Asisten Virtual Layanan Pelanggan Berbasis AI
- **No**: 3
- **Kode FR**: `FR-003`
- **Kategori**: Fitur Pembeli (Buyer)
- **Modul Domain**: Buyer - AI Customer Service
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-017`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin menggunakan fitur obrolan Customer Service berbasis API Layanan AI/LLM pihak ketiga, sehingga saya bisa mendapatkan jawaban cepat untuk pertanyaan umum (FAQ, cara beli, lacak pesanan) kapan saja.
- **Acceptance Criteria**:
  - Terdapat tombol floating chat bertuliskan "Bantuan AI" atau ikon maskot aplikasi.
  - AI memahami pertanyaan berbahasa Indonesia dan menjawab secara konsisten berdasarkan basis pengetahuan resmi MyPeken.
  - Jika pertanyaan berada di luar cakupan basis pengetahuan atau AI tidak dapat menyelesaikan masalah, AI menyatakan ketidaktahuannya dan menampilkan tombol "Hubungkan ke Admin" untuk mengalihkan obrolan ke Live Chat Admin (FR-017).
  - Sistem backend menyediakan integrasi API internal agar AI dapat membaca dan menarik data status pengiriman terbaru langsung dari database berdasarkan Nomor Pesanan yang diketik pembeli; AI hanya boleh mengembalikan pesanan milik pengguna yang sedang login.

### Kategori: Fitur Penjual (Seller UMKM)

#### [FR-004] Pembukaan Toko & Verifikasi Identitas Penjual (KYC)
- **No**: 4
- **Kode FR**: `FR-004`
- **Kategori**: Fitur Penjual (Seller UMKM)
- **Modul Domain**: Seller - Onboarding & KYC
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-015`, `FR-018`, `FR-027`, `FR-037`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengguna terdaftar, saya ingin mengajukan pembukaan toko melalui proses verifikasi identitas (KTP), rekening bank, dan lokasi toko di wilayah Sarbagita (Denpasar, Badung, Gianyar, Tabanan), sehingga saya dapat mulai berjualan secara legal dan aman di platform.
- **Acceptance Criteria**:
  - Pengguna menekan tombol "Buka Toko Gratis" dari halaman Profil Akun untuk mengakses form pendaftaran toko.
  - Selama status pengajuan toko masih "Menunggu Verifikasi Admin" atau "Ditolak", pengguna tetap dapat menggunakan akunnya secara normal untuk berbelanja sebagai pembeli.
  - Calon penjual wajib mengisi informasi dasar profil toko: Nama Toko (unik), Deskripsi Singkat Toko, dan Foto/Logo Toko.
  - Calon penjual wajib mengunggah foto KTP asli, menginput NIK KTP, dan mengunggah foto selfie memegang KTP.
  - Calon penjual wajib memasukkan detail Rekening Bank dengan nama pemilik yang sesuai dengan nama di KTP untuk pencairan dana.
  - Validasi Daftar Blokir Tunggakan: Sistem secara otomatis memeriksa NIK KTP dan nomor Rekening Bank yang diajukan terhadap daftar blokir (blacklist) akun penunggak (FR-015, FR-018); apabila terdeteksi masih memiliki saldo tertunggak yang belum dilunasi dari toko sebelumnya, pendaftaran otomatis ditolak dengan notifikasi kewajiban pelunasan tunggakan terlebih dahulu.
  - Calon penjual wajib mengisi alamat lengkap dan menandai titik koordinat GPS (pin maps); sistem memvalidasi bahwa koordinat berada khusus di wilayah Sarbagita (Kota Denpasar, Kab. Badung, Kab. Gianyar, atau Kab. Tabanan, Provinsi Bali) dan otomatis menolak pendaftaran jika lokasi di luar ketentuan.
  - Calon penjual wajib memilih minimal satu layanan kurir pengiriman awal yang didukung toko (dapat diubah kembali setelah toko aktif melalui FR-037).
  - Setelah data dikirim, status pengajuan menjadi "Menunggu Verifikasi Admin"; setelah disetujui (FR-027), penjual resmi memperoleh akses ke dashboard toko.

#### [FR-005] Manajemen Produk, Varian, Etalase Toko, & Diskon Produk (CRUD)
- **No**: 5
- **Kode FR**: `FR-005`
- **Kategori**: Fitur Penjual (Seller UMKM)
- **Modul Domain**: Seller - Catalog, Variants, Showcase & Discounts
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-008`, `FR-012`, `FR-031`, `FR-032`, `FR-034`, `FR-038`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin menambah dan mengelola produk beserta varian, dimensi, sub-kategori, etalase toko, dan diskon harga coret (tanpa voucher) secara lengkap, sehingga pembeli mendapatkan informasi akurat, promosi menarik, dan perhitungan ongkir yang tepat.
- **Acceptance Criteria**:
  - Saat menambah produk, penjual wajib mengisi Nama Produk, Foto, Deskripsi, Harga Normal, Stok, Berat Produk (gram/kg), Dimensi Produk (P × L × T dalam cm) untuk antisipasi berat volumetrik kurir (FR-012), serta memilih dropdown bertingkat Kategori Utama dan Sub-Kategori (FR-034).
  - Mendukung penambahan varian produk hingga 2 tingkat varian (contoh: 1 tingkat seperti Ukuran M/L atau Kemasan 250g/500g, maupun 2 tingkat kombinasi seperti Warna + Ukuran).
  - Apabila produk memiliki varian, maka Harga Normal, Diskon Produk (opsional), Stok, Berat Produk (gram/kg), dan Dimensi (P × L × T) ditetapkan secara terpisah per masing-masing kombinasi varian dan menjadi acuan langsung untuk validasi/penguncian stok atomik (FR-008) serta kalkulasi ongkos kirim (FR-012); apabila tanpa varian, nilai tersebut mengacu pada data produk induk.
  - Pengaturan Diskon Produk (Harga Coret — Tanpa Voucher): Penjual dapat menetapkan diskon opsional langsung pada produk induk maupun per masing-masing varian dalam bentuk persentase (1%–90%) atau nominal harga setelah diskon. Sistem otomatis memvalidasi bahwa harga setelah diskon wajib lebih rendah dari Harga Normal dan lebih besar dari Rp0, serta otomatis menampilkan persentase potongan. Penjual dapat mengatur periode berlaku diskon (opsional: tanggal & jam mulai hingga berakhir) atau mengaktifkan/menonaktifkan diskon secara manual kapan saja; apabila periode berakhir, harga otomatis kembali ke Harga Normal. Skema ini murni diskon harga per produk/varian yang ditanggung penjual (tanpa kode voucher/kupon, tanpa diskon ongkir, dan tanpa subsidi platform). Perubahan atau penghentian diskon hanya berlaku untuk transaksi baru (price snapshot tersimpan pada data pesanan FR-008 & Invoice FR-038).
  - Manajemen Etalase Toko: Penjual dapat membuat, mengubah nama, dan menghapus Etalase Toko kustom (maksimal 10 etalase per toko, contoh: "Best Seller", "Oleh-Oleh Khas") serta mengelompokkan produk secara opsional ke dalam satu etalase agar tampil terstruktur di Halaman Toko Publik (FR-031); menghapus etalase tidak menghapus produk di dalamnya (produk tetap tampil pada tab "Semua Produk").
  - Penjual dapat mengedit detail produk yang sudah ada (harga normal, diskon, stok, berat, dimensi, varian, kategori/sub-kategori, etalase, foto, dan deskripsi).
  - Penjual dapat menghapus (secara soft delete agar riwayat Detail Pesanan FR-032 dan Invoice FR-038 tetap utuh melalui product snapshot) atau menonaktifkan sementara (hide) produk dari toko jika barang kosong/tidak diproduksi lagi.

#### [FR-006] Dashboard Statistik & Performa Penjualan
- **No**: 6
- **Kode FR**: `FR-006`
- **Kategori**: Fitur Penjual (Seller UMKM)
- **Modul Domain**: Seller - Analytics Dashboard
- **Aktor Terkait**: `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: Tidak ada
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin melihat statistik penjualan di dashboard, sehingga saya bisa memantau performa toko (pendapatan, jumlah pesanan, produk terlaris).
- **Acceptance Criteria**:
  - Dashboard menampilkan grafik pendapatan harian/mingguan/bulanan.
  - Menampilkan total pesanan selesai dan pesanan batal.
  - Menampilkan daftar 5 produk paling laris di toko tersebut.

#### [FR-007] Notifikasi Aktivitas Pesanan Penjual (In-App & WhatsApp)
- **No**: 7
- **Kode FR**: `FR-007`
- **Kategori**: Fitur Penjual (Seller UMKM)
- **Modul Domain**: Seller - Notifications
- **Aktor Terkait**: `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-008`, `FR-010`, `FR-014`, `FR-020`, `FR-021`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin menerima notifikasi in-app di dashboard dan pesan WhatsApp prioritas terkait pesanan baru, permintaan pembatalan, komplain, retur, serta pembaruan penting lainnya, sehingga saya bisa memantau aktivitas toko secara real-time tanpa bergantung pada satu saluran.
- **Acceptance Criteria**:
  - Sistem menyediakan Push Notification / Notifikasi In-App di dashboard penjual sebagai saluran utama untuk seluruh pembaruan pesanan, serta integrasi API WhatsApp sebagai saluran prioritas (khusus "Pesanan Baru Masuk") untuk efisiensi biaya dan menghindari single point of failure.
  - Notifikasi dikirim otomatis kepada penjual ketika: (1) "Pesanan Baru Masuk" (dikirim via In-App dan WhatsApp saat pembeli berhasil membayar; memuat Nomor Pesanan, Nama Barang, jenis kurir beserta batas waktu respon, dan tautan aplikasi penjual); (2) "Permintaan Pembatalan dari Pembeli" (dikirim via In-App saat pembeli mengajukan pembatalan pada pesanan berstatus "Diproses" sesuai FR-021, agar penjual segera menyetujui atau menolak sebelum barang diserahkan ke kurir); (3) "Pesanan Dibatalkan" (dikirim via In-App jika pembeli membatalkan sebelum diproses atau dibatalkan otomatis oleh sistem pada FR-014 & FR-021); (4) "Komplain Masuk (Mediasi) & Pembaruan Retur" (dikirim via In-App saat pembeli mengajukan komplain pada FR-020 beserta tenggat tanggapan 1×24 jam, saat paket retur pembeli berstatus "Terkirim" beserta tenggat konfirmasi/bantahan retur 2×24 jam pada FR-010, serta hasil keputusan akhir Admin pada FR-010); (5) "Pesanan Selesai" (dikirim via In-App saat pembeli menekan "Pesanan Diterima" pada FR-020 atau selesai otomatis 2×24 jam pada FR-008, menginformasikan dana bersih setelah potongan komisi telah masuk ke Saldo Toko).

### Kategori: Transaksi, Pembayaran, & Admin

#### [FR-008] Integrasi Payment Gateway, Pembayaran Saldo, & Sistem Rekening Bersama (Escrow)
- **No**: 8
- **Kode FR**: `FR-008`
- **Kategori**: Transaksi, Pembayaran, & Admin
- **Modul Domain**: Transaction - Payment Gateway, Wallet & Escrow
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-002`, `FR-005`, `FR-009`, `FR-010`, `FR-012`, `FR-014`, `FR-016`, `FR-018`, `FR-020`, `FR-021`, `FR-025`, `FR-030`, `FR-033`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin membayar pesanan menggunakan Payment Gateway yang aman (Transfer Bank, E-Wallet, QRIS) maupun "Saldo Saya" hasil refund dengan pengamanan PIN Saldo, sehingga transaksi terverifikasi otomatis dan dana aman sebelum pesanan diterima.
- **Acceptance Criteria**:
  - Halaman checkout menampilkan rincian harga: Harga Barang (menampilkan harga normal dicoret, potongan diskon produk jika aktif sesuai FR-005, dan subtotal harga efektif) + Ongkir + Biaya Asuransi Pengiriman (jika aktif/wajib sesuai FR-012) + Biaya Layanan Pembeli flat sesuai FR-009.
  - Sebelum tagihan dibuat (saat tombol "Bayar Sekarang" ditekan), sistem melakukan validasi atomik ulang secara real-time untuk memastikan stok produk/varian masih mencukupi, produk aktif, harga dan status periode diskon produk masih berlaku (FR-005), serta toko tidak sedang "Libur" (FR-016) maupun "Suspended" (FR-018); jika stok/toko tidak valid atau periode diskon baru saja berakhir/harga berubah, pembuatan tagihan ditolak dengan pesan spesifik (beserta pembaruan harga terbaru untuk dikonfirmasi ulang pembeli) tanpa memotong dana.
  - Segera setelah validasi lolos dan tagihan dibuat, sistem langsung mengunci (reserve) stok produk secara atomik guna mencegah race condition (overselling) serta menyimpan price snapshot harga normal dan harga diskon pada data pesanan.
  - Pembeli diarahkan ke antarmuka pemilihan metode bayar untuk memilih Payment Gateway (Transfer Bank/VA, E-Wallet, QRIS) atau "Saldo Saya" (FR-025) tanpa batas minimum (pembayaran penuh maupun split payment); apabila pembeli memilih membayar menggunakan "Saldo Saya" (penuh maupun split payment), sistem mewajibkan verifikasi 6 digit PIN Saldo (FR-033) sebelum saldo dipotong (jika belum memiliki PIN Saldo, pembeli diarahkan membuat PIN terlebih dahulu).
  - Sistem menerapkan batas waktu bayar (15 menit QRIS/E-Wallet; 24 jam VA); jika kedaluwarsa atau dibatalkan manual oleh pembeli pada status "Menunggu Bayar" (FR-021), pesanan otomatis berstatus "Batal", stok yang dikunci dikembalikan, dan potongan "Saldo Saya" (jika split payment) langsung dikembalikan utuh.
  - Sistem memperbarui status menjadi "Dibayar" saat dana masuk dan menahan seluruh dana pembayaran di sistem (escrow); porsi ongkos kirim awal beserta premi Asuransi Pengiriman (jika ada) disalurkan ke pihak jasa logistik setelah pengiriman berjalan (status "Dikirim", FR-014).
  - Dana dilepaskan ke Saldo Toko penjual secara otomatis setelah pembeli menekan "Pesanan Diterima" (FR-020) atau otomatis 2x24 jam setelah status resi "Terkirim" (FR-030) tanpa komplain, dengan pemotongan otomatis Komisi Penjual persentase (mengacu FR-009) yang dihitung dari pendapatan harga barang efektif setelah diskon produk. Untuk keputusan Partial Refund (FR-010, FR-020), dana escrow dibagi berdasarkan rincian nominal Partial Refund per item produk ke "Saldo Saya" pembeli dan sisanya ke Saldo Toko penjual dengan potongan komisi proporsional per item sesuai rumus pada FR-009; untuk pembatalan dan Full Refund, alokasi dana harga barang, ongkir awal, Biaya Asuransi Pengiriman, dan Biaya Layanan Pembeli mengikuti ketentuan FR-009, FR-010, FR-020, dan FR-021.
  - Mekanisme escrow dan konfirmasi 2x24 jam hanya berlaku untuk produk fisik UMKM; transaksi produk digital PPOB (FR-002) langsung berstatus "Selesai" setelah API PPOB mengembalikan nomor token/bukti berhasil.

#### [FR-009] Manajemen Skema Biaya Layanan Pembeli & Komisi Penjual
- **No**: 9
- **Kode FR**: `FR-009`
- **Kategori**: Transaksi, Pembayaran, & Admin
- **Modul Domain**: Admin - Platform Fees & Commission Scheme
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`, `Super Admin`
- **Referensi / Relasi FR**: `FR-002`, `FR-005`, `FR-008`, `FR-010`, `FR-020`, `FR-021`, `FR-025`, `FR-028`, `FR-029`, `FR-034`, `FR-041`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai Super Admin, saya ingin mengatur biaya layanan flat bagi pembeli serta skema potongan komisi persentase (minimum 1%) bagi penjual berdasarkan kategori produk, sehingga pendapatan platform terkelola transparan dan sesuai dengan karakteristik margin tiap kategori UMKM.
- **Acceptance Criteria**:
  - Terdapat menu konfigurasi "Biaya Layanan & Komisi" di dashboard Super Admin (FR-028).
  - Super Admin dapat menetapkan Biaya Layanan Pembeli berbentuk flat fee (contoh: Rp1.000-Rp2.000 per transaksi produk fisik UMKM) yang ditambahkan otomatis pada struk checkout pembeli.
  - Ketentuan Pengembalian Biaya Layanan Pembeli: Biaya Layanan Pembeli dikembalikan 100% ke "Saldo Bebas Biaya Tarik" pembeli (FR-025) apabila pesanan batal akibat penolakan/kelalaian penjual, pembatalan otomatis sistem, kegagalan PPOB, atau keputusan Full Refund karena kesalahan penjual/kurir (FR-002, FR-010, FR-020, FR-021). Sebaliknya, apabila pembeli melakukan pembatalan mandiri setelah status "Dibayar" (FR-021), terjadi keputusan Full Refund yang bukan kesalahan penjual/kurir (FR-010), atau pesanan diselesaikan dengan Partial Refund (FR-010, FR-020), maka Biaya Layanan Pembeli tidak dikembalikan (non-refundable) untuk menutup biaya pemrosesan Payment Gateway.
  - Super Admin dapat mengatur tarif Komisi Penjual persentase (minimum 1%) berdasarkan Kategori Utama (FR-034), mencakup penetapan tarif default global (misalnya 1%) serta tarif khusus per Kategori Utama (contoh: Kuliner 1%, Fesyen/Kerajinan 2%). Seluruh Sub-Kategori di bawah suatu Kategori Utama otomatis mewarisi tarif komisi Kategori Utama induknya. Apabila Admin Operasional menambahkan Kategori Utama baru pada FR-034, kategori tersebut otomatis mewarisi tarif default global hingga disesuaikan oleh Super Admin.
  - Komisi persentase penjual dihitung per item produk sesuai Kategori Utamanya berdasarkan harga jual efektif barang setelah potongan diskon produk (FR-005) dan dipotong otomatis dari pendapatan harga barang milik penjual pada saat dana escrow cair ke Saldo Toko (FR-008); perubahan tarif hanya berlaku untuk pesanan baru dan tidak mengubah transaksi yang sudah dibuat (rate snapshot).
  - Rumus Komisi Proporsional untuk Partial Refund (Lintas Kategori): Pada pesanan yang diselesaikan dengan Partial Refund (FR-010, FR-020), nominal pengembalian wajib diinput secara terpisah per item produk yang bermasalah. Komisi penjual dihitung pada masing-masing item dengan rumus: (Harga Efektif Item setelah Diskon - Nominal Partial Refund Item) x Tarif Komisi Kategori Utama Item (sesuai rate snapshot pesanan), sehingga perhitungan tetap akurat meskipun satu pesanan berisi beberapa item dari kategori berbeda.
  - Transaksi produk digital PPOB (FR-002) dikecualikan dari skema komisi penjual dan menggunakan biaya admin flat (contoh: Rp1.500 per transaksi).
  - Seluruh realisasi pendapatan platform yang dihasilkan dari Komisi Penjual, Biaya Layanan Pembeli (non-refundable), serta biaya admin/margin PPOB otomatis teragregasi untuk dipantau dan direkonsiliasi pada Dashboard Analitik, Keuangan, & Rekonsiliasi Pendapatan Platform (FR-041).
  - Setiap perubahan aturan tarif mewajibkan input alasan dan tercatat di Audit Log (FR-029).

#### [FR-010] Panel Admin untuk Resolusi Konflik (Komplain, Partial Refund, & Sengketa Retur)
- **No**: 10
- **Kode FR**: `FR-010`
- **Kategori**: Transaksi, Pembayaran, & Admin
- **Modul Domain**: Admin - Conflict Resolution & Return Disputes
- **Aktor Terkait**: `Penjual (Seller UMKM)`, `Admin CS`, `Super Admin`
- **Referensi / Relasi FR**: `FR-007`, `FR-009`, `FR-012`, `FR-013`, `FR-015`, `FR-020`, `FR-022`, `FR-025`, `FR-029`, `FR-030`, `FR-036`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai Admin CS / Super Admin, saya ingin memiliki panel "Resolusi Konflik" untuk menangani komplain yang dieskalasi dari mediasi penjual maupun bantahan penjual atas barang retur, sehingga sengketa transaksi dapat diputuskan secara adil termasuk pengembalian sebagian dana.
- **Acceptance Criteria**:
  - Panel Resolusi Konflik menerima komplain yang gagal disepakati/ditolak/tidak direspons pada tahap Mediasi Penjual 1x24 jam (FR-020), pengiriman berstatus "Gagal Kirim/Dikembalikan" (FR-030), serta pengajuan bantahan penjual atas kondisi barang retur.
  - Admin dapat meninjau bukti transaksi, status polis Asuransi Pengiriman (FR-012), alasan komplain, riwayat chat pembeli-penjual (FR-036), tanggapan/bukti bantahan penjual dari tahap mediasi maupun bukti video unboxing bantahan retur penjual, bukti pendukung pembeli (FR-020), serta riwayat pelacakan (FR-030).
  - Admin memiliki 3 tombol keputusan (masing-masing mewajibkan input alasan serta pemilihan pihak penanggung/penyebab sengketa):
  - 1. "Kembalikan Dana Penuh ke Pembeli" (status akhir pesanan menjadi "Batal (Dana Dikembalikan)" dan tidak dapat diulas pada FR-013), dengan alokasi dana berdasarkan penyebab sengketa: (a) Kesalahan Penjual (barang rusak/cacat, salah kirim, jumlah kurang): pembeli menerima 100% Harga Barang + Ongkir Pengiriman Awal + Biaya Asuransi Pengiriman (jika ada) + Biaya Layanan Pembeli ke "Saldo Bebas Biaya Tarik" (FR-025); beban ongkir pengiriman awal dan premi asuransi yang telah dibayarkan ke kurir ditanggung penjual (dipotong dari Saldo Toko penjual, atau dicatat sebagai saldo tertunggak yang tunduk pada batas, tenggat pelunasan, dan pembekuan otomatis pada FR-015), sedangkan Biaya Layanan Pembeli dikembalikan oleh platform. (b) Bukan Kesalahan Penjual (misalnya alamat pembeli tidak valid/penerima menolak paket pada kasus Gagal Kirim/Dikembalikan FR-030 atau alasan pribadi pembeli): pembeli hanya menerima 100% Harga Barang ke "Saldo Reguler" (FR-025), sedangkan ongkir pengiriman awal, Biaya Asuransi Pengiriman (jika ada), dan Biaya Layanan Pembeli tidak dikembalikan (ditanggung pembeli). (c) Kesalahan/Kelalaian Kurir (paket hilang atau rusak dalam pengiriman): Alokasi ganti rugi mengikuti status Asuransi Pengiriman pesanan (FR-012): (i) Jika pesanan menggunakan Asuransi Pengiriman: pembeli menerima pengembalian 100% Harga Barang + Ongkir Pengiriman Awal + Biaya Layanan Pembeli ke "Saldo Bebas Biaya Tarik" (FR-025), sementara premi asuransi yang telah digunakan untuk klaim tidak dikembalikan dan platform memproses pencairan klaim asuransi penuh ke pihak logistik tanpa membebani penjual maupun platform; (ii) Jika pesanan tidak menggunakan Asuransi Pengiriman (khusus pesanan bernilai rendah di bawah ambang batas wajib asuransi pada FR-012): nilai ganti rugi yang dialokasikan kepada pembeli dibatasi sesuai plafon maksimal ganti rugi standar kurir dari API logistik (misalnya maksimal 10x ongkir atau batas resmi ketentuan kurir) ditambah pengembalian Biaya Layanan Pembeli ke "Saldo Bebas Biaya Tarik" (FR-025), sehingga platform tidak menanggung selisih kerugian di luar polis kurir.
  - 2. "Teruskan Dana Penuh ke Penjual" (dana bersih ke Saldo Toko penjual setelah potongan komisi FR-009; status akhir pesanan menjadi "Selesai" dan tetap dapat diulas pada FR-013).
  - 3. "Pengembalian Dana Sebagian (Partial Refund)": Admin wajib menginput nominal pengembalian sebagian secara terpisah per masing-masing item produk yang bermasalah (maksimal sebesar subtotal harga efektif item tersebut setelah diskon) untuk kasus barang kurang/rusak sebagian tanpa retur seluruh paket; dana escrow terbagi ke "Saldo Saya" pembeli (masuk ke "Saldo Bebas Biaya Tarik" jika kesalahan penjual/kurir, atau "Saldo Reguler" jika bukan kesalahan penjual) dan sisanya ke Saldo Toko penjual dengan potongan komisi proporsional per item sesuai rumus pada FR-009. Ongkir pengiriman awal, Biaya Asuransi Pengiriman (jika ada), dan Biaya Layanan Pembeli tidak dikembalikan pada skema Partial Refund. Status akhir pesanan menjadi "Selesai" dengan keterangan Partial Refund sehingga pembeli tetap memiliki hak memberikan ulasan pada FR-013.
  - Setelah diputuskan Admin, dana otomatis dialokasikan sesuai keputusan, notifikasi dikirim ke pembeli (FR-022) dan penjual (FR-007), dan aksi tercatat di Audit Log (FR-029).
  - Alur Retur & Bantahan Penjual: Untuk kasus barang fisik rusak/salah kirim yang memerlukan pengembalian penuh, Admin dapat memicu status "Menunggu Pengembalian Barang": pembeli wajib menginput resi retur beserta bukti struk ongkir retur maksimal 3x24 jam (jika terlewat, komplain gugur dan dana diteruskan ke penjual). Setelah resi retur berstatus "Terkirim", penjual diberikan waktu maksimal 2x24 jam dengan dua opsi aksi: (a) "Konfirmasi Penerimaan Retur" (dana refund cair otomatis ke pembeli sesuai alokasi keputusan di atas), atau (b) "Ajukan Bantahan Retur" apabila paket retur yang diterima kosong, ditukar, atau rusak di luar kesepakatan (wajib mengisi alasan dan mengunggah foto/video unboxing paket retur). Apabila penjual mengajukan bantahan retur, status berubah menjadi "Sengketa Retur (Ditinjau Admin)" dan dana escrow tetap ditahan hingga Admin menjatuhkan keputusan final yang mengikat (tercatat di Audit Log FR-029); apabila penjual tidak merespons hingga melewati 2x24 jam, dana refund otomatis cair ke pembeli.
  - Mekanisme Ongkos Kirim Retur: Pembeli menalangi ongkir retur terlebih dahulu. Jika terbukti kesalahan penjual, Admin memverifikasi bukti struk ongkir sehingga sistem otomatis mengganti ongkir retur ke "Saldo Bebas Biaya Tarik" pembeli bersamaan dengan dana refund (dipotong dari Saldo Toko penjual; jika tidak mencukupi, tercatat sebagai saldo tertunggak yang tunduk pada batas maksimum, tenggat pelunasan 14 hari, dan pembekuan otomatis pada FR-015). Jika bukan kesalahan penjual, ongkir retur tetap ditanggung pembeli.

### Kategori: Fitur Tambahan Pembeli

#### [FR-011] Pencarian Produk/Toko Berbasis Lokasi (LBS) Terdekat
- **No**: 11
- **Kode FR**: `FR-011`
- **Kategori**: Fitur Tambahan Pembeli
- **Modul Domain**: Buyer - Location-Based Search (LBS)
- **Aktor Terkait**: `Pengunjung (Guest)`, `Pembeli`
- **Referensi / Relasi FR**: `FR-001`, `FR-024`, `FR-026`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengunjung/pembeli, saya ingin mencari produk atau toko UMKM yang diurutkan berdasarkan jarak terdekat dari lokasi saya, sehingga pengiriman bisa lebih cepat.
- **Acceptance Criteria**:
  - Aplikasi meminta pop-up izin akses lokasi (GPS) saat pengguna pertama kali membuka pencarian berbasis lokasi.
  - Jika izin GPS diberikan, hasil pencarian produk/toko diurutkan berdasarkan radius kilometer terdekat menggunakan layanan pemetaan digital (Maps API) dan terintegrasi sebagai opsi pengurutan "Terdekat" (default saat lokasi aktif) pada FR-026.
  - Jika izin GPS ditolak, sistem otomatis menggunakan "Alamat Utama" (FR-024) bagi pembeli yang sudah login; bagi pengunjung Guest Mode (FR-001), sistem menampilkan katalog dengan urutan default "Relevansi" (atau titik acuan pusat Kota Denpasar).

#### [FR-012] Kalkulasi Otomatis Ongkos Kirim & Asuransi Pengiriman (Integrasi Logistik)
- **No**: 12
- **Kode FR**: `FR-012`
- **Kategori**: Fitur Tambahan Pembeli
- **Modul Domain**: Buyer - Shipping & Insurance Calculation
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-004`, `FR-005`, `FR-008`, `FR-010`, `FR-020`, `FR-023`, `FR-024`, `FR-037`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin memilih jasa pengiriman beserta perlindungan Asuransi Pengiriman yang tersedia di toko, di mana sistem menghitung biaya ongkos kirim, premi asuransi, dan estimasi tibanya secara otomatis.
- **Acceptance Criteria**:
  - Sistem terintegrasi dengan API logistik pihak ketiga.
  - Layanan pengiriman hanya mendukung rute antar-wilayah di dalam cakupan Sarbagita (Kota Denpasar, Kab. Badung, Kab. Gianyar, dan Kab. Tabanan, Provinsi Bali), baik kurir instan/same-day maupun reguler lokal.
  - Sistem otomatis memvalidasi titik alamat penjual (FR-004) dan pembeli (FR-024) sebelum menghitung ongkir; jika di luar Sarbagita, proses checkout ditolak dengan notifikasi di luar jangkauan.
  - Daftar opsi kurir yang ditampilkan saat checkout disaring hanya berdasarkan layanan kurir yang sedang diaktifkan oleh toko tersebut (FR-037). Jika tidak ada kurir aktif yang mendukung rute, berat, atau dimensi pesanan, sistem menampilkan pesan kendala spesifik dan mencegah checkout hingga keranjang disesuaikan.
  - Aturan Agregasi Berat & Dimensi Multi-Item (FR-023): Apabila pembeli melakukan checkout lebih dari satu item produk atau kuantitas lebih dari 1 dalam satu toko, sistem melakukan agregasi sebelum mengirim parameter ke API logistik dengan rumus: (1) Total Berat Aktual = jumlah dari (Berat Aktual per item/varian x Kuantitas) seluruh item terpilih; (2) Berat Volumetrik per item/varian = (P x L x T) / pembagi volumetrik standar kurir dari API logistik (misalnya 6.000), lalu Total Berat Volumetrik = jumlah dari (Berat Volumetrik per item/varian x Kuantitas); dan (3) Berat Tertagih (chargeable weight) = nilai terbesar antara Total Berat Aktual dan Total Berat Volumetrik (mengikuti aturan pembulatan masing-masing kurir). Khusus kurir Instan dan Same-Day, sistem juga memvalidasi bahwa ukuran item terbesar serta total berat/volume paket tidak melebihi batas kapasitas armada kurir.
  - Sistem otomatis menghitung opsi ongkos kirim beserta estimasi waktu tiba (ETD) dari API logistik berdasarkan titik alamat penjual, titik alamat pembeli, serta hasil perhitungan Berat Tertagih dari data berat aktual dan dimensi (P x L x T) pada FR-005, lalu menyimpan ETD tersebut pada data pesanan sebagai acuan SLA pengiriman (FR-020).
  - Mekanisme Asuransi Pengiriman: Halaman checkout menyediakan opsi "Asuransi Pengiriman" dengan tarif premi yang dihitung otomatis melalui API logistik berdasarkan total nilai harga efektif barang (FR-005). Ketentuan aktivasi asuransi dibagi menjadi dua: (1) Pesanan Bernilai Tinggi (subtotal harga barang >= Rp500.000 atau produk kategori bernilai tinggi seperti kerajinan perak/kain tenun endek): Asuransi Pengiriman diaktifkan secara wajib otomatis (tidak dapat dinonaktifkan) guna menjamin penggantian 100% apabila terjadi kehilangan/kerusakan oleh kurir; (2) Pesanan Standar (< Rp500.000): Asuransi Pengiriman bersifat opsional (checkbox); apabila pembeli tidak memilih asuransi, sistem menampilkan catatan peringatan jelas bahwa klaim kehilangan/kerusakan oleh kurir dibatasi sesuai plafon standar kurir (misalnya maksimal 10x ongkir, mengacu FR-010).
  - Biaya ongkos kirim beserta Biaya Asuransi Pengiriman (jika aktif/wajib) ditanggung sepenuhnya oleh pembeli dan ditambahkan ke total pembayaran checkout (FR-008).

#### [FR-013] Sistem Penilaian (Rating), Ulasan Produk, Balasan Penjual, & Moderasi Ulasan
- **No**: 13
- **Kode FR**: `FR-013`
- **Kategori**: Fitur Tambahan Pembeli
- **Modul Domain**: Buyer & Seller - Ratings, Reviews & Moderation
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-008`, `FR-010`, `FR-018`, `FR-020`, `FR-031`, `FR-040`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin memberikan rating dan ulasan beserta foto pada produk yang telah diterima dalam batas waktu yang jelas, sebagai penjual saya ingin memberikan balasan publik pada ulasan pembeli, dan sebagai pengguna terdaftar saya ingin melaporkan ulasan spam agar reputasi produk tetap akurat dan sehat.
- **Acceptance Criteria**:
  - Tombol "Beri Ulasan" muncul pada pesanan pembeli hanya setelah status akhir pesanan berubah menjadi "Selesai" (mencakup pesanan diterima normal, selesai otomatis 2×24 jam pada FR-008, maupun pesanan yang diselesaikan dengan keputusan Partial Refund atau Teruskan Dana Penuh ke Penjual pada FR-010/FR-020); tombol ulasan tidak muncul pada pesanan berstatus "Batal" atau pengembalian dana penuh (Full Refund).
  - Batas Waktu Pengisian Ulasan: Pembeli memiliki batas waktu maksimal 30 hari kalender sejak status pesanan berubah menjadi "Selesai" untuk mengirimkan rating dan ulasan (1 kali pengisian per item produk dalam pesanan, tanpa fitur edit setelah dikirim); apabila melewati 30 hari, tombol "Beri Ulasan" otomatis dinonaktifkan.
  - Pembeli dapat memberikan rating bintang (skala 1–5), menuliskan deskripsi ulasan, serta mengunggah foto produk (maksimal 3 foto, format JPG/PNG).
  - Penjual dapat memberikan maksimal 1 kali balasan publik ("Balas Ulasan") per ulasan melalui dashboard toko.
  - Ulasan pembeli, foto, balasan penjual, dan rata-rata bintang ditampilkan secara publik di halaman Detail Produk (FR-031).
  - Pelaporan & Moderasi Ulasan Spam: Setiap kartu ulasan pada Detail Produk (FR-031) maupun halaman ulasan di Dashboard Toko menyediakan tombol "Laporkan Ulasan" bagi pengguna terdaftar (pembeli maupun penjual) untuk melaporkan komentar spam, kata kasar, promosi pihak lain, atau dugaan ulasan palsu (mengacu mekanisme FR-040). Apabila Admin menyetujui penghapusan/penyembunyian ulasan melalui panel moderasi (FR-018), ulasan beserta balasannya segera disembunyikan dari tampilan publik dan rata-rata rating produk serta rating keseluruhan toko otomatis dihitung ulang secara real-time.

### Kategori: Fitur Tambahan Penjual

#### [FR-014] Pemrosesan Pesanan & Resi Pengiriman
- **No**: 14
- **Kode FR**: `FR-014`
- **Kategori**: Fitur Tambahan Penjual
- **Modul Domain**: Seller - Order Fulfillment & Shipping SLA
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-012`, `FR-016`, `FR-021`, `FR-032`, `FR-036`, `FR-038`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin memperbarui status pesanan (Terima/Tolak Pesanan, menanggapi permintaan pembatalan) dan memproses pengiriman dengan resi/kurir sesuai batas waktu layanan kurir, sehingga sistem dan pembeli dapat melacak status pengiriman barang.
- **Acceptance Criteria**:
  - Terdapat halaman "Daftar Pesanan" untuk melihat dan mengelola pesanan masuk berdasarkan status ("Dibayar", "Diproses" termasuk sub-status "Mencari Driver", dan riwayat pengiriman), dilengkapi tombol pintas "Chat Pembeli" (FR-036) dan "Cetak Label Pengiriman" (FR-038).
  - Penjual memiliki tombol "Proses Pesanan" (pada status "Dibayar" : "Diproses"), "Tolak Pesanan" (pada status "Dibayar"; wajib isi alasan, memicu batal & refund FR-021), "Kirim Pesanan" (pada status "Diproses"), serta tombol "Setujui Pembatalan" / "Tolak Pembatalan" apabila pembeli mengajukan permintaan pembatalan pada pesanan berstatus "Diproses" (sebelum masuk sub-status "Mencari Driver" atau status "Dikirim", mengacu FR-021).
  - Batas Waktu (SLA Timer) Pemrosesan & Pengiriman dibedakan berdasarkan kategori kurir yang dipilih pembeli (FR-012), dengan acuan jadwal hari dan jam operasional toko (FR-016): (1) Kurir Reguler Lokal: Maksimal 1×24 jam hari operasional untuk memproses/menolak pesanan berstatus "Dibayar", dan maksimal 2×24 jam hari operasional untuk mengirim/menerbitkan resi setelah berstatus "Diproses". (2) Kurir Same-Day: Maksimal 3 jam operasional untuk memproses/menolak pesanan berstatus "Dibayar", dan maksimal 4 jam operasional (atau sebelum batas cut-off penjemputan kurir Same-Day pada hari operasional yang sama) untuk menekan "Kirim Pesanan" (memanggil driver) setelah berstatus "Diproses". (3) Kurir Instan: Maksimal 2 jam operasional untuk memproses/menolak pesanan berstatus "Dibayar", dan maksimal 2 jam operasional untuk menekan "Kirim Pesanan" (memanggil driver) setelah berstatus "Diproses".
  - Apabila penjual melewati batas waktu terima atau kirim sesuai kategori kurir di atas, sistem otomatis membatalkan pesanan dan memproses refund penuh ke Saldo Saya pembeli (FR-021).
  - Aturan timer: jika pembayaran terjadi di luar jam operasional atau pada hari libur rutin mingguan, perhitungan waktu baru dimulai pada jam buka hari operasional berikutnya; hari libur rutin mingguan dilewati, sedangkan pengaktifan toggle "Libur/Tutup Toko" manual (FR-016) tidak menjeda timer pesanan masuk.
  - Saat menekan "Kirim Pesanan" untuk kurir reguler/ekspedisi, sistem menerbitkan booking code / resi otomatis melalui API Logistik untuk mencegah resi fiktif (input nomor resi manual yang valid hanya disediakan sebagai fallback darurat apabila API kurir tidak mendukung auto-booking).
  - Alur & Transisi Status Kurir Instan/Same-Day: Saat penjual menekan "Kirim Pesanan" untuk kurir instan/same-day, sistem otomatis memanggil driver pihak ketiga (API Logistik), status pesanan berpindah ke sub-status "Mencari Driver" (di dalam kelompok tab "Diproses" pada FR-032), timer SLA kirim penjual (2 jam Instan / 4 jam Same-Day) otomatis berhenti, dan digantikan oleh timer pencarian driver (maksimal 3 jam untuk Instan, atau 6 jam / melewati cut-off hari operasional untuk Same-Day). Jika driver tidak ditemukan dalam 15 menit, penjual menerima notifikasi untuk mencoba ulang pemanggilan. Selama berstatus "Mencari Driver", pembeli tidak dapat mengajukan permintaan pembatalan baru. Jika driver tetap tidak ditemukan hingga melewati batas waktu pencarian driver tersebut, pesanan otomatis "Batal" dan di-refund penuh (FR-021).
  - Status pesanan otomatis berubah menjadi "Dikirim" setelah resi reguler diterbitkan/diinput atau driver instan/same-day berhasil ditemukan.

#### [FR-015] Mutasi, Pelunasan Saldo Tertunggak, & Penarikan Saldo Pendapatan Toko (Withdrawal)
- **No**: 15
- **Kode FR**: `FR-015`
- **Kategori**: Fitur Tambahan Penjual
- **Modul Domain**: Seller - Store Balance, Arrears & Withdrawal
- **Aktor Terkait**: `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-001`, `FR-004`, `FR-008`, `FR-009`, `FR-010`, `FR-018`, `FR-019`, `FR-020`, `FR-033`, `FR-035`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin memantau riwayat mutasi saldo toko, melunasi saldo tertunggak secara mandiri, dan menarik saldo pendapatan toko ke rekening bank pribadi secara aman dengan PIN Saldo dan OTP multi-saluran secara otomatis, sehingga arus kas serta kewajiban toko mudah dikontrol tanpa persetujuan manual.
- **Acceptance Criteria**:
  - Terdapat halaman "Saldo Toko" yang menampilkan total pendapatan, saldo ditahan (FR-019), saldo tertunggak (FR-010, FR-020), dan saldo bersih yang bisa ditarik (Total Saldo - Saldo Ditahan - Saldo Tertunggak).
  - Halaman "Saldo Toko" menyediakan tab/tabel "Riwayat Mutasi Saldo" yang mencatat seluruh aliran dana masuk dan keluar secara kronologis, meliputi: (1) Dana Masuk dari pelepasan escrow pesanan selesai beserta rincian potongan komisi penjual (FR-008, FR-009), (2) Dana Keluar dari penarikan dana (withdrawal) beserta potongan biaya transfer, (3) Pemotongan/pembayaran beban ongkir pengiriman awal dan premi asuransi (untuk kasus Full Refund akibat kesalahan penjual), penggantian ongkir retur, maupun pelunasan saldo tertunggak (FR-010, FR-020), serta (4) Catatan penahanan/pelepasan saldo (FR-019), lengkap dengan nomor pesanan/referensi, waktu transaksi, nominal (+/-), saldo akhir, serta filter jenis mutasi dan rentang tanggal.
  - Pengendalian & Mitigasi Gagal Bayar Saldo Tertunggak: Apabila toko memiliki Saldo Tertunggak (> Rp0), berlaku aturan berikut: (1) Pelunasan Otomatis & Mandiri ("Bayar Tunggakan"): Saldo tertunggak otomatis dipotong dari dana penjualan berikutnya yang cair ke Saldo Toko; selain itu, tersedia tombol "Bayar Tunggakan" di halaman Saldo Toko agar penjual dapat melunasi saldo tertunggak kapan saja secara mandiri melalui Payment Gateway (VA, QRIS, atau E-Wallet) dan tercatat di Riwayat Mutasi Saldo. (2) Batas Maksimum, Tenggat Waktu, & Pembekuan Otomatis (Auto-Suspend): Selama masih memiliki Saldo Tertunggak yang belum lunas, tombol penarikan dana (withdrawal) dinonaktifkan dan penutupan akun diblokir (FR-033). Sistem menetapkan batas maksimum saldo tertunggak sebesar Rp250.000 dan tenggat pelunasan maksimal 14 hari kalender sejak saldo tertunggak pertama kali tercatat, disertai notifikasi pengingat berjenjang (H-3 dan H-1 sebelum jatuh tempo melalui In-App serta WhatsApp/Email). Apabila total saldo tertunggak melebihi Rp250.000 atau belum dilunasi melewati 14 hari kalender, sistem otomatis melakukan pembekuan sementara toko (Auto-Suspend Toko: etalase disembunyikan dan pesanan baru diblokir, namun penjual tetap wajib menyelesaikan pesanan berjalan sesuai FR-018) serta menandainya pada panel pemantauan Admin (FR-019). Pembekuan otomatis langsung dicabut sesaat setelah tunggakan dilunasi 100%. (3) Pencegahan Penelantaran Akun (Blacklist Identitas): Apabila penjual menelantarkan toko yang terkena Auto-Suspend hingga melewati 30 hari kalender tanpa pelunasan, Admin dapat menandai NIK KTP dan Rekening Bank penjual pada daftar blokir (blacklist) penunggak (FR-018) sehingga yang bersangkutan tidak dapat membuka toko baru (FR-004) sebelum melunasi kewajibannya.
  - Tujuan penarikan dikunci ke Rekening Bank terverifikasi toko (FR-004); penjual dapat memperbarui rekening tujuan secara mandiri melalui mekanisme verifikasi pada FR-035.
  - Penjual mengajukan penarikan dengan batas minimum (contoh: Rp50.000) dan informasi biaya transfer antar-bank ditanggung penjual (dipotong otomatis).
  - Verifikasi Keamanan 2 Lapis: Sebelum permintaan transfer dikirim ke Payment Gateway, penjual wajib memasukkan 6 digit PIN Saldo (FR-033; jika belum diatur, penjual diarahkan membuat PIN terlebih dahulu) serta menyelesaikan verifikasi 6 digit kode OTP melalui API WhatsApp dengan saluran cadangan (fallback) SMS OTP atau Email OTP (mengikuti aturan FR-001).
  - Sesaat setelah lolos verifikasi PIN Saldo dan OTP, nominal langsung dikunci/dipotong sementara dari Saldo Toko tersedia agar tidak terjadi double withdrawal selama status "Pending".
  - Transfer diproses otomatis (real-time) via API Disbursement Payment Gateway tanpa persetujuan manual Admin; status (Pending, Berhasil, Gagal) diperbarui via webhook, dan apabila berstatus "Gagal", 100% nominal dikembalikan otomatis ke Saldo Toko beserta notifikasi alasan dan tercatat kembali di riwayat mutasi.

#### [FR-016] Pengaturan Profil, Hari/Jam Operasional, & Status Libur Toko
- **No**: 16
- **Kode FR**: `FR-016`
- **Kategori**: Fitur Tambahan Penjual
- **Modul Domain**: Seller - Store Profile, Operating Hours & Holiday Mode
- **Aktor Terkait**: `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-004`, `FR-014`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin memperbarui informasi profil toko serta mengatur status libur dan jadwal hari/jam operasional toko, sehingga informasi toko tetap akurat dan saya bisa mengontrol kapan pesanan masuk dan diproses.
- **Acceptance Criteria**:
  - Penjual dapat memperbarui informasi profil toko melalui halaman Pengaturan Toko meliputi Nama Toko (wajib tetap unik), Deskripsi Singkat Toko, dan Foto/Logo Toko.
  - Penjual dapat memperbarui alamat lengkap dan titik koordinat GPS (pin maps) toko dengan validasi otomatis wajib tetap berada di wilayah Sarbagita (mengacu ketentuan FR-004); perubahan lokasi toko hanya berlaku sebagai titik asal pengiriman untuk pesanan baru dan tidak mengubah pesanan yang sedang berjalan.
  - Terdapat tombol toggle "Libur/Tutup Toko" di beranda penjual. Jika diaktifkan, seluruh produk toko tidak dapat dibeli (tombol "Beli" dinonaktifkan/abu-abu).
  - Pengaktifan toggle "Libur/Tutup Toko" tidak menghentikan atau memperpanjang batas waktu (timer) pesanan yang sudah terlanjur masuk (berstatus "Dibayar" atau "Diproses"); penjual tetap wajib memproses, mengirim, atau menolak pesanan tersebut sesuai batas waktu pada FR-014 (sistem menampilkan pop-up pengingat jika masih ada pesanan aktif saat toggle diaktifkan).
  - Sistem memiliki pengaturan Hari Operasional mingguan (pilihan hari aktif Senin–Minggu, default Senin–Sabtu) dan Jam Operasional harian (contoh: 08:00–17:00). Hari yang tidak dipilih dihitung sebagai hari libur rutin mingguan toko.
  - Pesanan yang dilakukan pembeli di luar jam operasional atau pada hari libur rutin mingguan tetap bisa di-checkout, namun masuk ke antrean dengan label "Diproses pada hari operasional berikutnya" disertai pop-up persetujuan pembeli saat checkout.

### Kategori: Fitur Tambahan Admin

#### [FR-017] Live Chat Dukungan Pelanggan (Handover dari AI)
- **No**: 17
- **Kode FR**: `FR-017`
- **Kategori**: Fitur Tambahan Admin
- **Modul Domain**: Admin - Live Chat Support (AI Handover)
- **Aktor Terkait**: `Admin`
- **Referensi / Relasi FR**: Tidak ada
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai admin sistem, saya ingin memiliki antarmuka Live Chat, sehingga saya bisa melanjutkan percakapan pelanggan yang dialihkan oleh AI Customer Service.
- **Acceptance Criteria**:
  - Terdapat panel "Pesan Masuk" di dashboard Admin yang khusus menampilkan obrolan yang dialihkan oleh AI.
  - Admin dapat membaca riwayat percakapan sebelumnya antara AI dan pelanggan.
  - Admin dapat membalas pesan secara real-time serta menandai sesi obrolan sebagai "Selesai" setelah kendala tertangani.

#### [FR-018] Moderasi Akun Pengguna, Toko, Produk, Ulasan, & Tindak Lanjut Laporan Pelanggaran
- **No**: 18
- **Kode FR**: `FR-018`
- **Kategori**: Fitur Tambahan Admin
- **Modul Domain**: Admin - Platform Moderation & Abuse Reports
- **Aktor Terkait**: `Admin Operasional/KYC`, `Super Admin`
- **Referensi / Relasi FR**: `FR-004`, `FR-008`, `FR-010`, `FR-013`, `FR-015`, `FR-017`, `FR-019`, `FR-021`, `FR-025`, `FR-029`, `FR-030`, `FR-031`, `FR-040`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai Admin Operasional/KYC atau Super Admin, saya ingin memantau master data, meninjau laporan pelanggaran dari pengguna, memblokir akun/toko, menghapus produk, atau menyembunyikan/menghapus ulasan spam yang melanggar syarat dan ketentuan, sehingga ekosistem marketplace tetap aman.
- **Acceptance Criteria**:
  - Admin memiliki daftar master data seluruh Pengguna, Toko, dan Produk, serta antrean panel "Laporan Pelanggaran" yang menerima seluruh laporan produk, toko, maupun ulasan spam yang dikirim oleh pengguna (FR-040), lengkap dengan kategori pelanggaran, deskripsi, dan lampiran bukti.
  - Admin memiliki tombol aksi "Suspend Toko" (sementara/permanen), "Suspend Akun Pengguna", "Hapus Produk", "Hapus/Sembunyikan Ulasan" (untuk ulasan spam/melanggar pada FR-013), tombol "Blacklist Identitas Penunggak" (khusus toko dengan Saldo Tertunggak yang ditelantarkan melewati batas 30 hari pada FR-015/FR-019), serta tombol "Tolak Laporan" (khusus untuk laporan pada FR-040 yang tidak terbukti melanggar), yang masing-masing mewajibkan input alasan.
  - Jika Admin menekan "Hapus/Sembunyikan Ulasan", ulasan (beserta balasan terkait) disembunyikan dari halaman Detail Produk (FR-031), rata-rata rating produk dan toko otomatis dihitung ulang (FR-013), dan pemilik ulasan menerima notifikasi in-app berisi alasan moderasi.
  - Jika Toko di-suspend (baik manual oleh Admin maupun Auto-Suspend akibat Saldo Tertunggak melewati batas/tenggat pada FR-015), etalase toko disembunyikan dan toko tidak dapat menerima pesanan baru (namun tetap wajib menyelesaikan atau membatalkan pesanan yang sudah masuk sebelum di-suspend), serta pemilik akun masih dapat login untuk mengakses menu pelunasan tunggakan (FR-015) dan berbelanja sebagai Pembeli. Apabila Admin mengaktifkan "Blacklist Identitas Penunggak", NIK KTP dan Rekening Bank pemilik toko tercatat di daftar blokir sehingga tidak dapat mendaftar toko baru (FR-004) hingga seluruh tunggakan dilunasi.
  - Jika Akun Pengguna di-suspend, pengguna tidak dapat login ke aplikasi sama sekali (akses Pembeli dan Penjual tertutup), dengan kebijakan penanganan pesanan aktif dan dana escrow sebagai berikut: (1) Sebagai Penjual (jika memiliki toko): Etalase toko otomatis disembunyikan dan pesanan baru diblokir. Pesanan masuk berstatus "Menunggu Bayar", "Dibayar", maupun "Diproses" (termasuk "Mencari Driver" yang belum berstatus "Dikirim") otomatis dibatalkan oleh sistem dan 100% dana di-refund ke "Saldo Saya" pembeli (FR-021, FR-025). Pesanan yang sudah berstatus "Dikirim" atau "Terkirim" tetap berjalan mengikuti pelacakan kurir (FR-030) hingga dikonfirmasi pembeli, selesai otomatis 2x24 jam, atau diputuskan melalui panel Resolusi Konflik Admin (FR-010). Seluruh "Saldo Toko" serta dana escrow yang cair milik akun tersebut otomatis ditahan sementara (mengacu mekanisme FR-019) hingga investigasi selesai. (2) Sebagai Pembeli: Pesanan berstatus "Menunggu Bayar" otomatis dibatalkan dan stok dikembalikan. Pesanan yang sudah berstatus "Dibayar", "Diproses", atau "Dikirim" tetap diproses dan dikirimkan ke alamat tujuan hingga selesai otomatis 2x24 jam setelah berstatus "Terkirim" (FR-008); apabila terjadi kendala pengiriman, kebutuhan komplain, atau klaim "Saldo Saya", penanganan dilakukan secara manual oleh Admin CS / Super Admin melalui verifikasi identitas (FR-010, FR-017).
  - Setelah laporan pelanggaran (FR-040) ditindaklanjuti atau ditolak, sistem memperbarui status laporan menjadi "Selesai Ditinjau" dan mengirim notifikasi in-app kepada pelapor.
  - Seluruh tindakan moderasi, penetapan blacklist penunggak, dan keputusan laporan pelanggaran tercatat otomatis di Audit Log (FR-029).

#### [FR-019] Monitoring Penarikan, Saldo Tertunggak, & Penahanan Saldo Penjual
- **No**: 19
- **Kode FR**: `FR-019`
- **Kategori**: Fitur Tambahan Admin
- **Modul Domain**: Admin - Withdrawal Monitoring, Arrears & Balance Hold
- **Aktor Terkait**: `Penjual (Seller UMKM)`, `Admin`
- **Referensi / Relasi FR**: `FR-015`, `FR-018`, `FR-029`, `FR-041`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai admin sistem, saya ingin memantau semua penarikan dana, mengawasi daftar toko yang memiliki saldo tertunggak, dan dapat menahan saldo toko yang terindikasi bermasalah, sehingga dana tetap aman tanpa memperlambat penarikan penjual yang normal.
- **Acceptance Criteria**:
  - Terdapat tabel read-only "Riwayat Penarikan" berisi nama toko, bank, nomor rekening, nominal, biaya, status (Pending/Berhasil/Gagal), dan waktu, dilengkapi filter status, toko, dan tanggal.
  - Status penarikan hanya berubah melalui webhook Payment Gateway dan tidak dapat diubah manual oleh Admin.
  - Pemantauan Saldo Tertunggak Toko: Tersedia tab/tabel read-only "Daftar Saldo Tertunggak" di dashboard Super Admin yang menampilkan seluruh toko dengan saldo tertunggak aktif (> Rp0, mengacu FR-015), memuat nama toko, nominal tunggakan, tanggal mulai tunggakan, tanggal jatuh tempo 14 hari, serta status kepatuhan (Aktif, Jatuh Tempo, Auto-Suspend, atau Ditindaklanjuti Blacklist FR-018), dilengkapi filter status dan nominal untuk memudahkan penagihan dan mitigasi risiko gagal bayar.
  - Ringkasan agregat total penarikan dana, total saldo ditahan, dan total piutang Saldo Tertunggak toko otomatis tersinkronisasi sebagai komponen posisi keuangan dan rekonsiliasi pada Dashboard Keuangan Platform (FR-041).
  - Admin dapat menekan "Tahan Saldo" (sebagian atau seluruhnya) dengan alasan wajib; penjual menerima notifikasi berisi alasan, tanggal berakhir, dan cara mengajukan banding.
  - Penjual melihat nominal saldo yang ditahan, alasan, dan tanggal berakhirnya di halaman Saldo Toko (FR-015).
  - Durasi penahanan maksimal 14 hari dan dapat diperpanjang dengan alasan tertulis; setelah investigasi selesai, Admin memilih "Lepas Saldo" atau memperpanjang penahanan.
  - Seluruh aksi tahan, perpanjang, dan lepas saldo tercatat otomatis di Audit Log (FR-029).

### Kategori: Tambahan

#### [FR-020] Konfirmasi Penerimaan Pesanan, Mediasi Penjual, & Pengajuan Komplain
- **No**: 20
- **Kode FR**: `FR-020`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer & Seller - Order Confirmation, Mediation & Complaints
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-008`, `FR-009`, `FR-010`, `FR-012`, `FR-013`, `FR-015`, `FR-025`, `FR-032`, `FR-036`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin mengonfirmasi penerimaan pesanan atau mengajukan komplain yang dimediasi terlebih dahulu bersama penjual sebelum dieskalasi ke Admin, sehingga masalah pesanan dapat diselesaikan cepat dan adil.
- **Acceptance Criteria**:
  - Pada halaman Detail Pesanan (FR-032), ketersediaan tombol aksi mengikuti status: (1) Status "Dikirim": Tombol "Pesanan Diterima" aktif (antisipasi paket sampai sebelum kurir tersinkronisasi). Tombol "Ajukan Komplain" aktif dengan dua ketentuan kategori agar pembeli tidak terjebak menunggu pembaruan kurir: (a) Kategori "Barang Rusak / Salah Kirim / Jumlah Kurang" langsung aktif kapan saja selama status "Dikirim" (tanpa perlu menunggu status "Terkirim" maupun melewati ETD) apabila paket fisik sudah diterima pembeli dalam kondisi bermasalah; wajib mengisi alasan, mengunggah foto/video unboxing yang memperlihatkan resi/label pengiriman pada paket secara jelas, serta memilih usulan solusi (Refund Penuh atau Partial Refund dengan rincian nominal per item produk). (b) Kategori "Pesanan Belum Diterima / Pengiriman Terkendala" aktif hanya jika telah melewati estimasi tanggal tiba (ETD, FR-012); wajib mengisi alasan & tangkapan layar pelacakan, tanpa video unboxing. (2) Status "Terkirim": Tombol "Pesanan Diterima" dan "Ajukan Komplain" keduanya aktif selama 2x24 jam sebelum selesai otomatis (FR-008). Pembeli dapat memilih kategori "Barang Rusak / Salah Kirim / Jumlah Kurang" (wajib alasan, foto/video unboxing, serta pilihan usulan solusi Refund Penuh atau Partial Refund dengan rincian nominal per item produk) atau kategori "Pesanan Belum Diterima" (antisipasi kurir salah tandai terkirim; wajib alasan & tangkapan layar pelacakan tanpa video unboxing).
  - Menekan "Pesanan Diterima" mengubah status menjadi "Selesai", melepaskan dana escrow otomatis ke Saldo Toko penjual (dipotong komisi FR-009), dan membuka form ulasan (FR-013).
  - Tahap Mediasi Penjual (1x24 Jam): Menekan "Ajukan Komplain" mengubah status pesanan menjadi "Komplain (Mediasi Penjual)" sambil menahan dana di escrow. Penjual diberi waktu maksimal 1x24 jam untuk menanggapi dengan pilihan: (a) Menyetujui usulan Refund Penuh (status akhir menjadi "Batal (Dana Dikembalikan)", pembeli menerima 100% Harga Barang + Ongkir Pengiriman Awal + Biaya Asuransi Pengiriman (jika ada) + Biaya Layanan Pembeli ke "Saldo Bebas Biaya Tarik" FR-025; beban ongkir pengiriman awal dan premi asuransi yang sudah dibayarkan ke kurir dipotong dari Saldo Toko penjual atau dicatat sebagai saldo tertunggak yang tunduk pada batas maksimum, tenggat pelunasan 14 hari, dan pembekuan otomatis pada FR-015, dan pesanan tidak dapat diulas) atau menyetujui Partial Refund sesuai rincian nominal per item produk (dana escrow terbagi otomatis ke "Saldo Bebas Biaya Tarik" pembeli dan sisanya ke Saldo Toko penjual dengan potongan komisi proporsional per item sesuai rumus FR-009; ongkir awal, Biaya Asuransi Pengiriman, dan Biaya Layanan Pembeli tidak dikembalikan, status akhir menjadi "Selesai" dengan keterangan Partial Refund sehingga hak ulasan FR-013 tetap terbuka), atau (b) Menolak/mengajukan bukti bantahan.
  - Eskalasi Otomatis ke Admin: Apabila penjual menolak komplain, tidak tercapai kesepakatan, atau penjual tidak merespons melewati 1x24 jam, status otomatis berubah menjadi "Komplain (Dieskalasi ke Admin)" dan seluruh alasan, bukti pembeli, bukti bantahan penjual, serta riwayat chat (FR-036) diteruskan ke panel Resolusi Konflik Admin (FR-010).

#### [FR-021] Pembatalan Pesanan & Pengembalian Dana (Refund) Otomatis
- **No**: 21
- **Kode FR**: `FR-021`
- **Kategori**: Tambahan
- **Modul Domain**: Transaction - Order Cancellation & Automated Refunds
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-008`, `FR-009`, `FR-012`, `FR-014`, `FR-018`, `FR-025`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengguna (pembeli/penjual), saya ingin membatalkan atau mengajukan pembatalan pesanan dalam kondisi tertentu, dan sistem memastikan stok serta dana yang sudah dibayar dikembalikan (refund) secara otomatis.
- **Acceptance Criteria**:
  - Pembeli dapat membatalkan pesanan secara sepihak saat status masih "Menunggu Bayar" (stok terkunci dan potongan split payment "Saldo Saya" FR-008 langsung dikembalikan seketika tanpa potongan biaya apa pun dan tanpa menunggu kedaluwarsa 24 jam) maupun saat status sudah "Dibayar" selama penjual belum menekan "Proses Pesanan".
  - Pengajuan Pembatalan pada Status "Diproses": Selama pesanan berstatus "Diproses" (sebelum masuk sub-status "Mencari Driver" maupun status "Dikirim", mengacu FR-014), pembeli dapat menekan tombol "Ajukan Pembatalan" (wajib memilih/mengisi alasan, misalnya salah varian/alamat; dibatasi maksimal 1 kali pengajuan per pesanan) yang membutuhkan persetujuan penjual (FR-014). Apabila penjual menyetujui atau penjual tidak merespons hingga melewati batas waktu pengiriman (FR-014), pesanan langsung berstatus "Batal" dan dana di-refund; apabila penjual menolak (wajib alasan, misalnya paket sudah dikemas/siap dijemput), pesanan tetap dilanjutkan ke pengiriman.
  - Penjual dapat membatalkan pesanan masuk melalui tombol "Tolak Pesanan" (FR-014) jika stok habis atau tidak sanggup melayani.
  - Pembatalan otomatis oleh sistem dipicu jika penjual melewati batas waktu respon atau pengiriman sesuai kategori kurir (Reguler, Same-Day, maupun Instan), gagal menemukan driver instan/same-day pada FR-014, atau apabila Akun Pengguna penjual di-suspend oleh Admin pada pesanan yang belum berstatus "Dikirim" (mengacu FR-018).
  - Aturan Pengembalian Stok & Dana (Refund) saat Status "Batal": Stok produk selalu dikembalikan secara otomatis, sedangkan rincian pengembalian dana untuk pesanan yang sudah terverifikasi "Dibayar" (sebelum status "Dikirim") mengikuti pihak pemicu pembatalan (mengacu FR-009, FR-012, dan FR-025): (1) Pembatalan Mandiri oleh Pembeli (batal sepihak saat "Dibayar" atau pengajuan pembatalan saat "Diproses" yang disetujui penjual): 100% Harga Barang + Ongkir Awal + Biaya Asuransi Pengiriman (jika ada) dikembalikan otomatis ke "Saldo Reguler" pembeli, sedangkan Biaya Layanan Pembeli flat (FR-009) tidak dikembalikan (non-refundable) karena transaksi telah diproses Payment Gateway. (2) Pembatalan akibat Penjual atau Sistem ("Tolak Pesanan" oleh penjual, penjual melewati batas waktu respon/kirim, gagal menemukan driver instan/same-day, atau akun penjual di-suspend): 100% total dana pembayaran (Harga Barang + Ongkir Awal + Biaya Asuransi Pengiriman jika ada + Biaya Layanan Pembeli) dikembalikan otomatis ke "Saldo Bebas Biaya Tarik" milik pembeli (dapat dibelanjakan kembali atau ditarik melalui FR-025).

#### [FR-022] Notifikasi Pelacakan Status Pesanan & Komplain Pembeli
- **No**: 22
- **Kode FR**: `FR-022`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Order & Complaint Notifications
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-007`, `FR-010`, `FR-020`, `FR-021`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin menerima notifikasi terkait setiap perubahan status pesanan, permintaan pembatalan, maupun proses komplain/retur saya, sehingga saya bisa memantau seluruh proses transaksi tanpa harus selalu membuka aplikasi.
- **Acceptance Criteria**:
  - Sistem menyediakan Push Notification / Notifikasi In-App sebagai saluran utama untuk seluruh pembaruan pesanan dan komplain pembeli, serta integrasi API WhatsApp sebagai saluran prioritas terbatas khusus untuk peristiwa kritis (yang menyangkut dana atau tenggat tindakan) demi efisiensi biaya API dan konsistensi dengan FR-007.
  - Notifikasi dikirimkan secara otomatis kepada pembeli dengan pembagian saluran berikut: (1) "Pesanan sedang diproses oleh Penjual" (dikirim via In-App). (2) "Status Permintaan Pembatalan" (saat penjual menyetujui atau menolak pengajuan pembatalan pada status "Diproses", mengacu FR-021) (dikirim via In-App). (3) "Pesanan sedang Dikirim" (beserta nomor resi atau link pelacakan kurir instan) (dikirim via In-App). (4) "Pesanan Terkirim" (mengingatkan tenggat konfirmasi penerimaan/komplain 2×24 jam) (dikirim via In-App dan WhatsApp). (5) "Pesanan Dibatalkan" (beserta informasi dana refund telah masuk ke "Saldo Saya") (dikirim via In-App dan WhatsApp). (6) "Pembaruan Mediasi & Keputusan Komplain": tanggapan mediasi penjual dan eskalasi otomatis ke Admin (FR-020) dikirim via In-App; keputusan akhir resolusi konflik oleh Admin (FR-010) dikirim via In-App dan WhatsApp. (7) "Instruksi & Pengingat Retur Barang": pemicuan status "Menunggu Pengembalian Barang" beserta pengingat tenggat input resi retur 3×24 jam dikirim via In-App dan WhatsApp; pembaruan konfirmasi penerimaan atau bantahan retur oleh penjual (FR-010) dikirim via In-App.

#### [FR-023] Manajemen Keranjang Belanja, Beli Langsung (Direct Checkout), & Single-Seller Checkout
- **No**: 23
- **Kode FR**: `FR-023`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Shopping Cart, Direct Checkout & Single-Seller Scope
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-005`, `FR-008`, `FR-012`, `FR-016`, `FR-018`, `FR-031`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin menyimpan berbagai produk fisik dari beberapa toko ke dalam keranjang belanja lalu memilih produk dari satu toko untuk di-checkout, maupun membeli langsung satu produk fisik tanpa masuk keranjang, sehingga proses belanja lebih cepat dan fleksibel.
- **Acceptance Criteria**:
  - Terdapat tombol "Masukkan Keranjang" dan "Beli" pada setiap halaman Detail Produk fisik (FR-031) yang aktif dan memiliki stok tersedia.
  - Alur Tombol "Beli" (Direct Checkout Produk Fisik): Menekan tombol "Beli" pada halaman Detail Produk (setelah memilih varian dan kuantitas) langsung mengarahkan pembeli ke halaman Checkout (FR-008) hanya untuk item tersebut tanpa menambahkan, mencampur, atau menghapus daftar item lain yang tersimpan di Keranjang Belanja (tetap mematuhi aturan single-seller checkout dan validasi anti-beli-produk-sendiri).
  - Pembeli dapat memasukkan banyak produk fisik dari berbagai toko berbeda ke dalam satu keranjang belanja; di halaman Keranjang, daftar item ditampilkan dikelompokkan berdasarkan masing-masing toko beserta harga efektif setelah diskon produk (jika aktif, FR-005).
  - Pada setiap item di keranjang, pembeli dapat mengubah kuantitas, menghapus item, serta mengisi kolom opsional "Catatan untuk Penjual".
  - Sistem menerapkan batasan ruang lingkup (scope) single-seller checkout: pembeli dapat mencentang (checkbox) sebagian atau seluruh item yang ingin dibeli, namun hanya dari satu toko yang sama dalam satu transaksi pembayaran. Apabila memilih item dari toko lain, sistem otomatis mengalihkan pilihan ke toko baru tersebut (atau memblokir lintas toko dengan notifikasi singkat), dan item dari toko lain tetap tersimpan di keranjang setelah checkout dilakukan.
  - Saat pembeli memilih lebih dari satu item produk atau kuantitas lebih dari 1 dari toko yang sama untuk di-checkout, sistem meneruskan seluruh rincian berat aktual, dimensi (P x L x T), dan kuantitas setiap item terpilih secara otomatis untuk diagregasi dalam kalkulasi ongkos kirim pada FR-012.
  - Sistem memvalidasi agar pengguna tidak dapat memasukkan produk dari tokonya sendiri ke keranjang belanja maupun membelinya lewat tombol "Beli" (mencegah manipulasi transaksi/rating palsu).
  - Saat Keranjang dibuka, saat menekan "Checkout", maupun saat menekan tombol "Beli", sistem memvalidasi ulang secara real-time ketersediaan stok, status aktif produk & harga diskon terbaru (FR-005), status "Libur" toko (FR-016), dan status "Suspend" toko (FR-018); item yang tidak tersedia atau dari toko libur/di-suspend ditandai dan proses checkout diblokir hingga diperbarui.

#### [FR-024] Manajemen Buku Alamat Pengiriman Pembeli
- **No**: 24
- **Kode FR**: `FR-024`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Address Book Management
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-011`, `FR-012`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin mengelola daftar alamat pengiriman beserta identitas penerima di profil saya, sehingga penentuan ongkos kirim, pengiriman paket, dan pencarian toko terdekat berjalan akurat.
- **Acceptance Criteria**:
  - Terdapat menu "Daftar Alamat" pada halaman Pengaturan Profil Pengguna.
  - Pembeli dapat menambah, mengedit, dan menghapus daftar alamat pengiriman dengan melengkapi kolom wajib: Nama Penerima, Nomor HP Penerima, detail alamat lengkap, dan titik koordinat GPS (pin maps), serta kolom opsional: Label Alamat (Rumah/Kantor/Kos) dan Catatan Kurir/Patokan.
  - Sistem memvalidasi otomatis bahwa wilayah dan titik koordinat GPS alamat berada khusus di wilayah Sarbagita (Kota Denpasar, Kab. Badung, Kab. Gianyar, atau Kab. Tabanan, Provinsi Bali), dan menolak penyimpanan beserta notifikasi apabila di luar ketentuan.
  - Pembeli dapat menentukan satu alamat sebagai "Alamat Utama" sebagai titik acuan jika GPS ditolak (FR-011) dan alamat default saat checkout (FR-012).

#### [FR-025] Manajemen & Penarikan Saldo Refund Pembeli
- **No**: 25
- **Kode FR**: `FR-025`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Refund Wallet (Saldo Saya) & Withdrawal
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-001`, `FR-002`, `FR-008`, `FR-010`, `FR-020`, `FR-021`, `FR-033`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin melihat jumlah saldo refund (penuh maupun partial refund), menggunakannya kembali untuk berbelanja, dan menariknya ke rekening bank pribadi secara aman dan otomatis dengan validasi nama rekening tujuan, PIN Saldo, OTP multi-saluran, dan aturan potongan biaya yang jelas.
- **Acceptance Criteria**:
  - Pembeli memiliki halaman "Saldo Saya" yang menampilkan riwayat dana masuk (dari refund penuh FR-021/FR-002 maupun partial refund FR-010/FR-020) dan dana keluar (pembayaran pesanan atau penarikan ke rekening bank).
  - Pemisahan Jenis Saldo untuk Saldo Campuran: Sistem mencatat total "Saldo Saya" dalam dua komponen terpisah secara transparan: (1) "Saldo Bebas Biaya Tarik" (berasal dari refund gagal PPOB FR-002, pembatalan/penolakan akibat kelalaian penjual atau sistem FR-021, serta komplain Full/Partial Refund maupun penggantian ongkir retur akibat kesalahan penjual atau kesalahan kurir pada FR-010/FR-020), dan (2) "Saldo Reguler" (berasal dari pembatalan mandiri oleh pembeli setelah status "Dibayar" pada FR-021 atau keputusan refund komplain yang bukan kesalahan penjual/kurir pada FR-010).
  - Saldo pada "Saldo Saya" dapat langsung digunakan kembali sebagai metode pembayaran di halaman checkout (FR-008) untuk produk fisik maupun PPOB tanpa batas minimum dan tanpa biaya admin (Rp0) dengan verifikasi 6 digit PIN Saldo (FR-033); apabila pengguna memiliki saldo campuran saat berbelanja, sistem memotong "Saldo Reguler" terlebih dahulu baru kemudian "Saldo Bebas Biaya Tarik" agar hak penarikan gratis pembeli tetap terjaga.
  - Validasi Nama Pemilik Rekening Tujuan (Bank Account Inquiry API): Saat mengajukan penarikan dana ke rekening bank, pembeli memilih nama bank dan menginput nomor rekening tujuan; sistem wajib memanggil Bank Account Inquiry API Payment Gateway secara real-time untuk mengecek keabsahan rekening dan menampilkan Nama Pemilik Rekening tujuan pada layar ringkasan penarikan. Jika nomor rekening tidak valid atau tidak ditemukan, proses penarikan ditolak dengan pesan error spesifik sebelum tahap verifikasi; pembeli wajib memeriksa dan mencentang konfirmasi kesesuaian nama pemilik rekening guna mencegah kesalahan transfer.
  - Aturan Penarikan Saldo Campuran: Jika nominal yang ditarik tidak melebihi jumlah "Saldo Bebas Biaya Tarik" yang tersedia, penarikan dibebaskan dari batas minimum dan biaya admin transfer antar-bank ditanggung penuh oleh platform (Rp0) - nominal langsung dipotong dari sub-bucket tersebut. Apabila nominal penarikan melebihi "Saldo Bebas Biaya Tarik" (sehingga turut menggunakan "Saldo Reguler"), maka berlaku ketentuan penarikan reguler (batas minimum penarikan misal Rp20.000 dan biaya admin transfer antar-bank ditanggung pembeli); halaman penarikan menampilkan rincian kedua saldo, nama pemilik rekening hasil inquiry, dan estimasi potongan biaya secara jelas sebelum konfirmasi keamanan.
  - Verifikasi Keamanan 2 Lapis: Sebelum permintaan transfer diproses, pembeli wajib memasukkan 6 digit PIN Saldo (FR-033; jika belum diatur, pembeli diarahkan membuat PIN terlebih dahulu) serta menyelesaikan verifikasi ulang 6 digit kode OTP melalui API WhatsApp dengan saluran cadangan (fallback) SMS OTP atau Email OTP (mengikuti aturan FR-001).
  - Sesaat setelah lolos verifikasi PIN Saldo dan OTP, nominal langsung dikunci/dipotong sementara dari "Saldo Saya" agar tidak terjadi double withdrawal selama berstatus "Pending".
  - Transfer diproses otomatis (real-time) via API Disbursement Payment Gateway tanpa persetujuan manual Admin; status (Pending, Berhasil, Gagal) diperbarui via webhook, dan jika "Gagal", 100% nominal dikembalikan otomatis ke sub-bucket saldo asalnya beserta notifikasi alasan.

#### [FR-026] Pencarian Lanjutan, Filter, & Pengurutan Produk
- **No**: 26
- **Kode FR**: `FR-026`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Advanced Search, Filtering & Sorting
- **Aktor Terkait**: `Pengunjung (Guest)`, `Pembeli`
- **Referensi / Relasi FR**: `FR-004`, `FR-005`, `FR-011`, `FR-013`, `FR-016`, `FR-031`, `FR-034`, `FR-037`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengunjung/pembeli, saya ingin mencari produk berdasarkan kata kunci, menyaring berdasarkan kategori/sub-kategori, lokasi kabupaten/kota Sarbagita, rentang harga, status diskon, layanan pengiriman, dan rating, serta mengurutkan hasil sesuai preferensi saya, sehingga barang spesifik cepat ditemukan.
- **Acceptance Criteria**:
  - Terdapat search bar di halaman utama (dapat diakses dalam Guest Mode maupun setelah login) untuk mencari produk atau toko berdasarkan kata kunci.
  - Pengguna dapat menyaring hasil menggunakan filter: (1) Kategori Utama & Sub-Kategori (FR-034). (2) Lokasi Toko / Wilayah Kabupaten-Kota (pilihan multi-select cakupan Sarbagita: Kota Denpasar, Kab. Badung, Kab. Gianyar, dan Kab. Tabanan — mengacu data lokasi toko pada FR-004/FR-016). (3) Rentang Harga (Harga Minimum – Harga Maksimum, mengacu pada harga jual efektif setelah diskon produk apabila sedang diskon, FR-005). (4) Layanan Pengiriman (Instan, Same-Day, atau Reguler Lokal, mengacu kurir aktif toko pada FR-037). (5) Rating Produk (contoh: 4+ bintang ke atas, mengacu rata-rata ulasan pada FR-013). (6) Sedang Diskon (opsi filter toggle untuk menampilkan khusus produk dengan diskon harga coret aktif, FR-005).
  - Pengguna dapat mengurutkan hasil pencarian berdasarkan: Terdekat (default jika GPS/Alamat Utama aktif mengacu FR-011), Relevansi, Terbaru (selaras dengan FR-031), Terlaris, Rating Tertinggi, Harga Terendah, dan Harga Tertinggi (berdasarkan harga jual efektif setelah diskon).

#### [FR-027] Tinjauan & Persetujuan Verifikasi Toko Baru (Admin)
- **No**: 27
- **Kode FR**: `FR-027`
- **Kategori**: Tambahan
- **Modul Domain**: Admin - New Store KYC Approval
- **Aktor Terkait**: `Admin`
- **Referensi / Relasi FR**: `FR-004`, `FR-029`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai admin sistem, saya ingin meninjau dan menyetujui dokumen identitas (KTP) serta data lokasi pendaftaran toko baru, sehingga saya dapat mencegah masuknya toko fiktif ke dalam platform.
- **Acceptance Criteria**:
  - Terdapat halaman "Persetujuan Toko Baru" di dashboard Admin yang berisi daftar pengajuan KYC (FR-004).
  - Admin dapat melihat detail data yang diajukan: Nama & Deskripsi Toko, Foto/Logo Toko, Foto KTP, Foto Selfie KTP, Nama & Nomor Rekening Bank, serta Titik Lokasi GPS.
  - Admin memiliki tombol aksi "Setujui" atau "Tolak" (beserta kolom input alasan penolakan).
  - Jika disetujui, sistem mengirim notifikasi WhatsApp bahwa toko aktif; jika ditolak, penjual menerima pesan beserta alasan untuk memperbaiki data, dan aksi tercatat di Audit Log (FR-029).

#### [FR-028] Autentikasi, RBAC Admin, & Logout Admin
- **No**: 28
- **Kode FR**: `FR-028`
- **Kategori**: Tambahan
- **Modul Domain**: Admin - Authentication, RBAC & Session Management
- **Aktor Terkait**: `Admin`
- **Referensi / Relasi FR**: `FR-009`, `FR-010`, `FR-017`, `FR-018`, `FR-019`, `FR-027`, `FR-029`, `FR-034`, `FR-035`, `FR-040`, `FR-041`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengelola platform, saya ingin login ke panel admin dengan autentikasi kuat dan pembagian hak akses berbasis peran (RBAC), sehingga setiap admin hanya mengakses modul sesuai tanggung jawabnya.
- **Acceptance Criteria**:
  - Sistem menerapkan 3 peran Admin (Role-Based Access Control / RBAC): (1) Admin CS (akses Live Chat FR-017 & Resolusi Konflik/Sengketa Retur FR-010), (2) Admin Operasional/KYC (akses Verifikasi Toko FR-027, Moderasi & Tindak Lanjut Laporan Pelanggaran FR-018/FR-040, serta Manajemen Kategori & Banner Beranda FR-034), dan (3) Super Admin (akses penuh termasuk Keuangan FR-009, FR-019, FR-035, Dashboard Keuangan & Rekonsiliasi Platform FR-041, serta Audit Log FR-029).
  - Tidak ada pendaftaran mandiri; pembuatan, penetapan peran, penonaktifan akun Admin, serta reset perangkat 2FA yang hilang dilakukan melalui seeding atau backend oleh pengembang di luar aplikasi.
  - Login memakai email + password dan wajib 2FA, dilengkapi idle timeout sesi selama 30 menit.
  - Tersedia tombol "Logout" untuk mengakhiri sesi admin secara aman.

#### [FR-029] Audit Log Aksi Admin
- **No**: 29
- **Kode FR**: `FR-029`
- **Kategori**: Tambahan
- **Modul Domain**: Admin - Immutable Audit Log
- **Aktor Terkait**: `Super Admin`
- **Referensi / Relasi FR**: `FR-009`, `FR-010`, `FR-018`, `FR-019`, `FR-027`, `FR-028`, `FR-035`, `FR-040`, `FR-041`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai Super Admin, saya ingin semua aksi sensitif dari seluruh peran admin tercatat permanen, sehingga setiap keputusan menyangkut dana dan akun dapat ditelusuri.
- **Acceptance Criteria**:
  - Dicatat: identitas & peran admin (siapa), waktu (kapan), aksi, alasan wajib, dan nilai sebelum/sesudah.
  - Cakupan: keputusan resolusi konflik termasuk partial refund & sengketa retur (FR-010), setuju/tolak toko (FR-027), suspend/hapus produk/hapus-sembunyikan ulasan/penetapan blacklist penunggak & tindak lanjut/penolakan laporan pelanggaran (FR-018/FR-040), ubah skema biaya/komisi (FR-009), tahan/lepas saldo (FR-019), verifikasi manual/ubah rekening penjual (FR-035), serta aktivitas ekspor laporan keuangan dan rekonsiliasi platform (FR-041).
  - Alasan wajib diisi untuk keputusan yang menyangkut dana, akun, ulasan, dan toko.
  - Hanya Super Admin (FR-028) yang dapat melihat seluruh Audit Log; log bersifat immutable (tidak dapat diedit maupun dihapus lewat aplikasi).

#### [FR-030] Sinkronisasi Status & Pelacakan Pengiriman
- **No**: 30
- **Kode FR**: `FR-030`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer & Logistics - Shipment Tracking & Status Sync
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-010`, `FR-014`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin melacak posisi dan pembaruan status pengiriman pesanan saya secara langsung di aplikasi, sehingga saya dapat memantau proses pengiriman hingga barang tiba.
- **Acceptance Criteria**:
  - Setelah status "Dikirim" (FR-014), sistem menerima pembaruan dari API logistik lewat webhook, dengan polling berkala sebagai cadangan.
  - Status kurir dipetakan menjadi Dalam Perjalanan, Terkirim, Gagal Kirim, atau Dikembalikan.
  - Detail Pesanan menampilkan nama kurir, nomor resi, dan timeline pelacakan (khusus kurir instan ditambah nama driver dan tautan pelacakan).
  - Jika pembaruan dari kurir gagal diambil, status terakhir tetap tampil beserta waktu pembaruan terakhirnya.
  - Jika pengiriman berakhir berstatus "Gagal Kirim" atau "Dikembalikan" (retur ke penjual), dana escrow tetap ditahan dan transaksi otomatis diteruskan ke panel Resolusi Konflik Admin (FR-010) untuk verifikasi pengembalian dana.

#### [FR-031] Eksplorasi Beranda (Guest Mode), Detail Produk, & Halaman Toko Publik (Etalase Toko)
- **No**: 31
- **Kode FR**: `FR-031`
- **Kategori**: Tambahan
- **Modul Domain**: Public & Buyer - Homepage, Product Detail & Storefront
- **Aktor Terkait**: `Pengunjung (Guest)`, `Pembeli`
- **Referensi / Relasi FR**: `FR-001`, `FR-005`, `FR-013`, `FR-016`, `FR-023`, `FR-026`, `FR-034`, `FR-036`, `FR-037`, `FR-039`, `FR-040`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengunjung/pembeli, saya ingin melihat banner informasi, navigasi kategori, dan katalog produk di beranda, membuka detail produk, menjelajahi etalase toko, mencari dan menyaring produk serta melihat reputasi di dalam halaman toko, maupun melaporkan pelanggaran tanpa harus login terlebih dahulu untuk eksplorasi, sehingga saya dapat meninjau produk secara aman sebelum membeli.
- **Acceptance Criteria**:
  - Beranda Utama dapat diakses secara publik (Guest Mode) tanpa login dan menampilkan: (1) Banner Promosi/Informasi UMKM (karusel/slider yang dikelola Admin pada FR-034). (2) Deretan Navigasi/Ikon Kategori Utama (tersinkronisasi dengan FR-034; mengklik salah satu kategori langsung mengarahkan pengunjung ke hasil katalog tersaring sesuai kategori tersebut pada FR-026). (3) Katalog/feed produk aktif dari berbagai toko UMKM (termasuk tampilan harga coret dan lencana persentase diskon apabila produk sedang diskon, FR-005).
  - Mengklik produk membuka halaman Detail Produk yang menampilkan galeri foto, nama produk, Harga Normal (dicoret jika sedang diskon), harga setelah diskon, dan lencana persentase diskon (FR-005), deskripsi, berat & dimensi produk, sisa stok, pilihan varian (hingga 2 tingkat, FR-005), rata-rata rating beserta ulasan, balasan penjual, dan tombol "Laporkan Ulasan" pada tiap ulasan (FR-013, FR-040), opsi layanan kurir yang didukung toko (FR-037), info toko beserta status buka/liburnya (FR-016), tombol "Masukkan Keranjang" dan "Beli" (Direct Checkout, FR-023), tombol "Wishlist/Favorit" (FR-039), tombol "Chat Penjual" (FR-036), serta tombol "Laporkan Produk" (FR-040).
  - Mengklik nama/logo toko membuka Halaman Toko Publik yang menampilkan profil toko, lokasi, jam operasional, ringkasan reputasi toko (rata-rata rating keseluruhan toko, total ulasan, dan total produk terjual), tombol "Chat Penjual" (FR-036), tombol "Ikuti Toko" (FR-039), tombol "Laporkan Toko" (FR-040), navigasi/tab Etalase Toko kustom buatan penjual (FR-005) di samping tab "Semua Produk", kolom pencarian internal toko, filter Kategori/Sub-Kategori/harga, serta pengurutan produk (Terbaru, Terlaris, Rating Tertinggi, Harga Terendah, dan Harga Tertinggi — selaras dengan opsi pengurutan pada FR-026) atas seluruh daftar produk aktif milik toko tersebut.
  - Menekan "Masukkan Keranjang", "Beli", "Chat Penjual", "Wishlist/Favorit", "Ikuti Toko", atau "Laporkan Produk/Toko/Ulasan" saat belum login akan mengarahkan pengunjung ke halaman autentikasi (FR-001).

#### [FR-032] Daftar & Riwayat Pesanan Pembeli
- **No**: 32
- **Kode FR**: `FR-032`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Order List & Transaction History
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-002`, `FR-012`, `FR-014`, `FR-020`, `FR-021`, `FR-030`, `FR-036`, `FR-038`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin melihat seluruh daftar pesanan saya yang dikelompokkan berdasarkan status transaksi, sehingga saya dapat memantau pesanan aktif maupun riwayat belanja dengan mudah.
- **Acceptance Criteria**:
  - Terdapat menu "Pesanan Saya" yang memuat daftar transaksi produk fisik dan produk digital PPOB (FR-002).
  - Pesanan dikelompokkan dalam tab status: Menunggu Bayar, Dibayar, Diproses (termasuk sub-status "Menunggu Persetujuan Pembatalan" mengacu FR-021 dan sub-status "Mencari Driver" untuk kurir Instan/Same-Day mengacu FR-014), Dikirim (termasuk sub-status "Terkirim" yang menunggu konfirmasi 2x24 jam), Selesai (termasuk pesanan berstatus "Selesai Partial Refund"), Komplain (termasuk sub-status "Mediasi Penjual", "Dieskalasi ke Admin", "Menunggu Pengembalian Barang", dan "Sengketa Retur"), dan Batal.
  - Mengklik salah satu item pesanan membuka halaman Detail Pesanan (rincian barang/token PPOB, rincian biaya termasuk harga normal, potongan diskon produk jika ada, ongkir, Biaya Asuransi Pengiriman jika aktif (FR-012), dan Biaya Layanan Pembeli, tombol aksi FR-020 & FR-021, pelacakan FR-030, tombol "Chat Penjual" pada produk fisik mengacu FR-036, serta tombol "Unduh/Cetak Invoice" mengacu FR-038).

#### [FR-033] Manajemen Profil Pengguna, Keamanan Akun (PIN Saldo & Password), Penutupan Akun, & Logout
- **No**: 33
- **Kode FR**: `FR-033`
- **Kategori**: Tambahan
- **Modul Domain**: User Account - Profile, PIN Saldo, Security & Account Closure
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-001`, `FR-008`, `FR-010`, `FR-015`, `FR-017`, `FR-019`, `FR-025`, `FR-035`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengguna terdaftar, saya ingin mengubah informasi profil dasar, mengatur PIN Saldo dan password akun, memperbarui nomor HP/WhatsApp dengan verifikasi akun lama yang aman, mengajukan penghapusan/penutupan akun, serta keluar (logout) dari akun saya, sehingga data dan saldo akun tetap akurat, aman, dan sesuai privasi.
- **Acceptance Criteria**:
  - Pengguna dapat memperbarui Nama Tampilan dan Foto Profil melalui halaman Pengaturan Profil.
  - Pengaturan PIN Saldo (6 Digit): Tersedia menu "PIN Saldo" pada Pengaturan Keamanan Akun bagi seluruh pengguna (pembeli/penjual) untuk membuat, mengubah (wajib memasukkan PIN lama), maupun mengatur ulang (Lupa PIN Saldo melalui verifikasi 6 digit OTP multi-saluran FR-001 atau re-autentikasi Google) kode PIN numerik 6 digit yang digunakan pada pembayaran saldo (FR-008), penarikan dana (FR-015, FR-025), dan perubahan rekening (FR-035). PIN Saldo disimpan dalam bentuk terenkripsi (hashed); apabila salah memasukkan PIN sebanyak 5 kali berturut-turut, fitur transaksi saldo dan penarikan diblokir sementara selama 15 menit (atau hingga pengguna melakukan reset PIN).
  - Pengaturan Email, Password, & Penautan Akun Google: Pengguna yang mendaftar menggunakan Nomor HP/WhatsApp dapat melengkapi serta memverifikasi alamat email, membuat atau mengubah password akun (agar dapat login melalui jalur Email & Password pada FR-001), maupun menautkan akun Google melalui halaman Pengaturan Profil agar dapat login melalui "Login with Google" (FR-001).
  - Perubahan Nomor HP/WhatsApp dengan Verifikasi Berlapis (Anti-Pembajakan Akun): Sebelum pengguna dapat memasukkan nomor baru, sistem wajib memverifikasi kepemilikan akun lama terlebih dahulu melalui 6 digit OTP ke nomor lama (WhatsApp dengan fallback SMS), Email OTP (jika email terverifikasi), ATAU re-autentikasi akun Google yang tertaut (apabila seluruh saluran lama tidak dapat diakses, pengguna diarahkan menghubungi Admin CS FR-017 untuk verifikasi identitas manual). Setelah verifikasi akun lama lolos, sistem mewajibkan verifikasi 6 digit OTP ke nomor baru (WhatsApp dengan fallback SMS, mengikuti ketentuan FR-001) sebelum perubahan disimpan, disertai notifikasi keamanan ke saluran lama (In-App dan WhatsApp/Email).
  - Penghapusan / Penutupan Akun Pengguna: Tersedia menu "Hapus / Tutup Akun" pada Pengaturan Profil. Sistem memvalidasi kelayakan penutupan akun: tidak ada pesanan aktif maupun komplain/retur berjalan, "Saldo Saya" (FR-025) dan "Saldo Toko" (FR-015) bernilai Rp0 (tanpa penarikan "Pending", saldo ditahan FR-019, maupun saldo tertunggak FR-010), serta akun tidak sedang di-suspend. Penutupan akun wajib dikonfirmasi melalui OTP multi-saluran (WhatsApp/SMS/Email sesuai FR-001) atau re-autentikasi Google. Setelah dikonfirmasi, sesi dicabut permanen, toko (jika ada) dinonaktifkan, dan data pribadi pengguna dianonimkan, sementara arsip transaksi dan log finansial tetap disimpan secara anonim untuk integritas pembukuan dan kepatuhan regulasi.
  - Terdapat tombol "Keluar (Logout)" untuk menghapus sesi login aktif dan mengarahkan pengguna kembali ke halaman login (FR-001).

#### [FR-034] Manajemen Kategori, Sub-Kategori Produk, & Banner Beranda (Admin)
- **No**: 34
- **Kode FR**: `FR-034`
- **Kategori**: Tambahan
- **Modul Domain**: Admin - Category Hierarchy & Homepage Banners
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`, `Admin`
- **Referensi / Relasi FR**: `FR-005`, `FR-009`, `FR-026`, `FR-028`, `FR-031`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai admin sistem, saya ingin mengelola daftar kategori utama, sub-kategori produk UMKM, serta banner promosi/informasi beranda, sehingga pengelompokan produk di etalase penjual, navigasi beranda, dan pencarian pembeli tetap rapi, terstruktur, dan konsisten.
- **Acceptance Criteria**:
  - Terdapat menu "Manajemen Kategori" dan "Manajemen Banner Beranda" di dashboard Admin (Admin Operasional/KYC & Super Admin, FR-028).
  - Sistem mendukung struktur kategori 2 tingkat, yaitu Kategori Utama dan Sub-Kategori di bawahnya (contoh: Kuliner : Makanan Ringan, Minuman Tradisional; Fesyen : Endek/Kebaya, Aksesoris).
  - Admin dapat menambah, mengubah nama/ikon, serta menonaktifkan atau menghapus Kategori Utama maupun Sub-Kategori yang tidak sedang digunakan oleh produk aktif (apabila masih digunakan produk aktif, penghapusan ditolak hingga produk dipindahkan).
  - Penambahan Kategori Utama baru otomatis mewarisi tarif komisi default global (FR-009), dan seluruh Sub-Kategori otomatis mewarisi tarif komisi Kategori Utama induknya.
  - Daftar Kategori Utama dan Sub-Kategori aktif otomatis tersinkronisasi ke form tambah/edit produk penjual (FR-005), navigasi kategori Beranda Utama (FR-031), dan filter pencarian pembeli (FR-026).
  - Manajemen Banner Beranda: Admin dapat menambah, mengedit, mengatur urutan tampil, mengaktifkan/menonaktifkan, serta menghapus banner promosi/informasi (maksimal 5 banner aktif; format gambar JPG/PNG beserta tautan tujuan opsional ke kategori atau halaman produk/toko) yang langsung tampil pada karusel Beranda Utama (FR-031).

#### [FR-035] Perubahan Rekening Bank Penjual (Mandiri / Self-Service)
- **No**: 35
- **Kode FR**: `FR-035`
- **Kategori**: Tambahan
- **Modul Domain**: Seller - Self-Service Bank Account Change
- **Aktor Terkait**: `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-001`, `FR-004`, `FR-015`, `FR-016`, `FR-019`, `FR-028`, `FR-029`, `FR-033`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin mengubah rekening bank pencairan toko secara mandiri dengan verifikasi keamanan otomatis menggunakan PIN Saldo dan OTP multi-saluran, sehingga saya tidak perlu bergantung pada proses manual Admin saat mengganti rekening.
- **Acceptance Criteria**:
  - Terdapat menu "Ubah Rekening Bank" pada halaman Saldo Toko (FR-015) atau Pengaturan Toko (FR-016) yang dapat diakses langsung oleh penjual.
  - Sistem memblokir perubahan rekening apabila masih terdapat pengajuan penarikan dana berstatus "Pending" (FR-015) atau saldo toko sedang ditahan (FR-019) guna mencegah konflik pencairan dana.
  - Penjual memilih nama bank dan menginput nomor rekening baru; sistem melakukan validasi nama pemilik rekening secara otomatis melalui Bank Account Inquiry API Payment Gateway untuk memastikan nama pemilik rekening baru sesuai dengan nama pada data KTP KYC (FR-004).
  - Apabila validasi nama otomatis cocok, penjual wajib memasukkan 6 digit PIN Saldo (FR-033) dan menyelesaikan verifikasi 6 digit kode OTP melalui API WhatsApp dengan saluran cadangan (fallback) SMS OTP atau Email OTP (mengikuti ketentuan FR-001); setelah verifikasi berhasil, rekening tujuan pencairan langsung diperbarui otomatis dan sistem mengirim notifikasi konfirmasi perubahan rekening melalui In-App serta WhatsApp/Email.
  - Fallback Verifikasi Manual (Super Admin): Apabila validasi nama otomatis gagal karena perbedaan penulisan wajar (misalnya nama pemilik disingkat oleh bank), penjual dapat mengajukan permohonan peninjauan manual dengan melampirkan bukti buku tabungan/e-statement; Super Admin (FR-028) meninjau dan menyetujui/menolak permohonan tersebut dengan input alasan wajib yang tercatat otomatis di Audit Log (FR-029).

#### [FR-036] Fitur Chat (Komunikasi Langsung) Pembeli & Penjual
- **No**: 36
- **Kode FR**: `FR-036`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer & Seller - Direct In-App Chat
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-008`, `FR-010`, `FR-014`, `FR-031`, `FR-032`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengguna (pembeli/penjual), saya ingin berkomunikasi secara langsung melalui fitur obrolan (chat) di dalam aplikasi terkait pertanyaan produk maupun pesanan, sehingga informasi dapat dikonfirmasi cepat dan riwayat komunikasi tersimpan aman di platform.
- **Acceptance Criteria**:
  - Pembeli dapat memulai percakapan melalui tombol "Chat Penjual" pada Detail Produk (FR-031), Halaman Toko Publik (FR-031), dan Detail Pesanan (FR-032); sistem memvalidasi agar pengguna tidak dapat mengirim pesan ke tokonya sendiri.
  - Penjual dapat melihat daftar pesan masuk dan membalas percakapan pembeli melalui menu "Chat Pembeli" di Dashboard Toko maupun tombol pintas pada halaman Daftar/Detail Pesanan (FR-014).
  - Pengguna dapat mengirim pesan teks, melampirkan kartu referensi produk atau nomor pesanan terkait, serta mengunggah gambar pendukung (format JPG/PNG, maksimal 5 MB per gambar; tanpa fitur voice/video call).
  - Pesan dikirim dan diterima secara real-time lengkap dengan timestamp, indikator pesan belum dibaca (unread badge), dan notifikasi pesan baru (Push Notification/in-app).
  - Riwayat percakapan tersimpan permanen (tidak dapat dihapus sepihak) sehingga dapat ditinjau Admin sebagai bukti pendukung pada panel Resolusi Konflik (FR-010).
  - Halaman obrolan menampilkan banner pengingat singkat agar seluruh pembayaran tetap dilakukan melalui sistem escrow MyPeken (FR-008).

#### [FR-037] Pengaturan Layanan Kurir Pengiriman Toko (Penjual)
- **No**: 37
- **Kode FR**: `FR-037`
- **Kategori**: Tambahan
- **Modul Domain**: Seller - Store Courier Service Configuration
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-012`, `FR-016`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin memilih dan mengaktifkan layanan kurir pengiriman yang didukung oleh toko saya (instan/same-day atau reguler lokal Sarbagita), sehingga pembeli hanya memilih metode pengiriman yang sanggup saya layani.
- **Acceptance Criteria**:
  - Terdapat menu "Pengaturan Kurir" di halaman Pengaturan Toko (FR-016) yang menampilkan daftar layanan kurir resmi terintegrasi API logistik platform di wilayah Sarbagita (kategori Instan / Same-Day dan Reguler Lokal) tanpa skema kurir internal bertarif manual.
  - Penjual dapat mengaktifkan atau menonaktifkan (toggle) masing-masing layanan kurir sesuai karakteristik produk dan kemampuan operasional toko (contoh: kuliner cepat basi hanya mengaktifkan Instan/Same-Day).
  - Sistem mewajibkan setiap toko aktif memiliki minimal satu layanan kurir aktif; jika penjual mencoba menonaktifkan seluruh kurir, sistem menolak perubahan dengan pesan validasi.
  - Perubahan pilihan kurir aktif hanya berlaku untuk transaksi baru saat kalkulasi ongkir (FR-012) dan tidak mengubah layanan kurir pada pesanan yang sudah dibuat/dibayar.

#### [FR-038] Cetak Label Pengiriman & Invoice Transaksi
- **No**: 38
- **Kode FR**: `FR-038`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer & Seller - Shipping Label & Transaction Invoice PDF
- **Aktor Terkait**: `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-005`, `FR-008`, `FR-012`, `FR-014`, `FR-024`, `FR-032`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai penjual, saya ingin mencetak label pengiriman pesanan yang sedang diproses, dan sebagai pembeli, saya ingin mengunduh bukti invoice resmi, sehingga pengemasan dan pencatatan transaksi lebih rapi.
- **Acceptance Criteria**:
  - Pada pesanan berstatus "Diproses" di Daftar Pesanan (FR-014), penjual memiliki tombol "Cetak Label Pengiriman" yang menghasilkan dokumen siap cetak/PDF memuat kode pesanan, kurir & resi/booking code, keterangan status Asuransi Pengiriman (jika aktif), data pengirim (toko), data penerima (FR-024), serta ringkasan barang dan catatan pembeli.
  - Pada Detail Pesanan (FR-032) untuk pesanan yang telah dibayar hingga selesai, pembeli memiliki tombol "Unduh/Cetak Invoice" yang menghasilkan bukti transaksi resmi format PDF memuat rincian barang, harga normal, potongan diskon produk (jika ada, berdasarkan price snapshot FR-005/FR-008), harga akhir, ongkir, Biaya Asuransi Pengiriman (jika aktif, FR-012), biaya layanan, metode bayar, dan status transaksi.

#### [FR-039] Wishlist Produk & Ikuti Toko (Follow)
- **No**: 39
- **Kode FR**: `FR-039`
- **Kategori**: Tambahan
- **Modul Domain**: Buyer - Product Wishlist & Store Follow
- **Aktor Terkait**: `Pembeli`
- **Referensi / Relasi FR**: `FR-001`, `FR-031`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pembeli, saya ingin menyimpan produk ke daftar favorit (wishlist) dan mengikuti (follow) toko UMKM, sehingga mudah diakses kembali dari halaman profil tanpa mencari ulang.
- **Acceptance Criteria**:
  - Terdapat tombol ikon "Wishlist/Favorit" pada kartu/Detail Produk (FR-031) dan tombol "Ikuti Toko" pada Halaman Toko Publik (FR-031); pengunjung belum login diarahkan ke FR-001.
  - Pembeli dapat melihat dan mengelola daftar produk tersimpan serta daftar toko yang diikuti pada halaman Profil Pengguna.

#### [FR-040] Pelaporan Produk, Toko, & Ulasan Spam (Report Abuse)
- **No**: 40
- **Kode FR**: `FR-040`
- **Kategori**: Tambahan
- **Modul Domain**: User - Report Abuse (Products, Stores & Spam Reviews)
- **Aktor Terkait**: `Pengunjung (Guest)`, `Pembeli`, `Penjual (Seller UMKM)`
- **Referensi / Relasi FR**: `FR-001`, `FR-013`, `FR-018`, `FR-028`, `FR-029`, `FR-031`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai pengguna terdaftar (pembeli/penjual), saya ingin melaporkan produk ilegal, barang palsu, toko yang terindikasi melakukan penipuan, maupun ulasan/komentar spam langsung dari halaman produk, toko, atau daftar ulasan, sehingga Admin dapat segera menindaklanjuti pelanggaran dan menjaga keamanan ekosistem MyPeken.
- **Acceptance Criteria**:
  - Terdapat tombol "Laporkan Produk" dan tombol "Laporkan Ulasan" (pada tiap kartu ulasan FR-013) di halaman Detail Produk (FR-031) serta tombol "Laporkan Toko" pada Halaman Toko Publik (FR-031); penjual juga dapat mengakses tombol "Laporkan Ulasan" dari halaman ulasan di Dashboard Toko (FR-013).
  - Pengunjung Guest Mode yang menekan tombol pelaporan ini diarahkan ke autentikasi (FR-001) terlebih dahulu agar pelaporan dapat dipertanggungjawabkan.
  - Pada formulir pelaporan, pelapor wajib memilih kategori pelanggaran sesuai objek yang dilaporkan: (1) Untuk Produk/Toko: Produk Ilegal/Dilarang, Barang Palsu, Indikasi Penipuan/Transaksi di Luar Aplikasi, Konten Tidak Pantas, atau Lokasi Toko Fiktif di Luar Sarbagita. (2) Untuk Ulasan: Ulasan Spam/Bot, Ujaran Kebencian/Kata Kasar, Konten Tidak Relevan/Promosi Pihak Lain, atau Dugaan Ulasan Palsu. Pelapor juga wajib menuliskan deskripsi alasan pelaporan, serta dapat mengunggah bukti pendukung opsional (maksimal 3 gambar, format JPG/PNG).
  - Sistem menerapkan validasi anti-spam: satu pengguna hanya dapat mengirim 1 laporan aktif per produk, toko, atau ulasan yang sama selama laporan sebelumnya masih berstatus "Menunggu Tinjauan", serta pengguna tidak dapat melaporkan produk, toko, maupun ulasan miliknya sendiri.
  - Setelah dikirim, laporan otomatis masuk ke antrean panel "Laporan Pelanggaran" pada dashboard Admin Operasional/KYC & Super Admin (FR-018, FR-028) untuk ditinjau dan ditindaklanjuti ("Hapus Produk", "Suspend Toko/Akun", "Hapus/Sembunyikan Ulasan", atau "Tolak Laporan" dengan alasan wajib yang tercatat di Audit Log FR-029).
  - Pelapor menerima notifikasi in-app apabila laporan yang diajukan telah selesai ditinjau oleh Admin.

#### [FR-041] Dashboard Analitik, Keuangan, & Rekonsiliasi Pendapatan Platform (Super Admin)
- **No**: 41
- **Kode FR**: `FR-041`
- **Kategori**: Tambahan
- **Modul Domain**: Super Admin - Platform Analytics, Financial Position & Reconciliation
- **Aktor Terkait**: `Super Admin`
- **Referensi / Relasi FR**: `FR-002`, `FR-008`, `FR-009`, `FR-010`, `FR-012`, `FR-015`, `FR-019`, `FR-020`, `FR-021`, `FR-025`, `FR-028`, `FR-029`, `FR-034`
- **Kebutuhan Fungsional (User Story)**:
  > Sebagai Super Admin, saya ingin memantau ringkasan metrik transaksi, rincian pendapatan platform, posisi dana mengendap (escrow dan saldo pengguna), serta mengekspor laporan keuangan dan rekonsiliasi secara berkala, sehingga kinerja bisnis dan arus kas platform terkelola secara transparan dan akurat.
- **Acceptance Criteria**:
  - Terdapat menu "Dashboard Keuangan & Rekonsiliasi" di panel Admin yang dibatasi khusus untuk peran Super Admin (FR-028).
  - Dashboard menyediakan filter periode waktu (Harian, Mingguan, Bulanan, dan rentang tanggal kustom) serta filter jenis transaksi (Semua, Produk Fisik UMKM, atau Produk Digital PPOB).
  - Menampilkan ringkasan metrik dan grafik tren secara real-time untuk periode terpilih, mencakup: (1) Performa Transaksi & GMV: Total GMV (Gross Merchandise Value) dari seluruh transaksi berhasil (status "Selesai" untuk produk fisik UMKM dan PPOB), total pesanan aktif, total pesanan selesai, dan total pesanan batal. (2) Rincian Pendapatan Kotor & Pendapatan Bersih Platform: (a) Total Komisi Penjual yang terealisasi dari pelepasan escrow pesanan selesai (sesuai rate snapshot FR-009, termasuk penyesuaian komisi proporsional dari keputusan Partial Refund pada FR-010/FR-020); (b) Total Biaya Layanan Pembeli yang menjadi hak platform (tidak dikembalikan / non-refundable pada pesanan selesai, Partial Refund, dan pembatalan mandiri pembeli sesuai FR-009/FR-021); (c) Total Margin / Biaya Admin PPOB dari transaksi produk digital berhasil (FR-002/FR-009); serta (d) Total Beban Subsidi Transfer Platform (biaya transfer antar-bank yang ditanggung platform untuk penarikan "Saldo Bebas Biaya Tarik" pembeli pada FR-025) guna menghitung Pendapatan Bersih Platform secara transparan. (3) Posisi Dana Pihak Ketiga & Rekonsiliasi (Liabilitas Platform): (a) Total Dana Mengendap di Escrow (akumulasi dana dari pesanan berstatus "Dibayar", "Diproses", "Dikirim", "Terkirim", dan "Komplain/Sengketa" yang belum selesai pada FR-008/FR-010); (b) Total Saldo Tersimpan Pengguna (akumulasi "Saldo Saya" pembeli FR-025 dan "Saldo Toko" penjual termasuk saldo ditahan FR-015/FR-019); (c) Total Piutang Saldo Tertunggak Penjual (tersinkronisasi dari FR-015/FR-019); serta (d) Ringkasan dana ongkos kirim dan premi asuransi yang disalurkan ke pihak jasa logistik (FR-008/FR-012) guna mempermudah rekonsiliasi terhadap rekening penampungan Payment Gateway. (4) Analitik Ekosistem UMKM: Menampilkan daftar 5 Kategori Utama (FR-034) dan 5 Toko UMKM dengan nilai transaksi (GMV) tertinggi pada periode terpilih.
  - Ekspor Laporan Keuangan & Rekonsiliasi: Tersedia tombol "Ekspor Laporan" yang menghasilkan dokumen siap unduh dalam format CSV/Excel (.xlsx) dan PDF, memuat lembar ringkasan pendapatan/rekonsiliasi serta rincian transaksi per nomor pesanan (tanggal, jenis transaksi, harga normal, diskon, subtotal efektif, ongkir, premi asuransi, biaya layanan, tarif & nominal komisi, alokasi refund, dan status dana) untuk kebutuhan pembukuan dan audit.
  - Setiap aktivitas ekspor laporan keuangan oleh Super Admin tercatat otomatis di Audit Log (FR-029) mencakup identitas admin, waktu ekspor, format file, dan rentang periode yang diunduh.
